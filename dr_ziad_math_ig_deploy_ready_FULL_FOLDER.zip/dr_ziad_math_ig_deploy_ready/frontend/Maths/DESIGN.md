﻿# Dr. Ziad Mohamed Math IG Design System

## Color
- Primary: #394959
- Accent: #52667A
- Light: #EDF1F5
- Dark text: #1A232E
- Practice action: #2563EB
- Warning: #D97706
- Error: #DC2626
- Neutral ink and surfaces are tinted slightly toward blue-grey.

## Typography
- Arabic: Cairo
- English: Outfit
- Product UI uses fixed sizes with clear hierarchy and no fluid viewport scaling.

## Shape
- Cards: 12px radius
- Buttons: 8px radius
- Inputs: 10px radius
- Dense tables and panels use restrained borders and soft tinted surfaces.

## Navigation
- Desktop: blue-grey sidebar with role-specific navigation.
- Mobile: bottom navigation with compact icons.
- Page transitions: 180ms fade-slide with framer-motion.

## Identity
- Mascot placeholder: dragon emoji, used sparingly in login, loading, and student practice.

