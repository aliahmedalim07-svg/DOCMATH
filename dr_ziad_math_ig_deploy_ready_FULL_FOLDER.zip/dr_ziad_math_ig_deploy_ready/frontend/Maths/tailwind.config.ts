import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ziad: {
          primary: "#394959",
          accent: "#2c3a47",
          light: "#EDF1F5",
          ink: "#1A232E",
          mint: "#D1DAE3",
          panel: "#F7F9FB",
          line: "#E1E7ED",
        },
        practice: {
          blue: "#2563EB",
          soft: "#EFF6FF",
        },
      },
      borderRadius: {
        card: "12px",
        button: "8px",
      },
      boxShadow: {
        soft: "0 18px 50px rgba(95, 113, 97, 0.08)",
        lift: "0 10px 28px rgba(95, 113, 97, 0.12)",
      },
      fontFamily: {
        cairo: ["Cairo", "sans-serif"],
        outfit: ["Outfit", "sans-serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;

// Trigger Vite CSS watcher restart
