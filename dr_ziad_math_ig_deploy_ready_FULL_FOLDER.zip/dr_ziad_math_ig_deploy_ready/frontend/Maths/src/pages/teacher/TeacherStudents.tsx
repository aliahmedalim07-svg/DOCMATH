import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Edit3, PlusCircle, X, Check, Trash2, KeyRound, Search, Pencil, Save, Loader2 } from "lucide-react";
import { useI18n } from "../../contexts/I18nContext";
import { getStudents, getCourses, addStudentToCourse, removeStudentFromCourse, deleteStudent, resetUserPassword, updateStudent, type UserProfileDto } from "../../lib/api-service";

export default function TeacherStudents() {
  const { t } = useI18n();
  const [courseFilter, setCourseFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [students, setStudents] = useState<UserProfileDto[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [selectedCourseIds, setSelectedCourseIds] = useState<string[]>([]);
  const [editModalStudent, setEditModalStudent] = useState<UserProfileDto | null>(null);
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editParentPhone, setEditParentPhone] = useState("");
  const [savingEdit, setSavingEdit] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        const [studentData, courseData] = await Promise.all([getStudents(), getCourses()]);
        setStudents(studentData);
        setCourses(courseData);
      } catch (error) {
        console.error("Failed to load data", error);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const filteredStudents = students.filter(s => {
    const noCourses = !s.courseIds || s.courseIds.length === 0;
    const matchesCourse = courseFilter === "all" || (courseFilter === "none" ? noCourses : s.courseIds?.includes(Number(courseFilter)));
    if (!matchesCourse) return false;
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      s.name.toLowerCase().includes(q) ||
      (s.phone && s.phone.toLowerCase().includes(q)) ||
      (s.userName && s.userName.toLowerCase().includes(q))
    );
  });

  const startEditCourses = (student: UserProfileDto) => {
    setEditingStudentId(student.id);
    setSelectedCourseIds((student.courseIds || []).map(String));
  };

  const cancelEditCourses = () => {
    setEditingStudentId(null);
    setSelectedCourseIds([]);
  };

  const toggleCourseSelection = (courseId: string) => {
    if (selectedCourseIds.includes(courseId)) {
      setSelectedCourseIds(selectedCourseIds.filter(id => id !== courseId));
    } else {
      setSelectedCourseIds([...selectedCourseIds, courseId]);
    }
  };

  const saveCourseAssignments = async (studentId: string) => {
    setUpdatingId(studentId);
    try {
      const student = students.find(s => s.id === studentId);
      if (!student) return;

      const currentCourseIds = (student.courseIds || []).map(String);
      const toAdd = selectedCourseIds.filter(id => !currentCourseIds.includes(id));
      const toRemove = currentCourseIds.filter(id => !selectedCourseIds.includes(id));

      await Promise.all([
        ...toAdd.map(courseId => addStudentToCourse(studentId, Number(courseId))),
        ...toRemove.map(courseId => removeStudentFromCourse(studentId, Number(courseId)))
      ]);

      setStudents(prev => prev.map(item =>
        item.id === studentId ? { ...item, courseIds: selectedCourseIds.map(Number) } : item
      ));
      setEditingStudentId(null);
    } catch (error) {
      console.error("Failed to update course assignments", error);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleDeleteStudent = async (student: UserProfileDto) => {
    if (!confirm(t("deleteStudentConfirm"))) return;
    setUpdatingId(student.id);
    try {
      await deleteStudent(student.id);
      setStudents(prev => prev.filter(s => s.id !== student.id));
    } catch (error) {
      console.error("Failed to delete student", error);
    } finally {
      setUpdatingId(null);
    }
  };

  const openEditModal = (student: UserProfileDto) => {
    setEditModalStudent(student);
    setEditName(student.name || "");
    setEditPhone(student.phone || "");
    setEditParentPhone(student.parentPhone || "");
  };

  const handleSaveEdit = async () => {
    if (!editModalStudent) return;
    setSavingEdit(true);
    try {
      const updated = await updateStudent(editModalStudent.id, {
        name: editName,
        phone: editPhone || null,
        parentPhone: editParentPhone || null,
      });
      setStudents(prev => prev.map(s => s.id === updated.id ? { ...s, ...updated } : s));
      setEditModalStudent(null);
    } catch (error) {
      console.error("Failed to update student", error);
    } finally {
      setSavingEdit(false);
    }
  };

  const handleResetPassword = async (student: UserProfileDto) => {
    const newPassword = window.prompt(`${t("enterNewPassword")} ${student.name}`);
    if (!newPassword) return;
    if (newPassword.length < 6) {
      window.alert(t("passwordMinChars"));
      return;
    }

    setUpdatingId(student.id);
    try {
      await resetUserPassword(student.id, newPassword);
      window.alert(t("passwordHasBeenReset"));
    } catch (error) {
      console.error("Failed to reset password", error);
      window.alert(t("couldNotResetPassword"));
    } finally {
      setUpdatingId(null);
    }
  };

  const getStudentCourseNames = (student: UserProfileDto) => {
    if (!student.courseIds || student.courseIds.length === 0) return t("noCoursesFound");
    const names = student.courseIds
      .map(id => courses.find(c => c.id == id)?.name || `Course ${id}`)
      .slice(0, 2);
    const extra = student.courseIds.length > 2 ? ` +${student.courseIds.length - 2}` : "";
    return names.join(", ") + extra;
  };

  return (
    <div className="space-y-5">
      <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-bold uppercase text-ziad-primary">{t("students")}</p>
            <h1 className="text-3xl font-extrabold text-ziad-ink">{t("studentManagement")}</h1>
            <p className="mt-2 text-sm text-ziad-ink/62">{t("manageEnrollments")}</p>
          </div>
          <div className="flex gap-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ziad-ink/65" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t("searchNameUsernamePhone")}
                className="h-10 w-64 rounded-button border border-ziad-line bg-white pl-9 pr-3 text-sm text-ziad-ink placeholder:text-ziad-ink/62 focus:outline-none focus:ring-2 focus:ring-ziad-primary/30"
              />
            </div>
            <select
              value={courseFilter}
              onChange={(e) => setCourseFilter(e.target.value)}
              className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-bold text-ziad-ink"
            >
              <option value="all">{t("allCourses")}</option>
              <option value="none">{t("noCoursesFound")}</option>
              {courses.map(course => (
                <option key={course.id} value={course.id}>{course.name}</option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <div className="table-scroll overflow-x-auto rounded-card border border-ziad-line bg-ziad-panel shadow-sm">
        <table className="min-w-[1200px] w-full border-collapse text-sm">
          <thead className="bg-ziad-light text-xs uppercase text-ziad-ink/68">
            <tr>
              {[t("nameColumn"), t("username"), t("phoneLabel"), t("parentsPhone"), t("enrolledCourses"), "Actions"].map((column) => (
                <th key={column} className="px-4 py-3 text-start font-extrabold">{column}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-ziad-line">
            {loading ? (
              <tr>
                <td colSpan={6} className="py-8 text-center font-medium text-ziad-ink/72">{t("loadingStudents")}</td>
              </tr>
            ) : filteredStudents.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center font-medium text-ziad-ink/72">{t("noResultsFound")}</td>
              </tr>
            ) : filteredStudents.map((student) => (
              <tr key={student.id} className="hover:bg-ziad-light/35">
                <td className="px-4 py-4">
                  <Link to={`/teacher/students/${student.id}`} className="font-extrabold text-ziad-ink hover:text-ziad-primary">
                    {student.name}
                  </Link>
                </td>
                <td className="px-4 py-4 text-ziad-ink/70">{student.userName || t("notAvailable")}</td>
                <td className="px-4 py-4 text-ziad-ink/70">{student.phone || t("notAvailable")}</td>
                <td className="px-4 py-4 text-ziad-ink/70">{student.parentPhone || t("notAvailable")}</td>
                <td className="px-4 py-4">
                  {editingStudentId === student.id ? (
                    <div className="flex flex-col gap-2">
                      <div className="flex flex-wrap gap-1">
                        {courses.map(course => (
                          <button
                            key={course.id}
                            onClick={() => toggleCourseSelection(String(course.id))}
                            className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs font-bold transition ${
                              selectedCourseIds.includes(String(course.id))
                                ? "bg-ziad-primary text-white"
                                : "border border-ziad-line bg-white text-ziad-ink hover:bg-ziad-light"
                            }`}
                          >
                            {selectedCourseIds.includes(String(course.id)) ? (
                              <Check className="h-3 w-3" />
                            ) : (
                              <PlusCircle className="h-3 w-3" />
                            )}
                            {course.name}
                          </button>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => saveCourseAssignments(student.id)}
                          disabled={updatingId === student.id}
                          className="inline-flex items-center gap-1 rounded bg-emerald-600 px-2 py-1 text-xs font-bold text-white hover:bg-emerald-700 disabled:opacity-50"
                        >
                          <Check className="h-3 w-3" /> {t("actionSave")}
                        </button>
                        <button
                          onClick={cancelEditCourses}
                          className="inline-flex items-center gap-1 rounded-button border border-ziad-line px-2 py-1 text-xs font-bold text-ziad-ink hover:bg-ziad-light"
                        >
                          <X className="h-3 w-3" /> {t("actionCancel")}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <span className="text-sm text-ziad-ink/70">{getStudentCourseNames(student)}</span>
                  )}
                </td>
                <td className="px-4 py-4">
                  <div className="flex flex-wrap gap-2">
                    {editingStudentId !== student.id && (
                      <>
                        <button
                          onClick={() => openEditModal(student)}
                          className="inline-flex items-center gap-1.5 rounded-button border border-ziad-line bg-ziad-panel px-2.5 py-1.5 text-xs font-bold text-ziad-ink hover:bg-ziad-light"
                        >
                          <Pencil className="h-3.5 w-3.5" /> {t("actionEdit")}
                        </button>
                        <button
                          onClick={() => startEditCourses(student)}
                          className="inline-flex items-center gap-1.5 rounded-button border border-ziad-line bg-ziad-panel px-2.5 py-1.5 text-xs font-bold text-ziad-ink hover:bg-ziad-light"
                        >
                          <Edit3 className="h-3.5 w-3.5" /> {t("courses")}
                        </button>
                        <button
                          onClick={() => handleResetPassword(student)}
                          disabled={updatingId === student.id}
                          className="inline-flex items-center gap-1.5 rounded-button border border-ziad-line bg-ziad-panel px-2.5 py-1.5 text-xs font-bold text-ziad-ink hover:bg-ziad-light disabled:opacity-60"
                        >
                          <KeyRound className="h-3.5 w-3.5" /> {t("actionResetPassword")}
                        </button>
                        <button
                          onClick={() => handleDeleteStudent(student)}
                          disabled={updatingId === student.id}
                          className="inline-flex items-center gap-1.5 rounded-button border border-red-300 bg-white px-2.5 py-1.5 text-xs font-bold text-red-600 hover:bg-red-50 disabled:opacity-60"
                        >
                          <Trash2 className="h-3.5 w-3.5" /> {t("actionDelete")}
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editModalStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => !savingEdit && setEditModalStudent(null)}>
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl" onClick={e => e.stopPropagation()} style={{ animation: "scaleIn 0.2s ease-out" }}>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-ziad-ink">{t("editStudent")}</h3>
              <button onClick={() => setEditModalStudent(null)} className="rounded-button p-1.5 text-ziad-ink/70 hover:bg-ziad-light">
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-1 text-sm font-medium text-ziad-ink/70">{editModalStudent.name}</p>

            <div className="mt-5 space-y-4">
              <div>
                <label className="text-[10px] font-bold uppercase text-ziad-ink/70">{t("fullName")}</label>
                <input
                  type="text"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="mt-1 h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-ziad-ink/70">{t("phoneLabel")}</label>
                <input
                  type="text"
                  value={editPhone}
                  onChange={e => setEditPhone(e.target.value)}
                  className="mt-1 h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-ziad-ink/70">{t("parentsPhone")}</label>
                <input
                  type="text"
                  value={editParentPhone}
                  onChange={e => setEditParentPhone(e.target.value)}
                  className="mt-1 h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
                />
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setEditModalStudent(null)}
                disabled={savingEdit}
                className="flex-1 rounded-button border border-ziad-line bg-white px-4 py-2.5 text-sm font-bold text-ziad-ink hover:bg-ziad-light disabled:opacity-50"
              >
                {t("actionCancel")}
              </button>
              <button
                onClick={handleSaveEdit}
                disabled={savingEdit || !editName.trim()}
                className="flex-1 rounded-button bg-ziad-primary px-4 py-2.5 text-sm font-bold text-white hover:bg-ziad-ink disabled:opacity-50 inline-flex items-center justify-center gap-2"
              >
                {savingEdit ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {savingEdit ? t("savingDots") : t("actionSave")}
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95) translateY(8px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
      `}</style>
    </div>
  );
}
