import { useEffect, useMemo, useState } from "react";
import { AlertCircle, Eye, FileText, Link as LinkIcon, Loader2, Plus, Trash2, Upload, Video, Lock, X } from "lucide-react";
import { useI18n } from "../../contexts/I18nContext";
import { addPdfToQuestionGroup, addVideoToQuestionGroup, getVideoUserViews, removePdfFromQuestionGroup, removeVideoFromQuestionGroup, updateVideoUserView, getAssignments, getSkills } from "../../lib/api-service";
import type { Assignment, Skill, VideoResource } from "../../lib/types";
import { cn } from "../../lib/utils";

type ResourceGroup = {
  id: string;
  title: string;
  kind: "Assignment" | "Skill";
  videos: Assignment["videos"];
  pdfs: Assignment["pdfs"];
};

export default function TeacherResources() {
  const { t } = useI18n();
  const [groups, setGroups] = useState<ResourceGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [videoProvider, setVideoProvider] = useState<'youtube' | 'vdocipher'>('youtube');
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [savingVideo, setSavingVideo] = useState(false);
  const [savingPdf, setSavingPdf] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [defaultViews, setDefaultViews] = useState(5);
  const [manageVideo, setManageVideo] = useState<VideoResource | null>(null);
  const [manageUsers, setManageUsers] = useState<{ userId: string; userName: string; views: number }[]>([]);
  const [manageLoading, setManageLoading] = useState(false);
  const [savingViews, setSavingViews] = useState<string | null>(null);

  const loadGroups = async () => {
    setLoading(true);
    try {
      const [assignments, skills] = await Promise.all([getAssignments(), getSkills()]);
      const assignmentGroups = assignments.map((item) => ({
        id: item.id,
        title: item.title,
        kind: "Assignment" as const,
        videos: item.videos || [],
        pdfs: item.pdfs || [],
      }));
      const skillGroups = skills.map((item: Skill) => ({
        id: item.id,
        title: item.name,
        kind: "Skill" as const,
        videos: (item as any).videos || [],
        pdfs: (item as any).pdfs || [],
      }));
      const nextGroups = [...assignmentGroups, ...skillGroups];
      setGroups(nextGroups);
      setSelectedGroupId((current) => current || nextGroups[0]?.id || "");
    } catch (error: any) {
      setMessage({ type: "error", text: error?.message || t("failedToLoadResources") });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadGroups();
  }, []);

  const selectedGroup = useMemo(
    () => groups.find((group) => group.id === selectedGroupId) || null,
    [groups, selectedGroupId],
  );

  const handleAddVideo = async () => {
    if (!selectedGroup || !videoUrl.trim()) return;
    setSavingVideo(true);
    setMessage(null);
    try {
      await addVideoToQuestionGroup(selectedGroup.id, videoUrl.trim(), videoProvider, videoProvider === 'vdocipher' ? defaultViews : undefined);
      setVideoUrl("");
      setMessage({ type: "success", text: t("videoAddedSuccess") });
      await loadGroups();
    } catch (error: any) {
      setMessage({ type: "error", text: error?.message || t("failedToAddVideo") });
    } finally {
      setSavingVideo(false);
    }
  };

  const handleAddPdf = async () => {
    if (!selectedGroup || !pdfFile) return;
    setSavingPdf(true);
    setMessage(null);
    try {
      await addPdfToQuestionGroup(selectedGroup.id, pdfFile);
      setPdfFile(null);
      setMessage({ type: "success", text: t("pdfUploadedSuccess") });
      await loadGroups();
    } catch (error: any) {
      setMessage({ type: "error", text: error?.message || t("failedToUploadPdf") });
    } finally {
      setSavingPdf(false);
    }
  };

  const handleDeleteVideo = async (videoId: string) => {
    if (!selectedGroup) return;
    if (!confirm(t("deleteVideoConfirm"))) return;
    setMessage(null);
    try {
      await removeVideoFromQuestionGroup(selectedGroup.id, videoId);
      setMessage({ type: "success", text: t("videoDeleted") });
      await loadGroups();
    } catch (error: any) {
      setMessage({ type: "error", text: error?.message || t("failedToDeleteVideo") });
    }
  };

  const handleDeletePdf = async (pdfId: string) => {
    if (!selectedGroup) return;
    if (!confirm(t("deletePdfConfirm"))) return;
    setMessage(null);
    try {
      await removePdfFromQuestionGroup(selectedGroup.id, pdfId);
      setMessage({ type: "success", text: t("pdfDeleted") });
      await loadGroups();
    } catch (error: any) {
      setMessage({ type: "error", text: error?.message || t("failedToDeletePdf") });
    }
  };

  const openManageViews = async (video: VideoResource) => {
    setManageVideo(video);
    setManageLoading(true);
    try {
      const users = await getVideoUserViews(video.id);
      setManageUsers(users);
    } catch {
      setMessage({ type: "error", text: t("failedToLoadUserViews") });
    } finally {
      setManageLoading(false);
    }
  };

  const handleSaveUserView = async (userId: string, views: number) => {
    if (!manageVideo) return;
    setSavingViews(userId);
    try {
      await updateVideoUserView(manageVideo.id, userId, views);
      setManageUsers((prev) => prev.map((u) => u.userId === userId ? { ...u, views } : u));
      setMessage({ type: "success", text: t("viewsUpdatedText") });
    } catch {
      setMessage({ type: "error", text: t("failedToUpdateViews") });
    } finally {
      setSavingViews(null);
    }
  };

  const closeManageViews = () => {
    setManageVideo(null);
    setManageUsers([]);
  };

  if (loading) {
    return <div className="flex items-center justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-ziad-primary" /></div>;
  }

  return (
    <div className="space-y-5">
      <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
        <p className="text-xs font-bold uppercase text-ziad-primary">{t("resources")}</p>
        <h1 className="text-3xl font-extrabold text-ziad-ink">{t("videosAndPdfs")}</h1>
        <p className="mt-2 text-sm text-ziad-ink/62">{t("attachYouTubeLinks")}</p>
      </section>

      {message && (
        <div className={cn(
          "flex items-center gap-3 rounded-card border px-4 py-3 text-sm font-semibold",
          message.type === "success" ? "border-green-300 bg-green-50 text-green-800" : "border-red-300 bg-red-50 text-red-800",
        )}>
          <AlertCircle className="h-4 w-4" />
          {message.text}
        </div>
      )}

      <div className="grid gap-4 xl:grid-cols-[360px_1fr]">
        <section className="rounded-card border border-ziad-line bg-ziad-panel p-4 shadow-sm">
          <p className="text-xs font-bold uppercase text-ziad-primary">{t("targetSection")}</p>
          <select
            value={selectedGroupId}
            onChange={(event) => setSelectedGroupId(event.target.value)}
            className="mt-3 h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold"
          >
            {groups.map((group) => (
              <option key={group.id} value={group.id}>{group.kind}: {group.title}</option>
            ))}
          </select>

          <div className="mt-5 space-y-3">
            <p className="text-xs font-bold uppercase text-ziad-primary">{t("addVideo")}</p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => { setVideoProvider('youtube'); setVideoUrl(''); }}
                className={`flex-1 rounded-button border px-3 py-2 text-xs font-bold transition ${videoProvider === 'youtube' ? 'border-ziad-primary bg-ziad-primary/10 text-ziad-primary' : 'border-ziad-line text-ziad-ink/72 hover:bg-ziad-light'}`}
              >
                {t("youtubeSource")}
              </button>
              <button
                type="button"
                onClick={() => { setVideoProvider('vdocipher'); setVideoUrl(''); }}
                className={`flex-1 rounded-button border px-3 py-2 text-xs font-bold transition ${videoProvider === 'vdocipher' ? 'border-ziad-primary bg-ziad-primary/10 text-ziad-primary' : 'border-ziad-line text-ziad-ink/72 hover:bg-ziad-light'}`}
              >
                <Lock className="mr-1 inline h-3 w-3" />{t("vdoCipherSource")}
              </button>
            </div>
            <input
              value={videoUrl}
              onChange={(event) => setVideoUrl(event.target.value)}
              placeholder={videoProvider === 'youtube' ? t("youtubeUrl") : t("vdoCipherVideoId")}
              className="h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
            />
            {videoProvider === 'vdocipher' && (
              <div className="flex items-center gap-2">
                <Eye className="h-4 w-4 shrink-0 text-ziad-ink/72" />
                <input
                  type="number"
                  min={1}
                  value={defaultViews}
                  onChange={(event) => setDefaultViews(Math.max(1, Number(event.target.value)))}
                  className="h-10 w-24 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
                />
                <span className="text-xs font-semibold text-ziad-ink/72">{t("viewsPerUser")}</span>
              </div>
            )}
            <button
              type="button"
              onClick={handleAddVideo}
              disabled={savingVideo || !selectedGroup || !videoUrl.trim()}
              className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-button bg-ziad-primary px-4 text-sm font-extrabold text-ziad-light hover:bg-ziad-ink disabled:opacity-50"
            >
              {savingVideo ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              {t("actionSave")}
            </button>
          </div>

          <div className="mt-6 space-y-3">
            <p className="text-xs font-bold uppercase text-ziad-primary">{t("uploadPdfLabel")}</p>
            <label className="inline-flex h-10 w-full cursor-pointer items-center justify-center gap-2 rounded-button border border-ziad-line px-4 text-sm font-bold text-ziad-ink hover:bg-ziad-light">
              <Upload className="h-4 w-4" />
              {pdfFile ? pdfFile.name : t("choosePdf")}
              <input type="file" accept=".pdf,application/pdf" className="hidden" onChange={(event) => setPdfFile(event.target.files?.[0] || null)} />
            </label>
            <button
              type="button"
              onClick={handleAddPdf}
              disabled={savingPdf || !selectedGroup || !pdfFile}
              className="h-10 w-full rounded-button bg-ziad-primary px-4 text-sm font-extrabold text-ziad-light hover:bg-ziad-ink disabled:opacity-50"
            >
              {savingPdf ? t("uploadingDots") : t("saveVideo")}
            </button>
          </div>
        </section>

        <section className="rounded-card border border-ziad-line bg-ziad-panel p-4 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-bold uppercase text-ziad-primary">{selectedGroup?.kind || "Resources"}</p>
              <h2 className="text-xl font-extrabold text-ziad-ink">{selectedGroup?.title || t("noGroupSelected")}</h2>
            </div>
          </div>

          <div className="mt-5 grid gap-4 lg:grid-cols-2">
            <div>
              <p className="mb-2 text-xs font-bold uppercase text-ziad-ink/75">{t("videosSection")}</p>
              <div className="space-y-2">
                {selectedGroup?.videos?.length ? selectedGroup.videos.map((video) => (
                  <div key={video.id} className="flex items-center gap-3 rounded-card border border-ziad-line bg-ziad-light/45 p-3 text-sm font-bold text-ziad-ink">
                    <Video className="h-4 w-4 shrink-0 text-ziad-accent" />
                    <span className="truncate">{video.title || video.url}</span>
                    {video.provider === 'vdocipher' && (
                      <span className="shrink-0 text-xs font-semibold text-ziad-ink/70">
                        {video.defaultViews != null ? `${video.defaultViews} views` : ''}
                      </span>
                    )}
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold ${video.provider === 'vdocipher' ? 'bg-violet-100 text-violet-700' : 'bg-red-100 text-red-700'}`}>
                      {video.provider === 'vdocipher' ? 'VdoCipher' : 'YouTube'}
                    </span>
                    {video.provider === 'vdocipher' && (
                      <button type="button" onClick={() => openManageViews(video)} className="shrink-0 text-ziad-primary hover:text-ziad-ink" title={t("labelManageViews")}>
                        <Eye className="h-4 w-4" />
                      </button>
                    )}
                    <button type="button" aria-label={t("ariaDeleteVideo")} onClick={() => handleDeleteVideo(video.id)} className="shrink-0 text-red-400 hover:text-red-600">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                )) : <p className="rounded-card border border-dashed border-ziad-line p-5 text-center text-sm font-medium text-ziad-ink/72">{t("noVideosYet")}</p>}
              </div>
            </div>

            <div>
              <p className="mb-2 text-xs font-bold uppercase text-ziad-ink/75">{t("pdfSection")}</p>
              <div className="space-y-2">
                {selectedGroup?.pdfs?.length ? selectedGroup.pdfs.map((pdf) => (
                  <div key={pdf.id} className="flex items-center gap-3 rounded-card border border-ziad-line bg-ziad-light/45 p-3 text-sm font-bold text-ziad-ink">
                    <a href={pdf.fileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 flex-1 min-w-0">
                      <FileText className="h-4 w-4 shrink-0 text-ziad-primary" />
                      <span className="truncate">{pdf.title}</span>
                      <LinkIcon className="shrink-0 h-4 w-4 text-ziad-ink/70" />
                    </a>
                    <button type="button" aria-label={t("ariaDeletePdf")} onClick={() => handleDeletePdf(pdf.id)} className="shrink-0 text-red-400 hover:text-red-600">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                )) : <p className="rounded-card border border-dashed border-ziad-line p-5 text-center text-sm font-medium text-ziad-ink/72">{t("noPdfsYet")}</p>}
              </div>
            </div>
          </div>
        </section>
      </div>

      {manageVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={closeManageViews}>
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-card bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-lg font-extrabold text-ziad-ink">{t("manageViews")}</h3>
              <button type="button" onClick={closeManageViews} className="text-ziad-ink/70 hover:text-ziad-ink">
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-1 text-sm font-medium text-ziad-ink/72">{manageVideo.title || manageVideo.url}</p>
            <div className="mt-3 mb-3">
              <input
                type="text"
                placeholder={t("searchStudentsPlaceholder")}
                className="w-full h-10 rounded-button border border-ziad-line bg-white px-4 text-sm font-semibold outline-none focus:border-ziad-primary"
                onChange={(e) => {
                  const term = e.target.value.toLowerCase();
                  // Filter happens via state if needed; simple DOM filter for now
                  const rows = document.querySelectorAll('[data-user-row]');
                  rows.forEach((row) => {
                    const name = row.getAttribute('data-user-name') || '';
                    (row as HTMLElement).style.display = name.toLowerCase().includes(term) ? '' : 'none';
                  });
                }}
              />
            </div>
            {manageLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-ziad-primary" /></div>
            ) : manageUsers.length === 0 ? (
              <p className="py-8 text-center text-sm font-medium text-ziad-ink/72">{t("noUsersFound")}</p>
            ) : (
              <div className="mt-4 space-y-2 max-h-[400px] overflow-auto">
                {manageUsers.map((user) => (
                  <div key={user.userId} data-user-row data-user-name={user.userName} className="flex items-center justify-between gap-3 rounded-card border border-ziad-line bg-ziad-light/45 p-3">
                    <span className="truncate text-sm font-bold text-ziad-ink">{user.userName}</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={0}
                        defaultValue={user.views}
                        className="h-8 w-20 rounded-button border border-ziad-line bg-white px-2 text-sm font-semibold outline-none focus:border-ziad-primary"
                        onBlur={(e) => {
                          const newViews = Math.max(0, Number(e.target.value));
                          if (newViews !== user.views) handleSaveUserView(user.userId, newViews);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            const newViews = Math.max(0, Number((e.currentTarget as HTMLInputElement).value));
                            if (newViews !== user.views) handleSaveUserView(user.userId, newViews);
                          }
                        }}
                      />
                      {savingViews === user.userId && <Loader2 className="h-4 w-4 animate-spin text-ziad-primary" />}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
