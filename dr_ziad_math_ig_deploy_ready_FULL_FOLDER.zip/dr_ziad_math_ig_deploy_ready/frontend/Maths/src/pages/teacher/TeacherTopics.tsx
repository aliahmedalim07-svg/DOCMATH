import { useEffect, useState } from "react";
import { Loader2, Search, Trash2, Edit2, AlertTriangle, X, Check, AlertCircle } from "lucide-react";
import { useI18n } from "../../contexts/I18nContext";
import { getTopics, createTopic, updateTopic, deleteTopic } from "../../lib/api-service";
import { cn } from "../../lib/utils";
import type { Topic } from "../../lib/types";

export default function TeacherTopics() {
  const { t } = useI18n();
  const [topics, setTopics] = useState<Topic[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [topicName, setTopicName] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Topic | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadTopics = async () => {
    try {
      const data = await getTopics();
      setTopics(data);
    } catch {
      setMessage({ type: "error", text: t("failedAction") });
    } finally {
      setLoading(false);
    }
  };

  const filteredTopics = searchQuery.trim()
    ? topics.filter(t => t.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : topics;

  useEffect(() => {
    loadTopics();
  }, []);

  const handleSave = async () => {
    if (!topicName.trim() || saving) return;
    setSaving(true);
    setMessage(null);
    try {
      if (editingId) {
        await updateTopic(editingId, topicName.trim());
        setMessage({ type: "success", text: t("topicUpdated") });
      } else {
        await createTopic(topicName.trim());
        setMessage({ type: "success", text: t("topicCreated") });
      }
      setTopicName("");
      setEditingId(null);
      await loadTopics();
    } catch {
      setMessage({ type: "error", text: t("failedAction") });
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (topic: Topic) => {
    setEditingId(topic.id);
    setTopicName(topic.name);
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteTopic(deleteTarget.id);
      setMessage({ type: "success", text: t("topicDeleted") });
      setDeleteTarget(null);
      await loadTopics();
    } catch {
      setMessage({ type: "error", text: t("failedAction") });
    } finally {
      setDeleting(false);
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setTopicName("");
  };

  if (loading) {
    return <div className="flex items-center justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-ziad-primary" /></div>;
  }

  return (
    <div className="space-y-5">
      <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
        <p className="text-xs font-bold uppercase text-ziad-primary">{t("topics")}</p>
        <h1 className="text-3xl font-extrabold text-ziad-ink">{t("topicManagement")}</h1>
      </section>

      {message && (
        <div className={cn(
          "flex items-center gap-3 rounded-card border px-4 py-3 text-sm font-semibold",
          message.type === "success" ? "border-green-300 bg-green-50 text-green-800" : "border-red-300 bg-red-50 text-red-800"
        )}>
          {message.type === "error" ? <AlertCircle className="h-4 w-4 flex-shrink-0" /> : <Check className="h-4 w-4 flex-shrink-0" />}
          {message.text}
          <button onClick={() => setMessage(null)} className="ml-auto rounded-button p-1 hover:bg-black/5">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      <div className="grid gap-4 xl:grid-cols-[380px_1fr]">
        <section className="rounded-card border border-ziad-line bg-ziad-panel p-4 shadow-sm self-start sticky top-5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold uppercase text-ziad-primary">{editingId ? t("editTopic") : t("addTopic")}</p>
            {editingId && (
              <button onClick={resetForm} className="text-xs font-bold text-red-600 hover:underline">{t("actionCancel")}</button>
            )}
          </div>
          <div className="mt-3 space-y-3">
            <input
              value={topicName}
              onChange={(e) => setTopicName(e.target.value)}
              placeholder={t("topicName")}
              className="h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
            />
            <button
              onClick={handleSave}
              disabled={saving || !topicName.trim()}
              className="w-full rounded-button bg-ziad-primary px-4 py-2 text-sm font-extrabold text-ziad-light hover:bg-ziad-ink disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin mx-auto" /> : (editingId ? t("editTopic") : t("addTopic"))}
            </button>
          </div>
        </section>

        <section className="rounded-card border border-ziad-line bg-ziad-panel shadow-sm">
          <div className="px-4 pt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ziad-ink/65" />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t("searchTopics")}
                className="h-10 w-full rounded-button border border-ziad-line bg-white pl-10 pr-3 text-sm outline-none focus:border-ziad-primary"
              />
            </div>
          </div>
          <table className="min-w-[400px] w-full text-sm">
            <thead className="bg-ziad-light text-xs uppercase text-ziad-ink/68">
              <tr>
                <th className="px-4 py-3 text-start font-extrabold">#</th>
                <th className="px-4 py-3 text-start font-extrabold">{t("topicName")}</th>
                <th className="px-4 py-3 text-start font-extrabold">{t("actions")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ziad-line">
              {filteredTopics.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-4 py-8 text-center text-sm font-medium text-ziad-ink/72">{searchQuery.trim() ? t("noTopicsMatch") : t("noTopicsFound")}</td>
                </tr>
              ) : filteredTopics.map((topic, index) => (
                <tr key={topic.id} className="hover:bg-ziad-light/35 transition-colors">
                  <td className="px-4 py-4 font-bold text-ziad-ink/68">{index + 1}</td>
                  <td className="px-4 py-4 font-semibold text-ziad-ink">{topic.name}</td>
                  <td className="px-4 py-4">
                    <div className="flex gap-2">
                      <button onClick={() => handleEdit(topic)} title={t("editTopic")} className="p-1.5 text-ziad-primary hover:bg-ziad-primary/10 rounded-lg transition">
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button onClick={() => setDeleteTarget(topic)} title={t("deleteTopic")} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>

      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => !deleting && setDeleteTarget(null)} />
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <button onClick={() => !deleting && setDeleteTarget(null)} className="absolute right-4 top-4 p-1 text-gray-600 hover:text-gray-800 rounded-full hover:bg-gray-100 transition">
              <X className="h-5 w-5" />
            </button>
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-red-100">
              <AlertTriangle className="h-7 w-7 text-red-600" />
            </div>
            <div className="mt-4 text-center">
              <h3 className="text-lg font-bold text-gray-900">{t("deleteTopic")}</h3>
              <p className="mt-2 text-sm font-medium text-gray-700">{t("deleteTopicConfirm")}</p>
              <div className="mt-3 rounded-lg bg-gray-50 border border-gray-100 p-3 text-sm font-bold text-gray-700">
                {deleteTarget.name}
              </div>
            </div>
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setDeleteTarget(null)}
                disabled={deleting}
                className="flex-1 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-bold text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
              >
                {t("actionCancel")}
              </button>
              <button
                onClick={confirmDelete}
                disabled={deleting}
                className="flex-1 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-red-700 transition disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                {deleting ? t("deletingDots") : t("deleteTopic")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
