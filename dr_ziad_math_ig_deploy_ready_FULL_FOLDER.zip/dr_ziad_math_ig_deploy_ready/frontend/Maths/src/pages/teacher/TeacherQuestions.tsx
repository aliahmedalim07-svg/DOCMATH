import { useEffect, useMemo, useState, useRef } from "react";
import { Loader2, Trash2, Edit2, AlertTriangle, X, Plus, Image as ImageIcon, Upload, Eye } from "lucide-react";
import * as XLSX from "xlsx";
import katex from "katex";
import { useI18n } from "../../contexts/I18nContext";
import { QuestionLatexPreview } from "../../components/QuestionLatexPreview";
import { LatexRenderer } from "../../components/LatexRenderer";
import { 
  getBooks, 
  getQuestions, 
  createQuestion, 
  deleteQuestion, 
  updateQuestion, 
  addQuestionToBook,
  uploadQuestionImage,
  uploadExplanationImage,
  uploadChoiceImage,
  getTopics,
  Book,
  Question as QuestionType,
  Topic
} from "../../lib/api-service";

interface BulkQuestionItem {
  id: number;
  questionText: string;
  choices: { id: number; text: string; isCorrect: boolean }[];
  questionImageFile: File | null;
  questionImagePreview: string;
  explanation: string;
  explanationImageFile: File | null;
  explanationImagePreview: string;
}

interface PreviewQuestion {
  title: string;
  questionText: string;
  choices: { id?: number | string; text: string; isCorrect?: boolean }[];
  questionImageUrl?: string;
  explanation?: string;
  explanationImageUrl?: string;
}

export default function TeacherQuestions() {
  const { t } = useI18n();
  const [books, setBooks] = useState<Book[]>([]);
  const [questions, setQuestions] = useState<QuestionType[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [difficulty, setDifficulty] = useState("all");
  const [year, setYear] = useState("all");
  const [month, setMonth] = useState("all");
  const [bookFilter, setBookFilter] = useState("all");
  const [topicFilter, setTopicFilter] = useState("all");

  interface OptionState {
    text: string;
    isCorrect: boolean;
    choiceId?: number;
    imageFile?: File | null;
    imagePreview?: string;
    existingImageUrl?: string;
  }

  const [editingId, setEditingId] = useState<string | null>(null);
  const [qText, setQText] = useState("");
  const [options, setOptions] = useState<OptionState[]>([{ text: "", isCorrect: false }]);
  const [explanation, setExplanation] = useState("");
  const [questionImageFile, setQuestionImageFile] = useState<File | null>(null);
  const [questionImagePreview, setQuestionImagePreview] = useState<string>("");
  const [explanationImageFile, setExplanationImageFile] = useState<File | null>(null);
  const [explanationImagePreview, setExplanationImagePreview] = useState<string>("");
  const [newDifficulty, setNewDifficulty] = useState("medium");
  const [newYear, setNewYear] = useState(String(new Date().getFullYear()));
  const [newMonth, setNewMonth] = useState("");
  const [selectedBookId, setSelectedBookId] = useState("");
  const [selectedTopicId, setSelectedTopicId] = useState("");
  const [saving, setSaving] = useState(false);
  const [showQuestionPreview, setShowQuestionPreview] = useState(false);
  const [previewQuestion, setPreviewQuestion] = useState<PreviewQuestion | null>(null);

  const questionImageInputRef = useRef<HTMLInputElement>(null);
  const explanationImageInputRef = useRef<HTMLInputElement>(null);

  const [deleteTarget, setDeleteTarget] = useState<QuestionType | null>(null);
  const [deleting, setDeleting] = useState(false);

  const [bulkModalOpen, setBulkModalOpen] = useState(false);
  const [bulkQuestions, setBulkQuestions] = useState<BulkQuestionItem[]>([]);
  const [bulkBookId, setBulkBookId] = useState("");
  const [bulkDefaultDifficulty, setBulkDefaultDifficulty] = useState("medium");
  const [bulkDefaultYear, setBulkDefaultYear] = useState(String(new Date().getFullYear()));
  const [bulkDefaultMonth, setBulkDefaultMonth] = useState("");
  const [bulkSaving, setBulkSaving] = useState(false);

  const bulkFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    Promise.all([getBooks(), getQuestions(), getTopics()])
      .then(([b, q, t]) => {
        setBooks(b);
        setQuestions(q);
        setTopics(t);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(
    () =>
      questions.filter((question) => {
        return (
          (difficulty === "all" || question.difficulty === difficulty) &&
          (year === "all" || String(question.yearAppeared) === year) &&
          (month === "all" || String(question.monthAppeared) === month) &&
          (bookFilter === "all" || question.bookId === bookFilter) &&
          (topicFilter === "all" || String(question.topicId) === topicFilter)
        );
      }),
    [questions, difficulty, year, month, bookFilter, topicFilter],
  );

  const handleAddOption = () => {
    setOptions([...options, { text: "", isCorrect: false, choiceId: 0 }]);
  };

  const handleRemoveOption = (index: number) => {
    if (options.length > 1) {
      const removed = options[index];
      if (removed.imagePreview) URL.revokeObjectURL(removed.imagePreview);
      const newOptions = options.filter((_, i) => i !== index);
      setOptions(newOptions);
    }
  };

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index].text = value;
    setOptions(newOptions);
  };

  const handleChoiceImageChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newOptions = [...options];
      if (newOptions[index].imagePreview) URL.revokeObjectURL(newOptions[index].imagePreview!);
      newOptions[index].imageFile = file;
      newOptions[index].imagePreview = URL.createObjectURL(file);
      setOptions(newOptions);
    }
  };

  const clearChoiceImage = (index: number) => {
    const newOptions = [...options];
    if (newOptions[index].imagePreview) URL.revokeObjectURL(newOptions[index].imagePreview!);
    newOptions[index].imageFile = null;
    newOptions[index].imagePreview = "";
    newOptions[index].existingImageUrl = undefined;
    setOptions(newOptions);
  };

  const handleSetCorrect = (index: number) => {
    const newOptions = options.map((opt, i) => ({
      ...opt,
      isCorrect: i === index
    }));
    setOptions(newOptions);
  };

  const handleQuestionImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setQuestionImageFile(file);
      setQuestionImagePreview(URL.createObjectURL(file));
    }
  };

  const handleExplanationImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setExplanationImageFile(file);
      setExplanationImagePreview(URL.createObjectURL(file));
    }
  };

  const clearQuestionImage = () => {
    setQuestionImageFile(null);
    setQuestionImagePreview("");
    if (questionImageInputRef.current) {
      questionImageInputRef.current.value = "";
    }
  };

  const clearExplanationImage = () => {
    setExplanationImageFile(null);
    setExplanationImagePreview("");
    if (explanationImageInputRef.current) {
      explanationImageInputRef.current.value = "";
    }
  };

  const handleSave = async () => {
    if (!selectedBookId || saving) return;
    if (!qText.trim() && !questionImageFile && !questionImagePreview) {
      setError(t("pleaseProvideQuestionText"));
      return;
    }
    const validOptions = options.filter(o => o.text.trim() || o.imageFile || o.imagePreview || o.existingImageUrl);
    if (validOptions.length === 0) {
      setError(t("pleaseAddChoice"));
      return;
    }
    if (!validOptions.some(o => o.isCorrect)) {
      setError(t("pleaseSelectCorrectAnswer"));
      return;
    }

    setSaving(true);
    setError("");
    try {
      const choices = validOptions.map((o, i) => ({
        id: o.choiceId || 0,
        text: o.text || String.fromCharCode(65 + i),
        isCorrect: o.isCorrect
      }));

      let savedQ: QuestionType;
      const existingQuestionImageUrl = editingId ? questions.find(q => q.id === editingId)?.questionImageUrl : undefined;
      const existingExplanationImageUrl = editingId ? questions.find(q => q.id === editingId)?.expanationImageUrl : undefined;

      if (editingId) {
        savedQ = await updateQuestion(editingId, {
          content: qText,
          difficulty: newDifficulty as any,
          yearAppeared: parseInt(newYear, 10),
          monthAppeared: newMonth ? parseInt(newMonth, 10) : undefined,
          explanation,
          questionImageUrl: existingQuestionImageUrl,
          expanationImageUrl: existingExplanationImageUrl,
          topicId: selectedTopicId ? Number(selectedTopicId) : undefined,
          choices
        });
        
        if (questionImageFile) {
          await uploadQuestionImage(savedQ.id, questionImageFile);
        }
        if (explanationImageFile) {
          await uploadExplanationImage(savedQ.id, explanationImageFile);
        }
        
        const updated = await getQuestions();
        setQuestions(updated);
      } else {
        savedQ = await createQuestion({
          text: qText,
          choices,
          difficulty: newDifficulty,
          yearAppeared: parseInt(newYear, 10),
          monthAppeared: newMonth ? parseInt(newMonth, 10) : undefined,
          explanation,
          topicId: selectedTopicId ? Number(selectedTopicId) : undefined
        } as any);

        if (questionImageFile) {
          await uploadQuestionImage(savedQ.id, questionImageFile);
        }
        if (explanationImageFile) {
          await uploadExplanationImage(savedQ.id, explanationImageFile);
        }

        await addQuestionToBook(savedQ.id, selectedBookId);
        
        const updated = await getQuestions();
        setQuestions(updated);
      }

      // Upload choice images — match by index order since savedQ.options is in the same order as validOptions
      for (let i = 0; i < validOptions.length; i++) {
        const opt = validOptions[i];
        if (opt.imageFile) {
          const savedChoice = savedQ.options[i];
          if (savedChoice) {
            await uploadChoiceImage(savedQ.id, Number(savedChoice.id), opt.imageFile);
          }
        }
      }

      resetForm();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteQuestion(deleteTarget.id);
      setQuestions(prev => prev.filter(q => q.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setDeleting(false);
    }
  };

  const handleEdit = (q: QuestionType) => {
    setEditingId(q.id);
    setQText(q.content || "");
    setOptions(q.options.length > 0
      ? q.options.map(o => ({
          text: o.content || o.label,
          isCorrect: o.label === q.correctAnswer,
          choiceId: Number(o.id),
          existingImageUrl: o.imageUrl,
        }))
      : [{ text: "", isCorrect: false, choiceId: 0 }]
    );
    setExplanation(q.explanation || "");
    setQuestionImagePreview(q.questionImageUrl || "");
    setQuestionImageFile(null);
    setExplanationImagePreview(q.expanationImageUrl || "");
    setExplanationImageFile(null);
    setNewDifficulty(q.difficulty);
    setNewYear(String(q.yearAppeared));
    setNewMonth(q.monthAppeared ? String(q.monthAppeared) : "");
    setSelectedBookId(q.bookId || "");
    setSelectedTopicId(q.topicId ? String(q.topicId) : "");
  };

  const resetForm = () => {
    setEditingId(null);
    setQText("");
    options.forEach(o => { if (o.imagePreview) URL.revokeObjectURL(o.imagePreview); });
    setOptions([{ text: "", isCorrect: false, choiceId: 0 }]);
    setExplanation("");
    setQuestionImageFile(null);
    setQuestionImagePreview("");
    setExplanationImageFile(null);
    setExplanationImagePreview("");
    setNewDifficulty("medium");
    setNewMonth("");
    setSelectedBookId("");
    setSelectedTopicId("");
    setShowQuestionPreview(false);
    if (questionImageInputRef.current) questionImageInputRef.current.value = "";
    if (explanationImageInputRef.current) explanationImageInputRef.current.value = "";
  };

  const getBookTitle = (id?: string) => books.find(b => b.id === id)?.title || "-";

  /* ---- Bulk upload handlers ---- */

  const readFileAsText = (file: File) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => resolve(String(event.target?.result ?? ""));
    reader.onerror = () => reject(reader.error ?? new Error("Failed to read file"));
    reader.readAsText(file);
  });

  const readFileAsArrayBuffer = (file: File) => new Promise<ArrayBuffer>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => resolve(event.target?.result as ArrayBuffer);
    reader.onerror = () => reject(reader.error ?? new Error("Failed to read file"));
    reader.readAsArrayBuffer(file);
  });

  const buildBulkItems = (rows: any[]) => {
    if (!Array.isArray(rows)) throw new Error("File must contain an array of questions");
    return rows.filter((raw: any) => raw && Object.values(raw).some(value => String(value ?? "").trim())).map((raw: any, index: number) => {
      const normalized = raw || {};
      const choiceKeys = Object.keys(normalized).filter(k => /^choice[A-Z]$/i.test(k)).sort((a, b) => a.localeCompare(b));
      const answerLetter = String(normalized.answerLetter || normalized.correctAnswer || "").trim().toUpperCase();
      const choices = choiceKeys.map((key, i) => ({
        id: i,
        text: normalizeBulkText(normalized[key] || ""),
        isCorrect: answerLetter === key.replace(/^choice/i, "").toUpperCase()
      }));
      return {
        id: index,
        questionText: normalizeBulkText(normalized.questionText || normalized.question || normalized.text || ""),
        choices,
        questionImageFile: null,
        questionImagePreview: "",
        explanation: normalizeBulkText(normalized.explanation || ""),
        explanationImageFile: null,
        explanationImagePreview: "",
      };
    });
  };

  const normalizeBulkText = (value: unknown) => String(value ?? "")
    .replace(/\f/g, "\\f")
    .replace(/\x08/g, "\\b")
    .replace(/\r/g, "\\r")
    .replace(/\t/g, "\\t");

  const extractBracketedExpression = (source: string, assignmentName: string) => {
    const assignmentIndex = source.search(new RegExp(`\\b${assignmentName}\\s*=`));
    if (assignmentIndex === -1) throw new Error(`Could not find ${assignmentName} = [...]`);

    const start = source.indexOf("[", assignmentIndex);
    if (start === -1) throw new Error(`Could not find ${assignmentName} array`);

    let depth = 0;
    let quote: string | null = null;
    let escaped = false;
    for (let i = start; i < source.length; i++) {
      const char = source[i];

      if (quote) {
        if (escaped) {
          escaped = false;
        } else if (char === "\\") {
          escaped = true;
        } else if (char === quote) {
          quote = null;
        }
        continue;
      }

      if (char === '"' || char === "'") {
        quote = char;
      } else if (char === "[") {
        depth++;
      } else if (char === "]") {
        depth--;
        if (depth === 0) return source.slice(start, i + 1);
      }
    }

    throw new Error(`Could not parse ${assignmentName} array`);
  };

  const stripPythonComments = (source: string) => {
    let result = "";
    let quote: string | null = null;
    let escaped = false;
    for (let i = 0; i < source.length; i++) {
      const char = source[i];

      if (quote) {
        result += char;
        if (escaped) {
          escaped = false;
        } else if (char === "\\") {
          escaped = true;
        } else if (char === quote) {
          quote = null;
        }
        continue;
      }

      if (char === '"' || char === "'") {
        quote = char;
        result += char;
      } else if (char === "#") {
        while (i < source.length && source[i] !== "\n") i++;
        result += "\n";
      } else {
        result += char;
      }
    }
    return result;
  };

  const parsePythonQuestions = (source: string) => {
    const arraySource = stripPythonComments(extractBracketedExpression(source, "questions"))
      .replace(/\bNone\b/g, "null")
      .replace(/\bTrue\b/g, "true")
      .replace(/\bFalse\b/g, "false")
      .replace(/,\s*([}\]])/g, "$1");
    return JSON.parse(arraySource);
  };

  const parseSpreadsheetRows = async (file: File) => {
    const extension = file.name.split(".").pop()?.toLowerCase();
    const workbook = extension === "csv"
      ? XLSX.read(await readFileAsText(file), { type: "string" })
      : XLSX.read(await readFileAsArrayBuffer(file), { type: "array" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    return XLSX.utils.sheet_to_json(sheet, { defval: "" });
  };

  const handleBulkFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const extension = file.name.split(".").pop()?.toLowerCase();
    const parse = async () => {
      try {
        const supportedExtensions = new Set(["json", "csv", "xlsx", "xls", "py"]);
        if (!extension || !supportedExtensions.has(extension)) {
          setError("Unsupported bulk file type. Upload .json, .csv, .xlsx, .xls, or .py.");
          return;
        }

        const rows = extension === "json"
          ? JSON.parse(await readFileAsText(file))
          : extension === "py"
            ? parsePythonQuestions(await readFileAsText(file))
            : await parseSpreadsheetRows(file);
        if (extension === "json" && !Array.isArray(rows)) {
          setError("JSON must be an array of questions");
          return;
        }
        const items: BulkQuestionItem[] = buildBulkItems(rows);
        setBulkQuestions(items);
        setBulkModalOpen(true);
        setError("");
      } catch (err: any) {
        setError(`Invalid ${extension?.toUpperCase() || "bulk"} file: ${err.message}`);
      }
    };
    void parse();
    if (bulkFileInputRef.current) bulkFileInputRef.current.value = "";
  };

  const updateBulkQuestion = (id: number, patch: Partial<BulkQuestionItem>) => {
    setBulkQuestions(prev => prev.map(q => q.id === id ? { ...q, ...patch } : q));
  };

  const handleBulkImageChange = (id: number, file: File | null) => {
    updateBulkQuestion(id, {
      questionImageFile: file,
      questionImagePreview: file ? URL.createObjectURL(file) : "",
    });
  };

  const handleBulkExplanationImageChange = (id: number, file: File | null) => {
    updateBulkQuestion(id, {
      explanationImageFile: file,
      explanationImagePreview: file ? URL.createObjectURL(file) : "",
    });
  };

  const clearBulkQuestionImage = (id: number) => {
    updateBulkQuestion(id, { questionImageFile: null, questionImagePreview: "" });
  };

  const clearBulkExplanationImage = (id: number) => {
    updateBulkQuestion(id, { explanationImageFile: null, explanationImagePreview: "" });
  };

  const addBulkChoice = (questionId: number) => {
    setBulkQuestions(prev => prev.map(q =>
      q.id === questionId
        ? { ...q, choices: [...q.choices, { id: q.choices.length, text: "", isCorrect: false }] }
        : q
    ));
  };

  const removeBulkChoice = (questionId: number, choiceIndex: number) => {
    setBulkQuestions(prev => prev.map(q =>
      q.id === questionId
        ? { ...q, choices: q.choices.filter((_, i) => i !== choiceIndex) }
        : q
    ));
  };

  const setBulkCorrect = (questionId: number, choiceIndex: number) => {
    setBulkQuestions(prev => prev.map(q =>
      q.id === questionId
        ? { ...q, choices: q.choices.map((c, i) => ({ ...c, isCorrect: i === choiceIndex })) }
        : q
    ));
  };

  const getLatexError = (text: string) => {
    const regex = /\$\$([\s\S]+?)\$\$|\$([^\$]+?)\$/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
      try {
        katex.renderToString(match[1] || match[2], {
          displayMode: Boolean(match[1]),
          throwOnError: true,
        });
      } catch {
        return "Invalid LaTeX";
      }
    }
    return "";
  };

  const getBulkQuestionLatexError = (item: BulkQuestionItem) => {
    const questionError = getLatexError(item.questionText);
    if (questionError) return questionError;
    const choiceError = item.choices.find(choice => getLatexError(choice.text));
    if (choiceError) return "Invalid LaTeX";
    return getLatexError(item.explanation);
  };

  const openBulkPreview = (item: BulkQuestionItem, index: number) => {
    setPreviewQuestion({
      title: `Question ${index + 1} Preview`,
      questionText: item.questionText,
      choices: item.choices,
      questionImageUrl: item.questionImagePreview,
      explanation: item.explanation,
      explanationImageUrl: item.explanationImagePreview,
    });
  };

  const resetBulkModal = () => {
    setBulkModalOpen(false);
    setBulkQuestions([]);
    setBulkBookId("");
    setBulkDefaultDifficulty("medium");
    setBulkDefaultYear(String(new Date().getFullYear()));
    setBulkDefaultMonth("");
    setBulkSaving(false);
    setPreviewQuestion(null);
  };

  const handleBulkSave = async () => {
    if (!bulkBookId) { setError("Please select a book"); return; }
    setBulkSaving(true);
    let successCount = 0;
    let failCount = 0;
    for (const item of bulkQuestions) {
      try {
        const validChoices = item.choices.filter(c => c.text.trim());
        if (!item.questionText.trim() || validChoices.length === 0 || !validChoices.some(c => c.isCorrect)) { failCount++; continue; }
        const created = await createQuestion({
          text: item.questionText,
          choices: validChoices.map(c => ({ text: c.text, isCorrect: c.isCorrect })),
          difficulty: bulkDefaultDifficulty,
          yearAppeared: parseInt(bulkDefaultYear, 10),
          monthAppeared: bulkDefaultMonth ? parseInt(bulkDefaultMonth, 10) : undefined,
          explanation: item.explanation,
        });
        if (item.questionImageFile) await uploadQuestionImage(created.id, item.questionImageFile);
        if (item.explanationImageFile) await uploadExplanationImage(created.id, item.explanationImageFile);
        await addQuestionToBook(created.id, bulkBookId);
        successCount++;
      } catch { failCount++; }
    }
    const updated = await getQuestions();
    setQuestions(updated);
    setBulkSaving(false);
    resetBulkModal();
    if (failCount === 0) {
      alert(`Successfully created ${successCount} question(s)!`);
    } else {
      alert(`Created ${successCount} question(s), ${failCount} failed.`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-ziad-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
        <p className="text-xs font-bold uppercase text-ziad-primary">{t("questions")}</p>
        <h1 className="text-3xl font-extrabold text-ziad-ink">{t("questionBank")}</h1>
        <p className="mt-2 text-sm text-ziad-ink/62">{t("addQuestionsToBooks")}</p>
      </section>

      {error && (
        <div className="rounded-card border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-700">{error}</div>
      )}

      <section className="grid gap-3 rounded-card border border-ziad-line bg-ziad-panel p-4 shadow-sm md:grid-cols-5">
        <select value={bookFilter} onChange={(event) => setBookFilter(event.target.value)} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-bold">
          <option value="all">{t("allBooks")}</option>
          {books.map((book) => <option key={book.id} value={book.id}>{book.title}</option>)}
        </select>
        <select value={difficulty} onChange={(event) => setDifficulty(event.target.value)} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-bold">
          <option value="all">{t("allDifficulty")}</option>
          {["easy", "medium", "hard"].map(d => <option key={d} value={d} className="capitalize">{d}</option>)}
        </select>
        <input type="text" value={year === "all" ? "" : year} onChange={(e) => setYear(e.target.value || "all")} placeholder={t("yearPlaceholder")} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-bold outline-none focus:border-ziad-primary" />
        <select value={month} onChange={(e) => setMonth(e.target.value)} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-bold">
          <option value="all">{t("allMonths")}</option>
          {Array.from({ length: 12 }, (_, i) => i + 1).map(m => <option key={m} value={m}>{m}</option>)}
        </select>
        <select value={topicFilter} onChange={(e) => setTopicFilter(e.target.value)} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-bold">
          <option value="all">{t("selectTopic")}</option>
          {topics.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </section>

      <section className="flex flex-wrap items-center gap-3 rounded-card border border-ziad-line bg-ziad-panel p-4 shadow-sm">
        <input ref={bulkFileInputRef} type="file" accept=".json,.csv,.xlsx,.xls,.py" onChange={handleBulkFileSelect} className="hidden" />
        <button type="button" onClick={() => bulkFileInputRef.current?.click()} className="flex items-center gap-2 rounded-button bg-ziad-primary px-4 py-2 text-sm font-extrabold text-ziad-light hover:bg-ziad-ink transition">
          <Upload className="h-4 w-4" /> {t("bulkUpload")}
        </button>
        <span className="text-xs font-medium text-ziad-ink/70">{t("bulkUploadHint")}</span>
      </section>

      <div className="grid gap-4 xl:grid-cols-[1fr_420px]">
        <section className="table-scroll overflow-x-auto rounded-card border border-ziad-line bg-ziad-panel shadow-sm">
          <table className="min-w-[600px] w-full text-sm">
            <thead className="bg-ziad-light text-xs uppercase text-ziad-ink/68">
              <tr>
                {[t("questionText"), t("selectBook"), t("selectTopic"), t("allDifficulty"), t("yearPlaceholder"), t("actions")].map((column) => (
                  <th key={column} className="px-4 py-3 text-start font-extrabold">{column}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-ziad-line">
              {filtered.map((question) => (
                <tr key={question.id} className="hover:bg-ziad-light/35 transition-colors">
                  <td className="px-4 py-4 font-semibold text-ziad-ink">
                    <div className="line-clamp-2 flex items-center gap-2">
                      {question.questionImageUrl && <ImageIcon className="h-4 w-4 text-ziad-primary shrink-0" />}
                      <span dangerouslySetInnerHTML={{ __html: question.content || "" }} />
                    </div>
                  </td>
                  <td className="px-4 py-4 text-ziad-ink/68">{getBookTitle(question.bookId)}</td>
                  <td className="px-4 py-4 text-ziad-ink/68">{question.topic?.name || "-"}</td>
                  <td className="px-4 py-4 font-bold capitalize text-ziad-ink">{question.difficulty}</td>
                  <td className="px-4 py-4 text-ziad-ink/68">{question.yearAppeared}{question.monthAppeared ? `-${question.monthAppeared}` : ''}</td>
                  <td className="px-4 py-4">
                    <div className="flex gap-2">
                      <button onClick={() => handleEdit(question)} title="Edit" className="p-1.5 text-ziad-primary hover:bg-ziad-primary/10 rounded-lg transition">
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button onClick={() => setDeleteTarget(question)} title="Delete" className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="rounded-card border border-ziad-line bg-ziad-panel p-4 shadow-sm self-start sticky top-5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold uppercase text-ziad-primary">{editingId ? t("updateQuestion") : t("saveQuestion")}</p>
            {editingId && (
              <button onClick={resetForm} className="text-xs font-bold text-red-600 hover:underline">{t("actionCancel")}</button>
            )}
          </div>
          
          <div className="mt-3 space-y-3">
            <div>
              <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">{t("selectBook")}</label>
              <select 
                value={selectedBookId} 
                onChange={(e) => setSelectedBookId(e.target.value)} 
                className="h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
              >
                <option value="">{t("selectBook")}</option>
                {books.map(b => <option key={b.id} value={b.id}>{b.title}</option>)}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">{t("selectTopic")}</label>
              <select 
                value={selectedTopicId} 
                onChange={(e) => setSelectedTopicId(e.target.value)} 
                className="h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
              >
                <option value="">{t("noTopic")}</option>
                {topics.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>

            <div>
              <div className="mb-1 flex items-center justify-between gap-2">
                <label className="text-[10px] font-bold uppercase text-ziad-ink/70">{t("questionText")}</label>
                <button
                  type="button"
                  onClick={() => setShowQuestionPreview(value => !value)}
                  className="inline-flex items-center gap-1 rounded-button border border-ziad-line bg-white px-2.5 py-1 text-xs font-bold text-ziad-primary transition hover:border-ziad-primary hover:bg-ziad-light"
                >
                  <Eye className="h-3.5 w-3.5" />
                  {showQuestionPreview ? "Hide Preview" : "Show Preview"}
                </button>
              </div>
              <textarea 
                rows={3} 
                value={qText} 
                onChange={(e) => setQText(e.target.value)} 
                placeholder={t("enterQuestionText")} 
                className="w-full rounded-card border border-ziad-line bg-white p-3 text-sm font-semibold outline-none focus:border-ziad-primary" 
              />
            </div>

            {showQuestionPreview ? (
              <QuestionLatexPreview
                title={editingId ? "Updated Question Preview" : "New Question Preview"}
                questionText={qText}
                choices={options}
                questionImageUrl={questionImagePreview || (editingId ? questions.find(q => q.id === editingId)?.questionImageUrl : "")}
                explanation={explanation}
                explanationImageUrl={explanationImagePreview || (editingId ? questions.find(q => q.id === editingId)?.expanationImageUrl : "")}
              />
            ) : null}

            <div>
              <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">{t("orUploadQuestionImage")}</label>
              <input
                ref={questionImageInputRef}
                type="file"
                accept="image/*"
                onChange={handleQuestionImageChange}
                className="w-full text-sm"
              />
              {(questionImagePreview || (editingId && questions.find(q => q.id === editingId)?.questionImageUrl)) && (
                <div className="mt-2 relative inline-block">
                  <img 
                    src={questionImagePreview || questions.find(q => q.id === editingId)?.questionImageUrl} 
                    alt={t("questionPreview")} 
                    loading="lazy"
                    onError={(e) => { e.currentTarget.style.display = "none"; }}
                    className="h-20 rounded border border-ziad-line object-contain bg-white"
                  />
                  <button 
                    onClick={clearQuestionImage}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">{t("choicesSelectCorrect")}</label>
              <div className="space-y-2">
                {options.map((opt, i) => (
                  <div key={i} className="space-y-1">
                    <div className="flex gap-2 items-center">
                      <button
                        type="button"
                        onClick={() => handleSetCorrect(i)}
                        className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold text-sm transition shrink-0 ${
                          opt.isCorrect 
                            ? "bg-green-500 border-green-500 text-white" 
                            : "border-ziad-line text-ziad-ink/65 hover:border-ziad-primary"
                        }`}
                      >
                        {String.fromCharCode(65 + i)}
                      </button>
                      <input 
                        value={opt.text}
                        onChange={(e) => handleOptionChange(i, e.target.value)}
                        placeholder={t("choiceLetter").replace("{letter}", String.fromCharCode(65 + i))}
                        className="flex-1 h-9 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary"
                      />
                      {!opt.text.trim() && !opt.imageFile && !opt.imagePreview && !opt.existingImageUrl ? (
                        <span className="text-[10px] font-bold text-red-500 bg-red-50 px-2 py-1 rounded shrink-0">Invalid</span>
                      ) : null}
                      {options.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveOption(i)}
                          className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition shrink-0"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                    <div className="flex items-center gap-2 ml-10">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleChoiceImageChange(i, e)}
                        className="w-full text-xs"
                      />
                      {(opt.imagePreview || opt.existingImageUrl) && (
                        <div className="relative inline-block shrink-0">
                          <img 
                            src={opt.imagePreview || opt.existingImageUrl} 
                            alt="" 
                            loading="lazy"
                            onError={(e) => { e.currentTarget.style.display = "none"; }}
                            className="h-10 rounded border border-ziad-line object-contain bg-white"
                          />
                          <button 
                            onClick={() => clearChoiceImage(i)}
                            className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600"
                          >
                            <X className="h-2.5 w-2.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={handleAddOption}
                  className="flex items-center gap-1 text-sm font-bold text-ziad-primary hover:text-ziad-ink"
                >
                  <Plus className="h-4 w-4" /> {t("addChoice")}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <select value={newDifficulty} onChange={(e) => setNewDifficulty(e.target.value)} className="h-10 w-full rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary">
                <option value="easy">{t("difficultyEasy")}</option>
                <option value="medium">{t("difficultyMedium")}</option>
                <option value="hard">{t("difficultyHard")}</option>
              </select>
              <div className="flex gap-2">
                <input type="number" value={newYear} onChange={(e) => setNewYear(e.target.value)} placeholder={t("yearPlaceholder")} className="h-10 flex-1 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary" />
                <input type="number" min="1" max="12" value={newMonth} onChange={(e) => setNewMonth(e.target.value)} placeholder={t("monthPlaceholder")} className="h-10 flex-1 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary" />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">{t("explanationLabel")}</label>
              <textarea 
                rows={2} 
                value={explanation} 
                onChange={(e) => setExplanation(e.target.value)} 
                placeholder={t("explanationOptional")} 
                className="w-full rounded-card border border-ziad-line bg-white p-3 text-sm font-semibold outline-none focus:border-ziad-primary" 
              />
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">{t("orUploadExplanationImage")}</label>
              <input
                ref={explanationImageInputRef}
                type="file"
                accept="image/*"
                onChange={handleExplanationImageChange}
                className="w-full text-sm"
              />
              {(explanationImagePreview || (editingId && questions.find(q => q.id === editingId)?.expanationImageUrl)) && (
                <div className="mt-2 relative inline-block">
                  <img 
                    src={explanationImagePreview || questions.find(q => q.id === editingId)?.expanationImageUrl} 
                    alt={t("explanationPreview")} 
                    loading="lazy"
                    onError={(e) => { e.currentTarget.style.display = "none"; }}
                    className="h-20 rounded border border-ziad-line object-contain bg-white"
                  />
                  <button 
                    onClick={clearExplanationImage}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
            </div>

            <button 
              type="button" 
              onClick={handleSave} 
              disabled={saving || !selectedBookId}
              className="w-full rounded-button bg-ziad-primary px-4 py-2 text-sm font-extrabold text-ziad-light hover:bg-ziad-ink disabled:opacity-50"
            >
              {saving ? t("savingDots") : (editingId ? t("updateQuestion") : t("saveQuestion"))}
            </button>
          </div>
        </section>
      </div>

      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ animation: "fadeIn 0.2s ease-out" }}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => !deleting && setDeleteTarget(null)} />
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl" style={{ animation: "scaleIn 0.25s ease-out" }}>
            <button onClick={() => !deleting && setDeleteTarget(null)} className="absolute right-4 top-4 p-1 text-gray-600 hover:text-gray-800 rounded-full hover:bg-gray-100 transition">
              <X className="h-5 w-5" />
            </button>
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-red-100">
              <AlertTriangle className="h-7 w-7 text-red-600" />
            </div>
            <div className="mt-4 text-center">
              <h3 className="text-lg font-bold text-gray-900">{t("deleteQuestion")}</h3>
              <p className="mt-2 text-sm font-medium text-gray-700">
                {t("deleteQuestionConfirm")}
              </p>
              <div className="mt-3 rounded-lg bg-gray-50 border border-gray-100 p-3 text-sm font-medium text-gray-700 text-start">
                <div className="line-clamp-2" dangerouslySetInnerHTML={{ __html: deleteTarget.content || "" }} />
              </div>
            </div>
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setDeleteTarget(null)}
                disabled={deleting}
                className="flex-1 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-bold text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
              >
                {t("actionCancel")}
              </button>
              <button
                onClick={confirmDelete}
                disabled={deleting}
                className="flex-1 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-red-700 transition disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                {deleting ? t("deletingDots") : t("deleteQuestion")}
              </button>
            </div>
          </div>
        </div>
      )}

      {bulkModalOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 overflow-y-auto" style={{ animation: "fadeIn 0.2s ease-out" }}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => !bulkSaving && setBulkModalOpen(false)} />
          <div className="relative w-full max-w-3xl my-8 rounded-2xl bg-white p-6 shadow-2xl" style={{ animation: "scaleIn 0.25s ease-out" }}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-extrabold text-ziad-ink">Bulk Upload Questions ({bulkQuestions.length})</h2>
              <button onClick={() => { if (!bulkSaving) { resetBulkModal(); } }} className="p-1 text-gray-600 hover:text-gray-800 rounded-full hover:bg-gray-100 transition">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-4 gap-3 p-4 bg-gray-50 rounded-xl mb-4">
              <select value={bulkBookId} onChange={(e) => setBulkBookId(e.target.value)} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary">
                <option value="">{t("selectBook")}</option>
                {books.map(b => <option key={b.id} value={b.id}>{b.title}</option>)}
              </select>
              <select value={bulkDefaultDifficulty} onChange={(e) => setBulkDefaultDifficulty(e.target.value)} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary">
                <option value="easy">{t("difficultyEasy")}</option>
                <option value="medium">{t("difficultyMedium")}</option>
                <option value="hard">{t("difficultyHard")}</option>
              </select>
              <input type="number" value={bulkDefaultYear} onChange={(e) => setBulkDefaultYear(e.target.value)} placeholder={t("yearPlaceholder")} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary" />
              <input type="number" min="1" max="12" value={bulkDefaultMonth} onChange={(e) => setBulkDefaultMonth(e.target.value)} placeholder={t("monthPlaceholder")} className="h-10 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary" />
            </div>

            <div className="mb-4 overflow-x-auto rounded-xl border border-ziad-line">
              <table className="min-w-[620px] w-full text-sm">
                <thead className="bg-ziad-light text-left text-[10px] font-bold uppercase text-ziad-ink/65">
                  <tr>
                    <th className="px-3 py-2">#</th>
                    <th className="px-3 py-2">Question</th>
                    <th className="px-3 py-2">Choices</th>
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2 text-right">Preview</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ziad-line bg-white">
                  {bulkQuestions.map((q, qi) => {
                    const latexError = getBulkQuestionLatexError(q);
                    const structurallyValid = Boolean(q.questionText.trim() && q.choices.filter(c => c.text.trim()).length > 0 && q.choices.some(c => c.isCorrect));
                    const valid = structurallyValid && !latexError;
                    return (
                      <tr key={q.id}>
                        <td className="px-3 py-2 text-xs font-extrabold text-ziad-primary">Q{qi + 1}</td>
                        <td className="max-w-[260px] px-3 py-2 font-semibold text-ziad-ink">
                          <div className="line-clamp-2 leading-6">
                            {q.questionText
                              ? latexError
                                ? q.questionText
                                : <LatexRenderer text={q.questionText} throwOnError />
                              : "No question text"}
                          </div>
                        </td>
                        <td className="px-3 py-2 text-xs font-bold text-ziad-ink/65">{q.choices.filter(c => c.text.trim()).length}</td>
                        <td className="px-3 py-2">
                          <span className={`rounded-full px-2 py-1 text-[10px] font-bold ${valid ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
                            {valid ? "Valid" : latexError || "Needs review"}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-right">
                          <button
                            type="button"
                            onClick={() => openBulkPreview(q, qi)}
                            className="inline-flex items-center gap-1 rounded-button border border-ziad-line bg-white px-2.5 py-1.5 text-xs font-bold text-ziad-primary transition hover:border-ziad-primary hover:bg-ziad-light"
                            aria-label={`View question ${qi + 1} preview`}
                          >
                            <Eye className="h-3.5 w-3.5" />
                            View
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-1">
              {bulkQuestions.map((q, qi) => (
                <div key={q.id} className="border border-ziad-line rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase text-ziad-primary">Q{qi + 1}</span>
                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => openBulkPreview(q, qi)} className="inline-flex items-center gap-1 rounded-button border border-ziad-line bg-white px-2 py-1 text-[10px] font-bold text-ziad-primary transition hover:border-ziad-primary hover:bg-ziad-light">
                        <Eye className="h-3 w-3" />
                        View
                      </button>
                      {q.choices.some(c => c.isCorrect) && <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded">Correct: {String.fromCharCode(65 + q.choices.findIndex(c => c.isCorrect))}</span>}
                    </div>
                  </div>
                  <textarea rows={2} value={q.questionText} onChange={(e) => updateBulkQuestion(q.id, { questionText: e.target.value })} placeholder="Question text" className="w-full rounded-card border border-ziad-line bg-white p-3 text-sm font-semibold outline-none focus:border-ziad-primary" />
                  <div className="space-y-1.5">
                    {q.choices.map((c, ci) => (
                      <div key={ci} className="flex gap-2 items-center">
                        <button type="button" onClick={() => setBulkCorrect(q.id, ci)} className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold text-sm transition ${c.isCorrect ? "bg-green-500 border-green-500 text-white" : "border-ziad-line text-ziad-ink/65 hover:border-ziad-primary"}`}>{String.fromCharCode(65 + ci)}</button>
                        <input value={c.text} onChange={(e) => setBulkQuestions(prev => prev.map(bq => bq.id === q.id ? { ...bq, choices: bq.choices.map((bc, bci) => bci === ci ? { ...bc, text: e.target.value } : bc) } : bq))} placeholder={`Choice ${String.fromCharCode(65 + ci)}`} className="flex-1 h-9 rounded-button border border-ziad-line bg-white px-3 text-sm font-semibold outline-none focus:border-ziad-primary" />
                        {q.choices.length > 1 && <button type="button" onClick={() => removeBulkChoice(q.id, ci)} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition"><Trash2 className="h-4 w-4" /></button>}
                      </div>
                    ))}
                    <button type="button" onClick={() => addBulkChoice(q.id)} className="flex items-center gap-1 text-sm font-bold text-ziad-primary hover:text-ziad-ink"><Plus className="h-4 w-4" /> Add choice</button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">Question Image</label>
                      <input type="file" accept="image/*" onChange={(e) => handleBulkImageChange(q.id, e.target.files?.[0] || null)} className="w-full text-sm" />
                      {q.questionImagePreview && <div className="mt-1 relative inline-block"><img src={q.questionImagePreview} alt="" className="h-16 rounded border border-ziad-line object-contain bg-white" /><button onClick={() => clearBulkQuestionImage(q.id)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600"><X className="h-3 w-3" /></button></div>}
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">Explanation</label>
                      <textarea rows={2} value={q.explanation} onChange={(e) => updateBulkQuestion(q.id, { explanation: e.target.value })} placeholder="Explanation (optional)" className="w-full rounded-card border border-ziad-line bg-white p-3 text-sm font-semibold outline-none focus:border-ziad-primary" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase text-ziad-ink/70 mb-1 block">Explanation Image</label>
                    <input type="file" accept="image/*" onChange={(e) => handleBulkExplanationImageChange(q.id, e.target.files?.[0] || null)} className="w-full text-sm" />
                    {q.explanationImagePreview && <div className="mt-1 relative inline-block"><img src={q.explanationImagePreview} alt="" className="h-16 rounded border border-ziad-line object-contain bg-white" /><button onClick={() => clearBulkExplanationImage(q.id)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600"><X className="h-3 w-3" /></button></div>}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 flex gap-3 justify-end pt-4 border-t border-ziad-line">
              <button type="button" onClick={resetBulkModal} disabled={bulkSaving} className="rounded-xl border border-gray-200 bg-white px-5 py-2.5 text-sm font-bold text-gray-700 hover:bg-gray-50 transition disabled:opacity-50">{t("actionCancel")}</button>
              <button type="button" onClick={handleBulkSave} disabled={bulkSaving || !bulkBookId} className="rounded-xl bg-ziad-primary px-5 py-2.5 text-sm font-extrabold text-ziad-light hover:bg-ziad-ink transition disabled:opacity-50 flex items-center gap-2">
                {bulkSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                {bulkSaving ? "Saving..." : `Save All (${bulkQuestions.length})`}
              </button>
            </div>
          </div>
        </div>
      )}

      {previewQuestion && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" style={{ animation: "fadeIn 0.2s ease-out" }}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setPreviewQuestion(null)} />
          <div className="relative w-full max-w-2xl" style={{ animation: "scaleIn 0.25s ease-out" }}>
            <QuestionLatexPreview
              title={previewQuestion.title}
              questionText={previewQuestion.questionText}
              choices={previewQuestion.choices}
              questionImageUrl={previewQuestion.questionImageUrl}
              explanation={previewQuestion.explanation}
              explanationImageUrl={previewQuestion.explanationImageUrl}
              onClose={() => setPreviewQuestion(null)}
            />
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95) translateY(8px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
      `}</style>
    </div>
  );
}
