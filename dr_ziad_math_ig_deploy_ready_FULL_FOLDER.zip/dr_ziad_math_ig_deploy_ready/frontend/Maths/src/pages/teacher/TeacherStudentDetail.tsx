import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useI18n } from "../../contexts/I18nContext";
import { ProgressRing } from "../../components/ProgressRing";
import { getBooks, getStudent, updateStudent, UserProfileDto } from "../../lib/api-service";
import type { Book } from "../../lib/types";

export default function TeacherStudentDetail() {
  const { t } = useI18n();
  const { studentId } = useParams();
  const [student, setStudent] = useState<UserProfileDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [booksList, setBooksList] = useState<Book[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");

  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function loadData() {
      if (!studentId) return;
      try {
        const [studentData, booksData] = await Promise.all([
          getStudent(studentId),
          getBooks()
        ]);
        setStudent(studentData);
        setBooksList(booksData);
        setEditName(studentData.name || "");
        setEditPhone(studentData.phone || "");
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [studentId]);

  if (loading) return <p className="p-5 text-ziad-ink/62">{t("loadingStudentProfile")}</p>;
  if (!student) {
    return <p className="rounded-card border border-red-200 bg-red-50 p-4 font-semibold text-red-700">{t("childNotFound")}</p>;
  }

  const mistakes: any[] = [];
  const submissions: any[] = [];

  const handleSave = async () => {
    if (!studentId) return;
    setSaving(true);
    try {
      const updated = await updateStudent(studentId, {
        name: editName,
        phone: editPhone || null,
      });
      setStudent(updated);
      setIsEditing(false);
    } catch (err) {
      console.error(err);
      alert(t("failedToUpdateStudent"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex-1">
            <p className="text-xs font-bold uppercase text-ziad-primary">{t("studentProfileLabel")}</p>
            {!isEditing ? (
              <>
                <h1 className="text-3xl font-extrabold text-ziad-ink">{student.name}</h1>
                <p className="mt-2 text-sm text-ziad-ink/62">{student.phone || t("noPhone")}</p>
              </>
            ) : (
              <div className="space-y-2 mt-2">
                <input value={editName} onChange={e => setEditName(e.target.value)} className="w-full rounded border px-3 py-1 text-lg font-bold" placeholder={t("nameColumn")} />
                <input value={editPhone} onChange={e => setEditPhone(e.target.value)} className="w-full rounded border px-3 py-1 text-sm" placeholder={t("phoneLabel")} />
              </div>
            )}
          </div>
          <div className="flex flex-col items-end gap-2">
            {!isEditing ? (
              <button onClick={() => setIsEditing(true)} className="text-sm font-bold text-ziad-primary hover:underline">{t("editInfo")}</button>
            ) : (
              <div className="flex gap-2">
                <button onClick={() => setIsEditing(false)} className="text-sm font-bold text-ziad-ink/72">{t("actionCancel")}</button>
                <button onClick={handleSave} disabled={saving} className="rounded-button bg-ziad-primary px-3 py-1 text-sm font-bold text-white disabled:opacity-50">{saving ? t("savingDots") : t("actionSave")}</button>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
        <p className="text-xs font-bold uppercase text-ziad-primary">{t("booksProgress")}</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {booksList.map((book) => (
            <div key={book.id} className="rounded-card border border-ziad-line bg-ziad-light/45 p-4">
              <div className="flex items-center justify-between gap-3">
                <h2 className="font-extrabold text-ziad-ink">{book.title}</h2>
                <ProgressRing value={0} size={64} stroke={7} />
              </div>
              <div className="mt-3 space-y-2">
                <p className="text-xs font-medium text-ziad-ink/70 italic">{t("bookProgressApiPending")}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
          <p className="text-xs font-bold uppercase text-ziad-primary">{t("mistakeHistoryDb")}</p>
          <div className="mt-4 space-y-3">
            {mistakes.length === 0 ? (
              <p className="text-sm font-medium text-ziad-ink/72">{t("mistakeHistoryDb")}</p>
            ) : mistakes.map((item) => (
                <div key={item.id} className="rounded-card border border-ziad-line bg-red-50 p-3">
                  {/* ... */}
                </div>
            ))}
          </div>
        </section>

        <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
          <p className="text-xs font-bold uppercase text-ziad-primary">{t("homeworkGrading")}</p>
          <div className="mt-4 space-y-3">
            {submissions.length === 0 ? (
              <p className="text-sm font-medium text-ziad-ink/72">{t("noSubmissionsFound")}</p>
            ) : (
              submissions.map((submission) => (
                <div key={submission.id} className="rounded-card border border-ziad-line bg-ziad-light/45 p-3">
                   {/* ... */}
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
