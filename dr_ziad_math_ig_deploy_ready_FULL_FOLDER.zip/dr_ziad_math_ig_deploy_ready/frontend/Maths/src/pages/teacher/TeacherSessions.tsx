import { useState, useEffect } from "react";
import { Plus, Trash2, FileText, Loader2, Link as LinkIcon } from "lucide-react";
import { useI18n } from "../../contexts/I18nContext";
import { formatDateTime } from "../../lib/utils";
import { getSessions, createSession, addPdfToSession, removePdfFromSession, getCourses } from "../../lib/api-service";
import type { Session } from "../../lib/types";
import type { AdminCourse } from "../../lib/api-service";

export default function TeacherSessions() {
  const { t } = useI18n();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDate, setNewDate] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [newPdf, setNewPdf] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [courses, setCourses] = useState<AdminCourse[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState("");

  useEffect(() => {
    loadSessions();
    getCourses().then(setCourses).catch(console.error);
  }, []);

  async function loadSessions() {
    try {
      setLoading(true);
      const data = await getSessions();
      setSessions(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setSubmitting(true);
    try {
      const session = await createSession({ title: newTitle.trim(), startTime: newDate ? new Date(newDate).toISOString() : new Date().toISOString(), url: newUrl.trim() }, selectedCourseId || undefined);
      
      if (newPdf) {
        await addPdfToSession(session.id.toString(), newPdf, newPdf.name);
      }

      setShowAddModal(false);
      setNewTitle("");
      setNewDate("");
      setNewUrl("");
      setNewPdf(null);
      setSelectedCourseId("");
      await loadSessions();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleUploadPdf(sessionId: string, e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await addPdfToSession(sessionId, file, file.name);
      await loadSessions();
    } catch (err: any) {
      alert(t("failedToUploadPdfMessage").replace("{message}", err.message));
    }
  }

  async function handleDeletePdf(sessionId: string, pdfId: string) {
    if (!confirm(t("deletePdfConfirm"))) return;
    try {
      await removePdfFromSession(sessionId, pdfId);
      await loadSessions();
    } catch (err: any) {
      alert(t("failedToDeletePdfMessage").replace("{message}", err.message));
    }
  }

  return (
    <div className="space-y-5">
      <section className="rounded-card border border-ziad-line bg-ziad-panel p-5 shadow-sm">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-bold uppercase text-ziad-primary">{t("liveSessions")}</p>
            <h1 className="text-3xl font-extrabold text-ziad-ink">{t("sessions")}</h1>
          </div>
          <button onClick={() => setShowAddModal(true)} className="inline-flex h-10 items-center justify-center gap-2 rounded-button bg-ziad-primary px-4 text-sm font-extrabold text-white hover:bg-ziad-ink">
            <Plus className="h-4 w-4" />
            {t("addSession")}
          </button>
        </div>
      </section>

      {error && <div className="rounded-card border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreate} className="w-full max-w-md rounded-card bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-xl font-bold">{t("addNewSession")}</h2>
            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-sm font-bold text-ziad-ink">{t("sessionTitle")}</label>
                <input required value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="h-10 w-full rounded-button border border-ziad-line px-3" />
              </div>
              <div>
                <label className="mb-1 block text-sm font-bold text-ziad-ink">{t("exactDateTime")}</label>
                <input type="datetime-local" value={newDate} onChange={(e) => setNewDate(e.target.value)} className="h-10 w-full rounded-button border border-ziad-line px-3" />
              </div>
              <div>
                <label className="mb-1 block text-sm font-bold text-ziad-ink">{t("courseOptional")}</label>
                <select value={selectedCourseId} onChange={(e) => setSelectedCourseId(e.target.value)} className="h-10 w-full rounded-button border border-ziad-line px-3 bg-white">
                  <option value="">{t("noCourseOption")}</option>
                  {courses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-bold text-ziad-ink">{t("meetingLinkOptional")}</label>
                <input value={newUrl} onChange={(e) => setNewUrl(e.target.value)} className="h-10 w-full rounded-button border border-ziad-line px-3" placeholder={t("meetingLinkOptional")} />
              </div>
              <div>
                <label className="mb-1 block text-sm font-bold text-ziad-ink">{t("attachmentPdf")}</label>
                <input type="file" accept=".pdf" onChange={(e) => setNewPdf(e.target.files?.[0] || null)} className="w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-button file:border-0 file:text-sm file:font-semibold file:bg-ziad-light file:text-ziad-ink hover:file:bg-ziad-line" />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button type="button" onClick={() => { setShowAddModal(false); setNewPdf(null); }} className="rounded-button px-4 py-2 text-sm font-bold border border-ziad-line text-ziad-ink">{t("actionCancel")}</button>
              <button disabled={submitting} type="submit" className="rounded-button bg-ziad-primary px-4 py-2 text-sm font-bold text-white flex items-center gap-2">
                {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                {t("saveSession")}
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-ziad-primary" /></div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {sessions.map((session) => (
            <div key={session.id} className="rounded-card border border-ziad-line bg-white p-5 shadow-sm">
              <h3 className="text-xl font-bold text-ziad-ink">{session.title || session.startTime}</h3>
              <p className="mt-1 text-sm font-medium text-ziad-ink/72">{formatDateTime(session.startTime)}</p>
              
              {session.url && (
                <a href={session.url} target="_blank" rel="noreferrer" className="mt-4 flex items-center gap-2 text-sm font-bold text-blue-600 hover:text-blue-700">
                  <LinkIcon className="h-4 w-4" /> {t("meetingLink")}
                </a>
              )}

              <div className="mt-4 border-t border-ziad-line pt-4">
                <h4 className="mb-2 text-sm font-bold uppercase text-ziad-ink/75">{t("resources")}</h4>
                <div className="space-y-2 mb-3">
                  {session.sessionPDFs?.map((m: any) => (
                     <div key={m.id} className="flex items-center justify-between gap-2 text-sm rounded bg-ziad-light/30 p-2">
                       <div className="flex items-center gap-2 overflow-hidden">
                         <FileText className="h-4 w-4 text-ziad-primary shrink-0" />
                         <span className="truncate">{m.title}</span>
                       </div>
                       <button onClick={() => handleDeletePdf(session.id, m.id)} className="text-red-500 shrink-0"><Trash2 className="h-4 w-4" /></button>
                     </div>
                  ))}
                  {(!session.sessionPDFs || session.sessionPDFs.length === 0) && (
                    <p className="text-xs font-medium italic text-gray-700">{t("noPdfsAttached")}</p>
                  )}
                </div>
                <label className="cursor-pointer inline-flex items-center gap-2 rounded-button bg-ziad-light px-3 py-1.5 text-xs font-bold text-ziad-ink hover:bg-ziad-line">
                  <Plus className="h-3 w-3" /> {t("addPdf")}
                  <input type="file" accept=".pdf" className="hidden" onChange={(e) => handleUploadPdf(session.id, e)} />
                </label>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
