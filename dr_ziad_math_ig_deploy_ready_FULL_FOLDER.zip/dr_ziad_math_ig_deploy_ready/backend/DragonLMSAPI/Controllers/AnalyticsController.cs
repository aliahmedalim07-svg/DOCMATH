using System.Security.Claims;
using DrZiadMathIGAPI.Dtos;
using DrZiadMathIGAPI.Models;
using DrZiadMathIGAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DrZiadMathIGAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnalyticsController(IAnalyticsService analyticsService, UserManager<ApplicationUser> userManager, DragonLMSDbContext context) : ControllerBase
    {
        [HttpGet("admin-dashboard")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<AdminDashboardDto>> GetAdminDashboard()
        {
            var today = DateOnly.FromDateTime(DateTime.Now);
            var todayStart = DateTime.Today;
            var tomorrowStart = todayStart.AddDays(1);
            var trendStart = todayStart.AddDays(-6);

            var courses = await context.Courses
                .Include(c => c.Students)
                .ToListAsync();

            var tries = await context.Tries
                .Include(t => t.User)
                .Include(t => t.QuestionGroup)
                    .ThenInclude(qg => qg!.Course)
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();

            var tryIds = tries.Select(t => t.Id).ToList();
            var answerCounts = await context.UserAnswers
                .Include(a => a.SelectedChoice)
                .Where(a => tryIds.Contains(a.Try.Id))
                .GroupBy(a => a.Try.Id)
                .Select(g => new
                {
                    TryId = g.Key,
                    Total = g.Count(),
                    Correct = g.Count(a => a.SelectedChoice.IsCorrect)
                })
                .ToListAsync();

            var scoreByTry = answerCounts.ToDictionary(
                item => item.TryId,
                item => item.Total > 0 ? Math.Round((double)item.Correct / item.Total * 100, 1) : 0);

            var attemptsWithScores = tries
                .Select(t => new
                {
                    Try = t,
                    Score = scoreByTry.TryGetValue(t.Id, out var score) ? score : 0
                })
                .ToList();

            var attemptTrend = Enumerable.Range(0, 7)
                .Select(offset => trendStart.AddDays(offset))
                .Select(day => new AdminSeriesPointDto
                {
                    Label = day.ToString("MMM d"),
                    Value = attemptsWithScores.Count(item => item.Try.CreatedAt.Date == day.Date)
                })
                .ToList();

            var scoreTrend = Enumerable.Range(0, 7)
                .Select(offset => trendStart.AddDays(offset))
                .Select(day =>
                {
                    var dayScores = attemptsWithScores
                        .Where(item => item.Try.CreatedAt.Date == day.Date)
                        .Select(item => item.Score)
                        .ToList();

                    return new AdminSeriesPointDto
                    {
                        Label = day.ToString("MMM d"),
                        Value = dayScores.Count > 0 ? Math.Round(dayScores.Average(), 1) : 0
                    };
                })
                .ToList();

            var dashboard = new AdminDashboardDto
            {
                TotalStudents = await userManager.Users.CountAsync(u => u.AccountType == AccountType.Student),
                TotalCourses = courses.Count,
                ActiveCourses = courses.Count(c => c.Deadline >= today),
                EndedCourses = courses.Count(c => c.Deadline < today),
                TotalBooks = await context.Books.CountAsync(),
                TotalSessions = await context.Sessions.CountAsync(),
                TotalAssignments = await context.QuestionGroups.CountAsync(g => g.Type == QuestionGroupType.Assignments),
                TotalSkills = await context.QuestionGroups.CountAsync(g => g.Type == QuestionGroupType.Skills),
                TotalWeeklyExams = await context.QuestionGroups.CountAsync(g => g.Type == QuestionGroupType.WeeklyExams),
                TotalAttempts = tries.Count,
                AverageScore = attemptsWithScores.Count > 0 ? Math.Round(attemptsWithScores.Average(item => item.Score), 1) : 0,
                AttemptsToday = tries.Count(t => t.CreatedAt >= todayStart && t.CreatedAt < tomorrowStart),
                AttemptTrend = attemptTrend,
                ScoreTrend = scoreTrend,
                CourseDistribution = courses
                    .OrderByDescending(c => c.Students.Count)
                    .Take(6)
                    .Select(c => new AdminSeriesPointDto { Label = c.Title, Value = c.Students.Count })
                    .ToList(),
                AverageScoreByCourse = attemptsWithScores
                    .Where(item => item.Try.QuestionGroup?.Course != null)
                    .GroupBy(item => item.Try.QuestionGroup!.Course!.Title)
                    .Select(g => new AdminSeriesPointDto
                    {
                        Label = g.Key,
                        Value = Math.Round(g.Average(item => item.Score), 1)
                    })
                    .OrderByDescending(item => item.Value)
                    .Take(8)
                    .ToList(),
                CourseStatus =
                [
                    new AdminSeriesPointDto { Label = "Active", Value = courses.Count(c => c.Deadline >= today) },
                    new AdminSeriesPointDto { Label = "Ended", Value = courses.Count(c => c.Deadline < today) }
                ],
                ContentMix =
                [
                    new AdminSeriesPointDto { Label = "Assignments", Value = await context.QuestionGroups.CountAsync(g => g.Type == QuestionGroupType.Assignments) },
                    new AdminSeriesPointDto { Label = "Skills", Value = await context.QuestionGroups.CountAsync(g => g.Type == QuestionGroupType.Skills) },
                    new AdminSeriesPointDto { Label = "Weekly Exams", Value = await context.QuestionGroups.CountAsync(g => g.Type == QuestionGroupType.WeeklyExams) },
                    new AdminSeriesPointDto { Label = "Sessions", Value = await context.Sessions.CountAsync() }
                ],
                RecentAttempts = attemptsWithScores
                    .Take(6)
                    .Select(item => new AdminRecentAttemptDto
                    {
                        Id = item.Try.Id,
                        StudentName = item.Try.User.Name ?? item.Try.User.UserName ?? "Student",
                        ActivityTitle = item.Try.QuestionGroup?.Title ?? "Activity",
                        SubmittedAt = item.Try.CreatedAt,
                        Score = item.Score
                    })
                    .ToList()
            };

            return Ok(dashboard);
        }

        [HttpGet("my-mistakes")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<IActionResult> GetMyMistakeHistory()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId is null) return Unauthorized();

            var user = await userManager.FindByIdAsync(userId);
            if (user is null) return NotFound("User not found.");

            var mistakes = await analyticsService.GetMistakeHistoryAsync(user);
            return Ok(mistakes);
        }

        [HttpGet("child-mistakes")]
        [Authorize(Roles = "Parent,Admin")]
        public async Task<IActionResult> GetChildMistakeHistory(string childPhoneNumber)
        {
            var user = await userManager.Users.FirstOrDefaultAsync(u => u.PhoneNumber == childPhoneNumber);

            if (user is null)
            {
                return BadRequest("No user with this phone number");
            }

            var parentPhone = User.Claims.FirstOrDefault(c => c.Type == "PhoneNumber")?.Value;
            if (user.ParentPhoneNumber != parentPhone)
            {
                return BadRequest("This user is not your child");
            }

            var mistakes = await analyticsService.GetMistakeHistoryAsync(user);
            return Ok(mistakes);
        }

        [HttpGet("my-weak-points")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<IActionResult> GetMyWeakPoints()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId is null) return Unauthorized();

            var user = await userManager.FindByIdAsync(userId);
            if (user is null) return NotFound("User not found.");

            var weakPoints = await analyticsService.GetWeakPointsDataAsync(user);
            return Ok(weakPoints);
        }

        [HttpGet("child-weak-points")]
        [Authorize(Roles = "Parent,Admin")]
        public async Task<IActionResult> GetChildWeakPoints(string childPhoneNumber)
        {
            var user = await userManager.Users.FirstOrDefaultAsync(u => u.PhoneNumber == childPhoneNumber);

            if (user is null)
            {
                return BadRequest("No user with this phone number");
            }

            var parentPhone = User.Claims.FirstOrDefault(c => c.Type == "PhoneNumber")?.Value;
            if (user.ParentPhoneNumber != parentPhone)
            {
                return BadRequest("This user is not your child");
            }

            var weakPoints = await analyticsService.GetWeakPointsDataAsync(user);
            return Ok(weakPoints);
        }

        [HttpGet("average-score-trend")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAverageScoreTrendByCourse([FromQuery] int courseId)
        {
            var trend = await analyticsService.GetAverageScoreTrendByCourseAsync(courseId);
            return Ok(trend);
        }

        [HttpGet("students-by-course")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetStudentsByCourse([FromQuery] int courseId)
        {
            var students = await analyticsService.GetStudentsByCourseAsync(courseId);
            return Ok(students);
        }
    }
}
