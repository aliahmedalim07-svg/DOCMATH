using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DrZiadMathIGAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using DrZiadMathIGAPI.Services;
using DrZiadMathIGAPI.Services.Video;
using DrZiadMathIGAPI.Dtos;

namespace DrZiadMathIGAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionGroupsController(
        DragonLMSDbContext context,
        IStorageService storageService,
        UserManager<ApplicationUser> userManager,
        VideoService videoService,
        IWhatsappService whatsAppService
        ) : ControllerBase
    {
        private static DateOnly Today => DateOnly.FromDateTime(DateTime.Now);

        private bool ShouldRestrictStudentData(string? userId) =>
            User?.Identity?.IsAuthenticated == true && User?.IsInRole("Admin") != true && userId != null;

        private IQueryable<T> RestrictStudentCourseData<T>(IQueryable<T> query, string? userId) where T : QuestionGroup
        {
            if (!ShouldRestrictStudentData(userId))
            {
                return query;
            }

            return query.Where(g => g.Course != null
                && g.Course.Deadline >= Today
                && g.Course.Students.Any(student => student.Id == userId));
        }

        // GET: api/QuestionGroups
        [HttpGet]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<QuestionGroup>>> GetQuestionGroups([FromQuery] QuestionGroupType? type)
        {
            var user = await userManager.GetUserAsync(User);
            IQueryable<QuestionGroup> query = context.QuestionGroups
                .Include(g => g.Course)
                    .ThenInclude(c => c!.Students);
            if (type.HasValue)
            {
                query = query.Where(g => g.Type == type.Value);
            }
            query = RestrictStudentCourseData(query, user?.Id);
            return await query.ToListAsync();
        }

        [HttpGet("assignments")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<AssignmentDto>>> GetAssignments([FromQuery] int? courseId = null)
        {
            var query = context.Assignments
                .Include(a => a.Videos)
                .Include(a => a.Book)
                .Include(a => a.Course)
                    .ThenInclude(c => c!.Students)
                .Include(a => a.QuestionBelongings)
                    .ThenInclude(qb => qb.Question)
                        .ThenInclude(q => q.Choices)
                .AsQueryable();

            if (courseId.HasValue)
            {
                query = query.Where(a => a.Course != null && a.Course.Id == courseId.Value);
            }

            var user = await userManager.GetUserAsync(User);
            query = RestrictStudentCourseData(query, user?.Id);

            var assignments = await query.ToListAsync();

            var assignmentIds = assignments.Select(a => a.Id).ToList();
            var pdfs = await context.QuestionGroupPDFs
                .Include(p => p.QuestionGroup)
                .Where(p => assignmentIds.Contains(p.QuestionGroup.Id))
                .ToListAsync();

            return assignments.Select(a => new AssignmentDto
            {
                Id = a.Id,
                Title = a.Title,
                Type = a.Type,
                DurationInMinutes = a.DurationInMinutes,
                Book = a.Book,
                Course = a.Course,
                Videos = a.Videos,
                Pdfs = pdfs.Where(p => p.QuestionGroup.Id == a.Id).ToList(),
                QuestionBelongings = a.QuestionBelongings.OrderBy(qb => qb.OrderIndex ?? 0).ToList()
            }).ToList();
        }

        [HttpGet("skills")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<SkillDto>>> GetSkills([FromQuery] int? courseId = null)
        {
            var query = context.Skills
                .Include(s => s.Videos)
                .Include(s => s.Course)
                    .ThenInclude(c => c!.Students)
                .Include(s => s.QuestionBelongings)
                    .ThenInclude(qb => qb.Question)
                        .ThenInclude(q => q.Choices)
                .AsQueryable();

            if (courseId.HasValue)
            {
                query = query.Where(s => s.Course != null && s.Course.Id == courseId.Value);
            }

            var user = await userManager.GetUserAsync(User);
            query = RestrictStudentCourseData(query, user?.Id);

            var skills = await query.ToListAsync();

            var skillIds = skills.Select(s => s.Id).ToList();
            var pdfs = await context.QuestionGroupPDFs
                .Include(p => p.QuestionGroup)
                .Where(p => skillIds.Contains(p.QuestionGroup.Id))
                .ToListAsync();

            return skills.Select(s => new SkillDto
            {
                Id = s.Id,
                Title = s.Title,
                Type = s.Type,
                Course = s.Course,
                Videos = s.Videos,
                Pdfs = pdfs.Where(p => p.QuestionGroup.Id == s.Id).ToList(),
                QuestionBelongings = s.QuestionBelongings.OrderBy(qb => qb.OrderIndex ?? 0).ToList()
            }).ToList();
        }

        [HttpGet("weekly-exams")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<WeeklyExamDto>>> GetWeeklyExams([FromQuery] int? courseId = null)
        {
            var user = await userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var query = context.WeeklyExams
                .Include(g => g.User)
                .Include(g => g.Videos)
                .Include(g => g.Course)
                    .ThenInclude(c => c!.Students)
                .Include(g => g.QuestionBelongings)
                    .ThenInclude(qb => qb.Question)
                        .ThenInclude(q => q.Choices)
                .Where(g => g.User.Id == user.Id);

            if (courseId.HasValue)
            {
                query = query.Where(g => g.Course != null && g.Course.Id == courseId.Value);
            }

            query = RestrictStudentCourseData(query, user.Id);

            var weeklyExams = await query.ToListAsync();

            var weeklyExamIds = weeklyExams.Select(g => g.Id).ToList();
            var pdfs = await context.QuestionGroupPDFs
                .Include(p => p.QuestionGroup)
                .Where(p => weeklyExamIds.Contains(p.QuestionGroup.Id))
                .ToListAsync();

            return weeklyExams.Select(g => new WeeklyExamDto
            {
                Id = g.Id,
                Title = g.Title,
                Type = g.Type,
                Date = g.Date,
                Course = g.Course,
                Videos = g.Videos,
                Pdfs = pdfs.Where(p => p.QuestionGroup.Id == g.Id).ToList(),
                QuestionBelongings = g.QuestionBelongings.OrderBy(qb => qb.OrderIndex ?? 0).ToList()
            }).ToList();
        }

        // GET: api/QuestionGroups/5
        [HttpGet("{id}")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<QuestionGroup>> GetQuestionGroup(int id)
        {
            var questionGroup = await context.QuestionGroups
                .Include(g => g.Course)
                    .ThenInclude(c => c!.Students)
                .FirstOrDefaultAsync(g => g.Id == id);

            if (questionGroup == null)
            {
                return NotFound();
            }

            var user = await userManager.GetUserAsync(User);
            var userId = user?.Id;
            if (ShouldRestrictStudentData(userId))
            {
                if (questionGroup.Course == null
                    || questionGroup.Course.Deadline < Today
                    || !questionGroup.Course.Students.Any(student => student.Id == userId))
                {
                    return NotFound();
                }
            }

            return questionGroup;
        }

        // GET: api/QuestionGroups/5/questions
        [HttpGet("{id}/questions")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<Question>>> GetGroupQuestions(int id)
        {
            var group = await context.QuestionGroups
                .Include(g => g.Course)
                    .ThenInclude(c => c!.Students)
                .FirstOrDefaultAsync(g => g.Id == id);
            if (group == null) return NotFound();

            var user = await userManager.GetUserAsync(User);
            var userId = user?.Id;
            if (ShouldRestrictStudentData(userId))
            {
                if (group.Course == null
                    || group.Course.Deadline < Today
                    || !group.Course.Students.Any(student => student.Id == userId))
                {
                    return NotFound();
                }
            }

            var belongs = await context.QuestionBelongings
                .Include(b => b.Question)
                .ThenInclude(q => q.Choices)
                .Include(b => b.Question)
                .ThenInclude(q => q.BookQuestions)
                .ThenInclude(bq => bq.Book)
                .Include(b => b.Question)
                .ThenInclude(q => q.Topic)
                .Where(b => b.QuestionGroup.Id == id)
                .OrderBy(b => b.OrderIndex ?? 0)
                .ToListAsync();

            var result = belongs.Select(b => b.Question).Select(q => new
            {
                q.Id,
                q.Text,
                q.QuestionImageUrl,
                q.ExpanationImageUrl,
                q.ExplanationVideoUrl,
                q.Difficulty,
                q.YearAppeared,
                q.MonthAppeared,
                q.Explanation,
                q.OrderIndex,
                q.TopicId,
                Topic = q.Topic == null ? null : new { q.Topic.Id, q.Topic.Name },
                Choices = q.Choices.Select(c => new { c.Id, c.Text, c.IsCorrect, c.ChoiceImageUrl }),
                BookQuestions = q.BookQuestions.Select(bq => new { Book = new { bq.Book.Id, bq.Book.Title } }),
            });

            return Ok(result);
        }

        [HttpPost("{id}/submit")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<IActionResult> SubmitQuestionGroup(int id, [FromBody] Dtos.SubmitQuestionGroupDto submission)
        {
            var group = await context.QuestionGroups
                .Include(g => g.Course)
                    .ThenInclude(c => c!.Students)
                .FirstOrDefaultAsync(g => g.Id == id);
            if (group == null) return NotFound();

            var user = await userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();
            if (ShouldRestrictStudentData(user.Id)
                && (group.Course == null
                    || group.Course.Deadline < Today
                    || !group.Course.Students.Any(student => student.Id == user.Id)))
            {
                return NotFound();
            }

            var tryRecord = new Try { User = user, QuestionGroup = group, CreatedAt = DateTime.UtcNow };
            context.Tries.Add(tryRecord);
            await context.SaveChangesAsync();

            int correctCount = 0;
            var questionIds = submission.Answers.Select(a => a.QuestionId).ToList();
            var questions = await context.Questions
                .Include(q => q.Choices)
                .Where(q => questionIds.Contains(q.Id))
                .ToListAsync();

            foreach (var answer in submission.Answers)
            {
                var question = questions.FirstOrDefault(q => q.Id == answer.QuestionId);
                if (question == null) continue;

                var selectedChoice = question.Choices.FirstOrDefault(c => c.Id == answer.ChoiceId);
                if (selectedChoice == null) continue;

                var isCorrect = question.Choices.Any(c => c.Id == answer.ChoiceId && c.IsCorrect);
                if (isCorrect) correctCount++;

                var userAnswer = new UserAnswer
                {
                    User = user,
                    Try = tryRecord,
                    Question = question,
                    SelectedChoice = selectedChoice
                };
                context.UserAnswers.Add(userAnswer);
            }

            await context.SaveChangesAsync();

            var answeredQuestions = await context.UserAnswers.CountAsync(a => a.Try.Id == tryRecord.Id);
            var totalQuestions = await GetScoringQuestionTotalAsync(group, answeredQuestions);

            var result = new Dtos.SubmitResultDto
            {
                TryId = tryRecord.Id,
                TotalQuestions = totalQuestions,
                CorrectAnswers = correctCount,
                ScorePercentage = totalQuestions > 0 ? (double)correctCount / totalQuestions * 100 : 0
            };

            // Send WhatsApp notification
            try
            {
                var message = $@"السلام عليكم، إزيك معاك مساعد دكتور زياد

كنت حابب أعرف حضرتك إن الطالب لسة حالل ({group.Type}) على الموقع و دي درجته ⬇️

#student: {user.FullName}
#course: {group.Course?.Title ?? "No course"}
#test: {group.Title}
#your score is: {result.CorrectAnswers}/{result.TotalQuestions}
#percentage: {result.ScorePercentage:F2}%

💥 لو في أي مشكلة بتواجهنا أو استفسار نتواصل مع الأسيستنت الخاص بينا 💥
🎯اليوزر والباسورد ناخدهم من ابننا أو بنتنا

بالتوفيق تيم دكتور زياد🤝♥️

Best wishes team Dr. Ziad Mohamed❤️";

                await whatsAppService.SendMessageAsync(user.ParentPhoneNumber, message);
                await whatsAppService.SendMessageAsync(user.PhoneNumber!, message);
            }
            catch
            {
                // Do nothing if WhatsApp notification fails, as it should not affect the main functionality
            }

            return Ok(result);
        }

        // POST: api/QuestionGroups/assignment
        [HttpPost("assignment")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Assignment>> PostAssignment([FromBody] Dtos.CreateAssignmentDto dto)
        {
            var book = await context.Books.FindAsync(dto.BookId);
            if (book == null) return BadRequest("Book not found.");

            var assignment = new Assignment
            {
                Title = dto.Title,
                DurationInMinutes = dto.DurationInMinutes,
                Book = book,
                Type = QuestionGroupType.Assignments
            };

            if (dto.CourseId.HasValue)
            {
                var course = await context.Courses.FindAsync(dto.CourseId.Value);
                if (course != null) assignment.Course = course;
            }

            context.Assignments.Add(assignment);
            await context.SaveChangesAsync();

            return CreatedAtAction("GetQuestionGroup", new { id = assignment.Id }, assignment);
        }

        // POST: api/QuestionGroups/skill
        [HttpPost("skill")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Skill>> PostSkill(Skill skill, [FromQuery] int? courseId = null)
        {
            skill.Type = QuestionGroupType.Skills;

            if (courseId.HasValue)
            {
                var course = await context.Courses.FindAsync(courseId.Value);
                if (course != null) skill.Course = course;
            }

            context.Skills.Add(skill);
            await context.SaveChangesAsync();

            return CreatedAtAction("GetQuestionGroup", new { id = skill.Id }, skill);
        }

        // POST: api/QuestionGroups/5/add-question
        [HttpPost("{id}/add-question")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddQuestionToGroup(int id, [FromBody] int questionId)
        {
            var group = await context.QuestionGroups.FindAsync(id);
            var question = await context.Questions.FindAsync(questionId);

            if (group == null) return NotFound($"Assignment with id {id} not found.");
            if (question == null) return NotFound($"Question with id {questionId} not found.");

            if (await context.QuestionBelongings.AnyAsync(b => b.QuestionGroup.Id == id && b.Question.Id == questionId))
            {
                return BadRequest("Question is already in this assignment.");
            }

            context.QuestionBelongings.Add(new QuestionBelonging { Question = question, QuestionGroup = group });
            await context.SaveChangesAsync();

            return Ok(new { success = true, questionGroupId = id, questionId = questionId });
        }

        [HttpGet("{id}/tries")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<Dtos.TryDto>>> GetTriesByAssignment(int id)
        {
            var user = await userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var isAdmin = User?.IsInRole("Admin") == true || User?.Identity?.IsAuthenticated != true;
            var tries = await context.Tries
                .Include(t => t.QuestionGroup)
                    .ThenInclude(g => g!.Course)
                .Where(t => t.User.Id == user.Id && t.QuestionGroup != null && t.QuestionGroup.Id == id)
                .Where(t => isAdmin || t.QuestionGroup!.Course == null || t.QuestionGroup.Course.Deadline >= Today)
                .OrderByDescending(t => t.Id)
                .ToListAsync();

            var result = new List<Dtos.TryDto>();
            foreach (var tryRecord in tries)
            {
                var answers = await context.UserAnswers
                    .Include(a => a.Question).ThenInclude(q => q.Choices)
                    .Where(a => a.Try.Id == tryRecord.Id)
                    .ToListAsync();

                var correctCount = answers.Count(a => a.SelectedChoice.IsCorrect);
                var total = await GetScoringQuestionTotalAsync(tryRecord.QuestionGroup, answers.Count);

                result.Add(new Dtos.TryDto
                {
                    Id = tryRecord.Id,
                    QuestionGroupTitle = tryRecord.QuestionGroup?.Title ?? "Unknown",
                    QuestionGroupId = tryRecord.QuestionGroup?.Id ?? 0,
                    SubmittedAt = tryRecord.CreatedAt,
                    TotalQuestions = total,
                    CorrectAnswers = correctCount,
                    ScorePercentage = total > 0 ? (double)correctCount / total * 100 : 0
                });
            }

            return Ok(result);
        }

        [HttpDelete("{id}/remove-question/{questionId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemoveQuestionFromGroup(int id, int questionId)
        {
            var belonging = await context.QuestionBelongings
                .FirstOrDefaultAsync(b => b.QuestionGroup.Id == id && b.Question.Id == questionId);

            if (belonging == null) return NotFound();

            context.QuestionBelongings.Remove(belonging);
            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpPut("{id}/reorder-questions")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ReorderQuestions(int id, [FromBody] List<int> belongingIds)
        {
            var belongings = await context.QuestionBelongings
                .Where(b => b.QuestionGroup.Id == id)
                .ToListAsync();

            var ordered = belongingIds
                .Select((bid, index) => new { Id = bid, OrderIndex = index })
                .ToList();

            foreach (var item in ordered)
            {
                var belonging = belongings.FirstOrDefault(b => b.Id == item.Id);
                if (belonging != null)
                {
                    belonging.OrderIndex = item.OrderIndex;
                }
            }

            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateQuestionGroup(int id, [FromBody] Dtos.UpdateQuestionGroupDto dto)
        {
            var group = await context.QuestionGroups
                .Include(g => g.Course)
                .FirstOrDefaultAsync(g => g.Id == id);

            if (group == null) return NotFound();

            if (dto.CourseId.HasValue)
            {
                var course = await context.Courses.FindAsync(dto.CourseId.Value);
                if (course != null) group.Course = course;
            }
            else
            {
                group.Course = null;
            }

            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteQuestionGroup(int id)
        {
            var group = await context.QuestionGroups.FindAsync(id);
            if (group == null) return NotFound();

            var belongings = await context.QuestionBelongings.Where(b => b.QuestionGroup.Id == id).ToListAsync();
            context.QuestionBelongings.RemoveRange(belongings);

            var tries = await context.Tries.Where(t => t.QuestionGroup != null && t.QuestionGroup.Id == id).ToListAsync();
            foreach (var tr in tries)
            {
                var answers = await context.UserAnswers.Where(a => a.Try.Id == tr.Id).ToListAsync();
                context.UserAnswers.RemoveRange(answers);
            }
            context.Tries.RemoveRange(tries);

            var videos = await context.QuestionGroupVideos.Where(v => v.QuestionGroup.Id == id).ToListAsync();
            context.QuestionGroupVideos.RemoveRange(videos);

            var pdfs = await context.QuestionGroupPDFs.Where(p => p.QuestionGroup.Id == id).ToListAsync();
            context.QuestionGroupPDFs.RemoveRange(pdfs);

            context.QuestionGroups.Remove(group);
            await context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPost("{id}/add-video")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddVideoToGroup(int id, [FromBody] Dtos.AddQuestionGroupVideoDto video)
        {
            var group = await context.QuestionGroups.FindAsync(id);
            if (group == null) return NotFound();
            if (string.IsNullOrWhiteSpace(video.Url)) return BadRequest("Video URL is required.");

            var url = video.Provider == VideoProvider.YouTube
                ? ToYouTubeEmbedUrl(video.Url.Trim())
                : video.Url.Trim();

            var newVideo = new QuestionGroupVideo
            {
                Url = url,
                Provider = video.Provider,
                DefaultViews = video.DefaultViews,
                QuestionGroup = group
            };
            context.QuestionGroupVideos.Add(newVideo);
            await context.SaveChangesAsync();

            if (video.Provider == VideoProvider.VdoCipher && video.DefaultViews.HasValue)
            {
                List<ApplicationUser> users;
                if (group.Course != null)
                {
                    users = await context.Users
                        .Where(u => u.Courses.Any(c => c.Id == group.Course.Id))
                        .ToListAsync();
                }
                else
                {
                    users = await context.Users
                        .Where(u => u.AccountType == AccountType.Student)
                        .ToListAsync();
                }

                foreach (var user in users)
                {
                    context.UserViews.Add(new UserView
                    {
                        Video = newVideo,
                        User = user,
                        Views = video.DefaultViews.Value
                    });
                }
                await context.SaveChangesAsync();
            }

            return NoContent();
        }

        [HttpGet("{id}/play")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<Dtos.VideoPlayResultDto>> PlayVideo(int id)
        {
            var user = await userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var video = await context.QuestionGroupVideos.FindAsync(id);
            if (video == null) return NotFound();

            if (video.Provider == VideoProvider.VdoCipher)
            {
                var userView = await context.UserViews
                    .FirstOrDefaultAsync(uv => uv.Video.Id == id && uv.User.Id == user.Id);
                if (userView == null || userView.Views <= 0)
                    return Forbid();
                userView.Views--;
                await context.SaveChangesAsync();
            }

            var result = await videoService.GetPlayableUrlAsync(video, user.UserName);
            return Ok(new Dtos.VideoPlayResultDto
            {
                Url = result.Url,
                PlayerType = result.PlayerType
            });
        }

        [HttpGet("{videoId}/remaining-views")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<Dtos.RemainingViewsDto>> GetRemainingViews(int videoId)
        {
            var user = await userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var video = await context.QuestionGroupVideos.FindAsync(videoId);
            if (video == null) return NotFound();

            if (video.Provider != VideoProvider.VdoCipher)
                return Ok(new Dtos.RemainingViewsDto { RemainingViews = -1 });

            var userView = await context.UserViews
                .FirstOrDefaultAsync(uv => uv.Video.Id == videoId && uv.User.Id == user.Id);
            return Ok(new Dtos.RemainingViewsDto { RemainingViews = userView?.Views ?? 0 });
        }

        [HttpGet("{videoId}/user-views")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<IEnumerable<Dtos.VideoUserViewDto>>> GetVideoUserViews(int videoId)
        {
            var video = await context.QuestionGroupVideos.FindAsync(videoId);
            if (video == null) return NotFound();

            var userViews = await context.UserViews
                .Include(uv => uv.User)
                .Where(uv => uv.Video.Id == videoId)
                .Select(uv => new Dtos.VideoUserViewDto
                {
                    UserId = uv.User.Id,
                    UserName = uv.User.Name ?? uv.User.UserName ?? "",
                    Views = uv.Views
                })
                .ToListAsync();
            return Ok(userViews);
        }

        [HttpPut("{videoId}/user-views/{userId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateVideoUserView(int videoId, string userId, [FromBody] Dtos.UpdateUserViewDto dto)
        {
            var userView = await context.UserViews
                .FirstOrDefaultAsync(uv => uv.Video.Id == videoId && uv.User.Id == userId);
            if (userView == null) return NotFound();

            userView.Views = dto.Views;
            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{groupId}/videos/{videoId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteVideoFromGroup(int groupId, int videoId)
        {
            var video = await context.QuestionGroupVideos
                .FirstOrDefaultAsync(v => v.Id == videoId && v.QuestionGroup.Id == groupId);
            if (video == null) return NotFound();

            context.QuestionGroupVideos.Remove(video);
            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpPost("{id}/add-pdf")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddPdfToGroup(int id, [FromForm(Name = "file")] IFormFile pdfFile)
        {
            var group = await context.QuestionGroups.FindAsync(id);
            if (group == null) return NotFound();
            if (pdfFile == null || pdfFile.Length == 0) return BadRequest("PDF file is required.");

            var url = await storageService.UploadFileAsync(pdfFile, "questionGroupPDFs");
            context.QuestionGroupPDFs.Add(new QuestionGroupPDF { QuestionGroup = group, Url = url });
            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{groupId}/pdfs/{pdfId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeletePdfFromGroup(int groupId, int pdfId)
        {
            var pdf = await context.QuestionGroupPDFs
                .FirstOrDefaultAsync(p => p.Id == pdfId && p.QuestionGroup.Id == groupId);
            if (pdf == null) return NotFound();

            context.QuestionGroupPDFs.Remove(pdf);
            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpGet("tries")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<Dtos.TryDto>>> GetTries()
        {
            var user = await userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var isAdmin = User?.IsInRole("Admin") == true || User?.Identity?.IsAuthenticated != true;
            var userTries = await context.Tries
                .Include(t => t.QuestionGroup)
                    .ThenInclude(g => g!.Course)
                .Where(t => t.User.Id == user.Id)
                .Where(t => isAdmin || t.QuestionGroup == null || t.QuestionGroup.Course == null || t.QuestionGroup.Course.Deadline >= Today)
                .OrderByDescending(t => t.Id)
                .ToListAsync();

            var result = new List<Dtos.TryDto>();
            foreach (var tryRecord in userTries)
            {
                var answers = await context.UserAnswers
                    .Include(a => a.Question)
                    .ThenInclude(q => q.Choices)
                    .Where(a => a.Try.Id == tryRecord.Id)
                    .ToListAsync();

                var correctCount = answers.Count(a => a.SelectedChoice.IsCorrect);
                var total = await GetScoringQuestionTotalAsync(tryRecord.QuestionGroup, answers.Count);

                result.Add(new Dtos.TryDto
                {
                    Id = tryRecord.Id,
                    QuestionGroupTitle = tryRecord.QuestionGroup?.Title ?? "Unknown",
                    QuestionGroupId = tryRecord.QuestionGroup?.Id ?? 0,
                    SubmittedAt = tryRecord.CreatedAt,
                    TotalQuestions = total,
                    CorrectAnswers = correctCount,
                    ScorePercentage = total > 0 ? (double)correctCount / total * 100 : 0
                });
            }

            return Ok(result);
        }

        [HttpGet("tries/{id}")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<Dtos.TryDetailDto>> GetTryDetail(int id)
        {
            var user = await userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var tryRecord = await context.Tries
                .Include(t => t.QuestionGroup)
                    .ThenInclude(g => g!.Course)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (tryRecord == null || tryRecord.User.Id != user.Id)
                return NotFound();
            if (ShouldRestrictStudentData(user.Id) && tryRecord.QuestionGroup?.Course?.Deadline < Today)
                return NotFound();

            var answers = await context.UserAnswers
                .Include(a => a.Question)
                .ThenInclude(q => q.Choices)
                .Where(a => a.Try.Id == tryRecord.Id)
                .ToListAsync();

            var correctCount = answers.Count(a => a.SelectedChoice.IsCorrect);
            var total = await GetScoringQuestionTotalAsync(tryRecord.QuestionGroup, answers.Count);

            var answerDtos = answers.Select(a => new Dtos.QuestionAnswerDto
            {
                QuestionId = a.Question.Id,
                QuestionText = a.Question.Text ?? "",
                QuestionImageUrl = a.Question.QuestionImageUrl,
                Explanation = a.Question.Explanation,
                ExplanationImageUrl = a.Question.ExpanationImageUrl,
                SelectedChoiceId = a.SelectedChoice.Id,
                SelectedChoiceText = a.SelectedChoice.Text,
                SelectedChoiceImageUrl = a.SelectedChoice.ChoiceImageUrl,
                CorrectChoiceId = a.Question.Choices.FirstOrDefault(c => c.IsCorrect)?.Id,
                CorrectChoiceText = a.Question.Choices.FirstOrDefault(c => c.IsCorrect)?.Text,
                CorrectChoiceImageUrl = a.Question.Choices.FirstOrDefault(c => c.IsCorrect)?.ChoiceImageUrl,
                IsCorrect = a.SelectedChoice.IsCorrect
            }).ToList();

            var result = new Dtos.TryDetailDto
            {
                TryId = tryRecord.Id,
                QuestionGroupTitle = tryRecord.QuestionGroup?.Title ?? "Unknown",
                QuestionGroupId = tryRecord.QuestionGroup?.Id ?? 0,
                SubmittedAt = tryRecord.CreatedAt,
                TotalQuestions = total,
                CorrectAnswers = correctCount,
                ScorePercentage = total > 0 ? (double)correctCount / total * 100 : 0,
                Answers = answerDtos
            };

            return Ok(result);
        }

        private async Task<int> GetQuestionGroupQuestionCountAsync(int questionGroupId, int fallbackTotal)
        {
            if (questionGroupId <= 0) return fallbackTotal;

            var total = await context.QuestionBelongings
                .CountAsync(b => b.QuestionGroup.Id == questionGroupId);

            return total > 0 ? total : fallbackTotal;
        }

        private async Task<int> GetScoringQuestionTotalAsync(QuestionGroup? questionGroup, int answeredTotal)
        {
            if (questionGroup?.Type == QuestionGroupType.Skills)
            {
                return answeredTotal;
            }

            return await GetQuestionGroupQuestionCountAsync(questionGroup?.Id ?? 0, answeredTotal);
        }

        private static string ToYouTubeEmbedUrl(string url)
        {
            try
            {
                var uri = new Uri(url);
                var host = uri.Host.ToLowerInvariant();

                string? videoId = null;

                if (host.Contains("youtu.be"))
                {
                    videoId = uri.AbsolutePath.TrimStart('/');
                }
                else if (host.Contains("youtube.com"))
                {
                    var query = System.Web.HttpUtility.ParseQueryString(uri.Query);
                    videoId = query["v"];
                }

                if (!string.IsNullOrWhiteSpace(videoId))
                {
                    return $"https://www.youtube-nocookie.com/embed/{videoId}?rel=0&modestbranding=1";
                }
            }
            catch { }

            return url;
        }
    }
}
