using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DrZiadMathIGAPI.Models;
using DrZiadMathIGAPI.Dtos;
using Microsoft.AspNetCore.Authorization;
using DrZiadMathIGAPI.Services;
using System.Security.Claims;

namespace DrZiadMathIGAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SessionsController(DragonLMSDbContext context, IStorageService storageService) : ControllerBase
    {

        private string? GetUserId() => User?.FindFirstValue(ClaimTypes.NameIdentifier);
        private static DateOnly Today => DateOnly.FromDateTime(DateTime.Now);

        // GET: api/Sessions
        [HttpGet]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<Session>>> GetSessions()
        {
            var query = context.Sessions
                .Include(s => s.SessionPDFs)
                .Include(s => s.Course)
                    .ThenInclude(c => c!.Students)
                .AsQueryable();

            var userId = GetUserId();
            if (User?.IsInRole("Admin") != true && userId != null)
            {
                query = query.Where(s => s.Course != null
                    && s.Course.Deadline >= Today
                    && s.Course.Students.Any(student => student.Id == userId));
            }

            return await query.ToListAsync();
        }

        // GET: api/Sessions/by-course/5
        [HttpGet("by-course/{courseId}")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<Session>>> GetSessionsByCourse(int courseId)
        {
            var isAdmin = User?.IsInRole("Admin") == true;
            if (!isAdmin)
            {
                var userId = GetUserId();
                if (userId == null) return Forbid();

                var course = await context.Courses
                    .Include(c => c.Students)
                    .FirstOrDefaultAsync(c => c.Id == courseId);
                if (course == null) return NotFound();
                if (!course.Students.Any(s => s.Id == userId)) return Forbid();
                if (course.Deadline < Today) return Ok(Array.Empty<Session>());
            }

            return await context.Sessions
                .Include(s => s.SessionPDFs)
                .Where(s => s.Course != null && s.Course.Id == courseId)
                .ToListAsync();
        }

        // GET: api/Sessions/5
        [HttpGet("{id}")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<Session>> GetSession(int id)
        {
            var session = await context.Sessions
                .Include(s => s.SessionPDFs)
                .Include(s => s.Course)
                    .ThenInclude(c => c!.Students)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (session == null)
            {
                return NotFound();
            }

            var userId = GetUserId();
            if (User?.IsInRole("Admin") != true && userId != null)
            {
                if (session.Course == null
                    || session.Course.Deadline < Today
                    || !session.Course.Students.Any(student => student.Id == userId))
                {
                    return NotFound();
                }
            }

            return session;
        }

        // PUT: api/Sessions/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PutSession(int id, Session session)
        {
            if (id != session.Id)
            {
                return BadRequest();
            }

            context.Entry(session).State = EntityState.Modified;

            try
            {
                await context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SessionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Sessions
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Session>> PostSession([FromBody] CreateSessionDto dto, [FromQuery] int? courseId = null)
        {
            var session = new Session
            {
                StartTime = dto.StartTime ?? DateTime.UtcNow,
                Title = dto.Title,
                Url = dto.Url,
                SessionPDFs = new List<SessionPDF>()
            };

            if (courseId.HasValue)
            {
                var course = await context.Courses.FindAsync(courseId.Value);
                if (course != null) session.Course = course;
            }
            context.Sessions.Add(session);
            await context.SaveChangesAsync();

            return CreatedAtAction("GetSession", new { id = session.Id }, session);
        }

        // DELETE: api/Sessions/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteSession(int id)
        {
            var session = await context.Sessions
                .Include(s => s.SessionPDFs)
                .FirstOrDefaultAsync(s => s.Id == id);
            if (session == null)
            {
                return NotFound();
            }

            foreach (var pdf in session.SessionPDFs.ToList())
            {
                try
                {
                    await storageService.DeleteFileAsync(pdf.Url);
                }
                catch (FileNotFoundException)
                {
                    // File already missing from storage.
                }
            }

            context.Sessions.Remove(session);
            await context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPost("pdf/{id}")]
        [Authorize(Roles = "Admin")]
        [RequestSizeLimit(100L * 1024L * 1024L)]
        [RequestFormLimits(MultipartBodyLengthLimit = 100L * 1024L * 1024L)]
        public async Task<IActionResult> AddPDFToSession(
            int id,
            [FromForm] IFormFile? file,
            [FromForm] string title)
        {
            var session = await context.Sessions
                .Include(s => s.SessionPDFs)
                .FirstOrDefaultAsync(s => s.Id == id);
            if (session == null)
            {
                return NotFound();
            }

            if (file == null || file.Length == 0)
            {
                return BadRequest("PDF file is required.");
            }

            var path = await storageService.UploadFileAsync(file, "sessions");
            session.SessionPDFs.Add(new SessionPDF { Session = session, Id = 0, Title = string.IsNullOrWhiteSpace(title) ? file.FileName : title, Url = path });
            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("pdf/{sessionId}/{pdfId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemovePDFFromSession(int sessionId, int pdfId)
        {
            var session = await context.Sessions
                .Include(s => s.SessionPDFs)
                .FirstOrDefaultAsync(s => s.Id == sessionId);
            if (session == null)
            {
                return NotFound();
            }
            var pdf = session.SessionPDFs.FirstOrDefault(p => p.Id == pdfId);
            if (pdf == null)
            {
                return NotFound();
            }

            try
            {
                await storageService.DeleteFileAsync(pdf.Url);
            }
            catch (FileNotFoundException)
            {
                // File not found in storage
            }

            session.SessionPDFs.Remove(pdf);
            await context.SaveChangesAsync();
            return NoContent();
        }
        private bool SessionExists(int id)
        {
            return context.Sessions.Any(e => e.Id == id);
        }
    }
}
