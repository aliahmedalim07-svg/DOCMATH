using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DrZiadMathIGAPI.Models;
using Microsoft.AspNetCore.Authorization;

namespace DrZiadMathIGAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionsController : ControllerBase
    {
        private readonly DragonLMSDbContext _context;
        private readonly Services.IStorageService _storageService;

        public QuestionsController(DragonLMSDbContext context, Services.IStorageService storageService)
        {
            _context = context;
            _storageService = storageService;
        }

        // GET: api/Questions
        [HttpGet]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult> GetQuestions()
        {
            var questions = await _context.Questions
                .Include(q => q.Choices)
                .Include(q => q.BookQuestions)
                    .ThenInclude(bq => bq.Book)
                .Include(q => q.QuestionBelongings)
                    .ThenInclude(qb => qb.QuestionGroup)
                .Include(q => q.Topic)
                .OrderBy(q => q.OrderIndex)
                .ToListAsync();

            var result = questions.Select(q => new
            {
                q.Id,
                q.Text,
                q.QuestionImageUrl,
                q.ExpanationImageUrl,
                q.ExplanationVideoUrl,
                q.Difficulty,
                q.YearAppeared,
                q.MonthAppeared,
                q.Explanation,
                q.OrderIndex,
                q.TopicId,
                Topic = q.Topic == null ? null : new { q.Topic.Id, q.Topic.Name },
                Choices = q.Choices.Select(c => new { c.Id, c.Text, c.IsCorrect, c.ChoiceImageUrl }),
                BookQuestions = q.BookQuestions.Select(bq => new { Book = new { bq.Book.Id, bq.Book.Title } }),
                QuestionBelongings = q.QuestionBelongings.Select(qb => new { QuestionGroup = new { qb.QuestionGroup.Id, qb.QuestionGroup.Title, Type = (int)qb.QuestionGroup.Type } })
            });

            return Ok(result);
        }

        // GET: api/Questions/5
        [HttpGet("{id}")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<Question>> GetQuestion(int id)
        {
            var question = await _context.Questions.Include(q => q.Choices).Include(q => q.Topic)
                .FirstOrDefaultAsync(q => q.Id == id);

            if (question == null)
            {
                return NotFound();
            }

            return question;
        }

        // PUT: api/Questions/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PutQuestion(int id, Question question)
        {
            if (id != question.Id)
            {
                return BadRequest();
            }

            var existingQuestion = await _context.Questions.Include(q => q.Choices).FirstOrDefaultAsync(q => q.Id == id);
            if (existingQuestion == null)
            {
                return NotFound();
            }

            // Map top-level properties
            _context.Entry(existingQuestion).CurrentValues.SetValues(question);

            // Update Choices
            // Preserve existing choice image URLs for choices that already exist
            var oldChoiceImages = existingQuestion.Choices
                .Where(c => c.ChoiceImageUrl != null)
                .ToDictionary(c => c.Id, c => c.ChoiceImageUrl);

            _context.Choices.RemoveRange(existingQuestion.Choices);
            existingQuestion.Choices = question.Choices;

            // Carry over existing choice image URLs if the incoming choice has none
            foreach (var choice in existingQuestion.Choices)
            {
                if (string.IsNullOrEmpty(choice.ChoiceImageUrl) && oldChoiceImages.TryGetValue(choice.Id, out var existingUrl))
                {
                    choice.ChoiceImageUrl = existingUrl;
                }
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!QuestionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            var updatedQuestion = await _context.Questions
                .Include(q => q.Choices)
                .FirstOrDefaultAsync(q => q.Id == id);

            return Ok(updatedQuestion);
        }

        // POST: api/Questions
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Question>> PostQuestion(Question question)
        {
            _context.Questions.Add(question);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetQuestion", new { id = question.Id }, question);
        }

        // DELETE: api/Questions/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteQuestion(int id)
        {
            var question = await _context.Questions
                .Include(q => q.Choices)
                .Include(q => q.BookQuestions)
                .Include(q => q.QuestionBelongings)
                .FirstOrDefaultAsync(q => q.Id == id);

            if (question == null)
            {
                return NotFound();
            }

            // Remove related associations manually to avoid FK constraint issues
            if (question.BookQuestions != null) _context.BookQuestions.RemoveRange(question.BookQuestions);
            if (question.QuestionBelongings != null) _context.QuestionBelongings.RemoveRange(question.QuestionBelongings);
            if (question.Choices != null) _context.Choices.RemoveRange(question.Choices);

            _context.Questions.Remove(question);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPost("{id}/add-to-books")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddQuestionToBooks(int id, [FromBody] List<int> bookIds)
        {
            var question = await _context.Questions.FindAsync(id);
            if (question == null)
            {
                return NotFound($"Question with ID {id} not found.");
            }

            foreach (var bookId in bookIds)
            {
                var book = await _context.Books
                                         .Include(b => b.BookQuestions)
                                         .ThenInclude(bq => bq.Question)
                                         .FirstOrDefaultAsync(b => b.Id == bookId);
                if (book == null)
                {
                    return NotFound($"Book with ID {bookId} not found.");
                }

                if (!book.BookQuestions.Any(bq => bq.Question != null && bq.Question.Id == id))
                {
                    _context.BookQuestions.Add(new BookQuestion { Book = book, Question = question });
                }
            }

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpPost("{id}/upload-question-image")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UploadQuestionImage(int id, [FromForm] IFormFile imageFile)
        {
            var question = await _context.Questions.FindAsync(id);
            if (question == null) return NotFound();

            if (imageFile != null && imageFile.Length > 0)
            {
                var url = await _storageService.UploadFileAsync(imageFile, "questionImages");
                question.QuestionImageUrl = url;
                await _context.SaveChangesAsync();
            }

            return Ok(new { url = question.QuestionImageUrl });
        }

        [HttpPost("{id}/upload-explanation-image")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UploadExplanationImage(int id, [FromForm] IFormFile imageFile)
        {
            var question = await _context.Questions.FindAsync(id);
            if (question == null) return NotFound();

            if (imageFile != null && imageFile.Length > 0)
            {
                var url = await _storageService.UploadFileAsync(imageFile, "explanationImages");
                question.ExpanationImageUrl = url;
                await _context.SaveChangesAsync();
            }

            return Ok(new { url = question.ExpanationImageUrl });
        }

        [HttpPost("{id}/choices/{choiceId}/upload-image")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UploadChoiceImage(int id, int choiceId, [FromForm] IFormFile imageFile)
        {
            var choice = await _context.Choices.FirstOrDefaultAsync(c => c.Id == choiceId && c.Question != null && c.Question.Id == id);
            if (choice == null) return NotFound();

            if (imageFile != null && imageFile.Length > 0)
            {
                var url = await _storageService.UploadFileAsync(imageFile, "choiceImages");
                choice.ChoiceImageUrl = url;
                await _context.SaveChangesAsync();
            }

            return Ok(new { url = choice.ChoiceImageUrl });
        }

        private bool QuestionExists(int id)
        {
            return _context.Questions.Any(e => e.Id == id);
        }
    }
}
