using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using DrZiadMathIGAPI.Dtos;
using DrZiadMathIGAPI.Models;
using DrZiadMathIGAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace DrZiadMathIGAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController(UserManager<ApplicationUser> userManager, IConfiguration configuration, DragonLMSDbContext context, IWhatsappService whathsappService) : ControllerBase
    {
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<ActionResult<AuthResponse>> Register([FromBody] RegisterRequest request)
        {
            var existingUser = await userManager.FindByNameAsync(request.Username);
            if (existingUser is not null)
            {
                return Conflict("A user with this username already exists.");
            }

            // Return bad request if the user is not admin and trying to register an admin
            if (request.AccountType == AccountType.Admin && (User.Identity?.IsAuthenticated != true || !User.IsInRole("Admin")))
            {
                return BadRequest("Only admins can register new admin accounts.");
            }

            if (request.AccountType == AccountType.Parent && request.PhoneNumber is null)
            {
                return BadRequest("Phone number is required for parent accounts.");
            }

            if (request.AccountType == AccountType.Student && string.IsNullOrWhiteSpace(request.ParentPhoneNumber))
            {
                return BadRequest("Parent phone number is required for student accounts.");
            }

            var formattedPhone = FormatPhoneNumber(request.PhoneNumber);
            var formattedParentPhone = FormatPhoneNumber(request.ParentPhoneNumber);

            if (request.AccountType == AccountType.Parent)
            {
                var child = await context.Users.FirstOrDefaultAsync(u => u.ParentPhoneNumber == formattedPhone && u.AccountType == AccountType.Student);
                if (child is null)
                {
                    return BadRequest("No child with this parent phone number exists.");
                }
            }

            var user = new ApplicationUser
            {
                UserName = request.Username,
                Email = $"{request.Username}@dragon.local",
                Name = request.Name,
                PhoneNumber = formattedPhone,
                ParentPhoneNumber = formattedParentPhone,
                FullName = request.Name,
                AccountType = request.AccountType
            };

            var result = await userManager.CreateAsync(user, request.Password);
            if (!result.Succeeded)
            {
                return BadRequest(result.Errors);
            }

            var roleName = request.AccountType switch
            {
                AccountType.Admin => "Admin",
                AccountType.Parent => "Parent",
                AccountType.Student => "Student",
                _ => "Student"
            };

            var roleResult = await userManager.AddToRoleAsync(user, roleName);
            if (!roleResult.Succeeded)
            {
                return BadRequest(roleResult.Errors);
            }

            var registerResponse = await CreateAuthResponseAsync(user);
            if (User?.Identity?.IsAuthenticated != true)
            {
                SetAuthCookie(registerResponse.Token);
            }
            return Ok(registerResponse);
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<ActionResult<AuthResponse>> Login([FromBody] LoginRequest request)
        {
            var user = await userManager.FindByNameAsync(request.Username);
            if (user is null || !await userManager.CheckPasswordAsync(user, request.Password))
            {
                return Unauthorized();
            }

            var loginResponse = await CreateAuthResponseAsync(user);
            SetAuthCookie(loginResponse.Token);
            return Ok(loginResponse);
        }

        [Authorize]
        [HttpGet("profile")]
        public async Task<ActionResult<UserProfileDto>> GetProfile()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId is null) return Unauthorized();

            var user = await userManager.FindByIdAsync(userId);
            if (user is null) return NotFound();

            return Ok(new UserProfileDto
            {
                Id = user.Id,
                Name = string.IsNullOrWhiteSpace(user.Name) ? (user.UserName ?? "Unknown") : user.Name,
                Phone = user.PhoneNumber,
                AccountType = user.AccountType,
            });
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("students")]
        public ActionResult<IEnumerable<UserProfileDto>> GetStudents()
        {
            var students = context.Users
                .Where(user => user.AccountType == AccountType.Student)
                .Include(u => u.Courses)
                .ToList();

            var result = students.Select(user => new UserProfileDto
            {
                Id = user.Id,
                Name = string.IsNullOrWhiteSpace(user.Name) ? (user.UserName ?? "Unknown") : user.Name,
                UserName = user.UserName,
                Phone = user.PhoneNumber,
                ParentPhone = user.ParentPhoneNumber,
                AccountType = AccountType.Student,
                CourseIds = [.. user.Courses.Select(c => c.Id)]
            }).ToList();

            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("students/{studentId}")]
        public async Task<IActionResult> UpdateStudent(string studentId, [FromBody] UpdateStudentRequest request)
        {
            var student = await userManager.Users
                .Include(u => u.Courses)
                .FirstOrDefaultAsync(u => u.Id == studentId && u.AccountType == AccountType.Student);
            if (student is null) return NotFound("Student not found.");

            if (!string.IsNullOrWhiteSpace(request.Name))
            {
                student.Name = request.Name;
                student.FullName = request.Name;
            }

            if (request.Phone != null)
                student.PhoneNumber = FormatPhoneNumber(request.Phone);

            if (request.ParentPhone != null)
                student.ParentPhoneNumber = FormatPhoneNumber(request.ParentPhone);

            var result = await userManager.UpdateAsync(student);
            if (!result.Succeeded)
                return BadRequest(result.Errors);

            return Ok(new UserProfileDto
            {
                Id = student.Id,
                UserName = student.UserName,
                Name = student.Name ?? student.UserName ?? "Unknown",
                Phone = student.PhoneNumber,
                ParentPhone = student.ParentPhoneNumber,
                AccountType = AccountType.Student,
                CourseIds = student.Courses?.Select(c => c.Id).ToList() ?? new()
            });
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("students/{studentId}/add-course/{courseId}")]
        public async Task<IActionResult> AddStudentToCourse(string studentId, int courseId)
        {
            var user = await context.Users.Include(u => u.Courses).FirstOrDefaultAsync(u => u.Id == studentId);
            if (user is null) return NotFound("Student not found.");

            var course = await context.Courses.FindAsync(courseId);
            if (course is null) return NotFound("Course not found.");

            if (user.Courses.Any(c => c.Id == courseId))
                return BadRequest("Student is already enrolled in this course.");

            user.Courses.Add(course);
            await context.SaveChangesAsync();

            var message = $@"السلام عليكم، مساء الخير.🌹
تم تفعيل الحساب بنجاح
#course: {course.Title}
#student name: {user.FullName}
#username: {user.UserName}

🎯اليوزر والباسورد ناخدهم من ابننا أو بنتنا

بالتوفيق تيم دكتور زياد🤝♥️

Best wishes team Dr. Ziad Mohamed❤️";
            await whathsappService.SendMessageAsync(user.ParentPhoneNumber, message);

            return NoContent();
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("students/{studentId}/remove-course/{courseId}")]
        public async Task<IActionResult> RemoveStudentFromCourse(string studentId, int courseId)
        {
            var user = await context.Users.Include(u => u.Courses).FirstOrDefaultAsync(u => u.Id == studentId);
            if (user is null) return NotFound("Student not found.");

            var course = user.Courses.FirstOrDefault(c => c.Id == courseId);
            if (course is null) return NotFound("Student is not enrolled in this course.");

            user.Courses.Remove(course);
            await context.SaveChangesAsync();
            return NoContent();
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("students/{studentId}")]
        public async Task<IActionResult> DeleteStudent(string studentId)
        {
            var user = await userManager.FindByIdAsync(studentId);
            if (user is null) return NotFound("Student not found.");

            var result = await userManager.DeleteAsync(user);
            if (!result.Succeeded) return BadRequest(result.Errors);

            return NoContent();
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("users/{userId}/reset-password")]
        public async Task<IActionResult> ResetUserPassword(string userId, [FromBody] AdminResetPasswordRequest request)
        {
            var user = await userManager.FindByIdAsync(userId);
            if (user is null) return NotFound("User not found.");

            var token = await userManager.GeneratePasswordResetTokenAsync(user);
            var result = await userManager.ResetPasswordAsync(user, token, request.NewPassword);
            if (!result.Succeeded) return BadRequest(result.Errors);

            return NoContent();
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("parents")]
        public ActionResult<IEnumerable<UserProfileDto>> GetParents()
        {
            var parents = context.Users
                .Where(user => user.AccountType == AccountType.Parent)
                .ToList();

            var result = parents.Select(user => new UserProfileDto
            {
                Id = user.Id,
                Name = string.IsNullOrWhiteSpace(user.Name) ? (user.UserName ?? "Unknown") : user.Name,
                UserName = user.UserName,
                Phone = user.PhoneNumber,
                AccountType = AccountType.Parent
            }).ToList();

            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("parents/{parentId}")]
        public async Task<IActionResult> DeleteParent(string parentId)
        {
            var user = await userManager.FindByIdAsync(parentId);
            if (user is null) return NotFound("Parent not found.");

            var result = await userManager.DeleteAsync(user);
            if (!result.Succeeded) return BadRequest(result.Errors);

            return NoContent();
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("admins")]
        public ActionResult<IEnumerable<UserProfileDto>> GetAdmins()
        {
            var admins = context.Users
                .Where(user => user.AccountType == AccountType.Admin)
                .ToList();

            var result = admins.Select(user => new UserProfileDto
            {
                Id = user.Id,
                Name = string.IsNullOrWhiteSpace(user.Name) ? (user.UserName ?? "Unknown") : user.Name,
                UserName = user.UserName,
                Phone = user.PhoneNumber,
                AccountType = AccountType.Admin
            }).ToList();

            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("admins/{adminId}")]
        public async Task<IActionResult> DeleteAdmin(string adminId)
        {
            var user = await userManager.FindByIdAsync(adminId);
            if (user is null) return NotFound("Admin not found.");

            var result = await userManager.DeleteAsync(user);
            if (!result.Succeeded) return BadRequest(result.Errors);

            return NoContent();
        }

        [Authorize(Roles = "Parent")]
        [HttpGet("my-children")]
        public async Task<ActionResult<IEnumerable<ParentChildDto>>> GetMyChildren()
        {
            var userId = User.FindFirstValue(System.Security.Claims.ClaimTypes.NameIdentifier);
            if (userId is null) return Unauthorized();

            var parent = await userManager.FindByIdAsync(userId);
            if (parent is null) return NotFound("Parent not found.");

            var children = await context.Users
                .Where(u => u.ParentPhoneNumber == parent.PhoneNumber && u.AccountType == AccountType.Student)
                .ToListAsync();

            var result = new List<ParentChildDto>();
            foreach (var child in children)
            {
                var lastTry = await context.Tries
                    .Where(t => t.User.Id == child.Id)
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                result.Add(new ParentChildDto
                {
                    Id = child.Id,
                    Name = string.IsNullOrWhiteSpace(child.Name) ? (child.UserName ?? "Unknown") : child.Name,
                    Phone = child.PhoneNumber,
                    LastActivity = lastTry?.CreatedAt
                });
            }

            return Ok(result);
        }

        [Authorize(Roles = "Parent,Student,Admin")]
        [HttpGet("student/{studentId}/stats")]
        public async Task<ActionResult<StudentStatsDto>> GetStudentStats(string studentId)
        {
            ApplicationUser? targetUser = null;

            if (studentId == "me")
            {
                var currentUserId = User.FindFirstValue(System.Security.Claims.ClaimTypes.NameIdentifier);
                if (currentUserId is null) return Unauthorized();
                targetUser = await userManager.FindByIdAsync(currentUserId);
            }
            else
            {
                targetUser = await context.Users.FindAsync(studentId);
            }

            if (targetUser is null) return NotFound("Student not found.");

            if (User.IsInRole("Parent") && targetUser.ParentPhoneNumber != (await userManager.GetUserAsync(User))?.PhoneNumber)
                return Forbid();

            return await BuildStudentStatsAsync(targetUser.Id);
        }

        private async Task<StudentStatsDto> BuildStudentStatsAsync(string studentId)
        {
            var student = await context.Users.FindAsync(studentId);
            if (student is null) return new StudentStatsDto();

            var tries = await context.Tries
                .Include(t => t.QuestionGroup)
                .Where(t => t.User.Id == studentId)
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();

            var userAnswers = await context.UserAnswers
                .Include(a => a.Question)
                .Include(a => a.SelectedChoice)
                .Where(a => a.User.Id == studentId)
                .ToListAsync();

            var weakPoints = userAnswers
                .GroupBy(a => a.Question.Id)
                .Count(g => g.Count(ua => !ua.SelectedChoice.IsCorrect) >= 2);

            var completedAssignments = tries.Select(t => t.QuestionGroup?.Id).Distinct().Count();
            var questionGroupIds = tries
                .Where(t => t.QuestionGroup != null)
                .Select(t => t.QuestionGroup!.Id)
                .Distinct()
                .ToList();
            var questionTotals = await context.QuestionBelongings
                .Where(b => questionGroupIds.Contains(b.QuestionGroup.Id))
                .GroupBy(b => b.QuestionGroup.Id)
                .Select(g => new { QuestionGroupId = g.Key, Total = g.Count() })
                .ToDictionaryAsync(item => item.QuestionGroupId, item => item.Total);

            int GetTryTotal(Try tryRecord, int fallbackTotal)
            {
                var questionGroupId = tryRecord.QuestionGroup?.Id ?? 0;
                return questionTotals.TryGetValue(questionGroupId, out var total) && total > 0
                    ? total
                    : fallbackTotal;
            }

            double totalScore = 0;
            if (tries.Any())
            {
                foreach (var tryRecord in tries)
                {
                    var answers = userAnswers.Where(a => a.Try.Id == tryRecord.Id).ToList();
                    var correctCount = answers.Count(a => a.SelectedChoice.IsCorrect);
                    var total = GetTryTotal(tryRecord, answers.Count);
                    if (total > 0)
                    {
                        totalScore += (double)correctCount / total * 100;
                    }
                }
                totalScore /= tries.Count;
            }

            var recentTries = tries.Take(7).Select(t =>
            {
                var answers = userAnswers.Where(a => a.Try.Id == t.Id).ToList();
                var correctCount = answers.Count(a => a.SelectedChoice.IsCorrect);
                var total = GetTryTotal(t, answers.Count);
                return new TryDto
                {
                    Id = t.Id,
                    QuestionGroupTitle = t.QuestionGroup?.Title ?? "Unknown",
                    QuestionGroupId = t.QuestionGroup?.Id ?? 0,
                    SubmittedAt = t.CreatedAt,
                    TotalQuestions = total,
                    CorrectAnswers = correctCount,
                    ScorePercentage = total > 0 ? (double)correctCount / total * 100 : 0
                };
            }).ToList();

            // Calculate student rank
            var (studentRank, rankedStudents) = await CalculateStudentRankForStatsAsync(studentId);

            double totalScoreOutOf800 = totalScore > 0 ? Math.Round(totalScore / 100 * 800, 1) : 0;

            return new StudentStatsDto
            {
                StudentId = student.Id,
                StudentName = string.IsNullOrWhiteSpace(student.Name) ? (student.UserName ?? "Unknown") : student.Name,
                StudentPhone = student.PhoneNumber,
                TotalScore = Math.Round(totalScore, 1),
                TotalScoreOutOf800 = totalScoreOutOf800,
                WeakPointsCount = weakPoints,
                MistakeCount = tries.Count,
                CompletedAssignments = completedAssignments,
                StudentRank = studentRank,
                RankedStudents = rankedStudents,
                LastActivity = tries.FirstOrDefault()?.CreatedAt,
                RecentTries = recentTries
            };
        }

        private async Task<(int Rank, int RankedStudents)> CalculateStudentRankForStatsAsync(string studentId)
        {
            var allTries = await context.Tries
                .Include(t => t.User)
                .ToListAsync();
            var tryIds = allTries.Select(t => t.Id).ToList();
            if (tryIds.Count == 0) return (0, 0);

            var answerCounts = await context.UserAnswers
                .Include(a => a.SelectedChoice)
                .Where(a => tryIds.Contains(a.Try.Id))
                .GroupBy(a => a.Try.Id)
                .Select(g => new
                {
                    TryId = g.Key,
                    Total = g.Count(),
                    Correct = g.Count(a => a.SelectedChoice.IsCorrect)
                })
                .ToListAsync();

            var scoreByTry = answerCounts.ToDictionary(
                item => item.TryId,
                item => item.Total > 0 ? (double)item.Correct / item.Total * 100 : 0);

            var ranked = allTries
                .Where(t => scoreByTry.ContainsKey(t.Id))
                .GroupBy(t => t.User.Id)
                .Select(g => new
                {
                    StudentId = g.Key,
                    AverageScore = g.Average(t => scoreByTry[t.Id])
                })
                .OrderByDescending(item => item.AverageScore)
                .ThenBy(item => item.StudentId)
                .ToList();

            var rank = ranked.FindIndex(item => item.StudentId == studentId);
            return (rank >= 0 ? rank + 1 : 0, ranked.Count);
        }

        private static string FormatPhoneNumber(string? phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber)) return string.Empty;

            var cleaned = new string(phoneNumber.Where(char.IsDigit).ToArray());

            if (cleaned.Length == 10 && cleaned[0] == '1')
                return "20" + cleaned;

            if (cleaned.Length == 11 && cleaned[0] == '0')
                return "20" + cleaned[1..];

            if (cleaned.Length == 12 && cleaned[..2] == "20")
                return cleaned;

            if (cleaned.Length == 13 && cleaned[..3] == "200")
                return cleaned[1..];

            return cleaned;
        }

        private void SetAuthCookie(string token)
        {
            Response?.Cookies.Append("dr-ziad-math-ig-token", token, new CookieOptions
            {
                HttpOnly = true,
                SameSite = SameSiteMode.Lax,
                Secure = false,
                MaxAge = TimeSpan.FromMinutes(int.Parse(configuration.GetSection("Jwt")["ExpiresInMinutes"] ?? "60")),
                Path = "/"
            });
        }

        private async Task<AuthResponse> CreateAuthResponseAsync(ApplicationUser user)
        {
            var roles = await userManager.GetRolesAsync(user);
            var jwtSection = configuration.GetSection("Jwt");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSection["Key"]!));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, user.Id),
                new(ClaimTypes.Name, user.UserName ?? string.Empty)
            };

            claims.AddRange(roles.Select(role => new Claim(ClaimTypes.Role, role)));

            var token = new JwtSecurityToken(
                issuer: jwtSection["Issuer"],
                audience: jwtSection["Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(int.Parse(jwtSection["ExpiresInMinutes"] ?? "60")),
                signingCredentials: credentials);

            return new AuthResponse(new JwtSecurityTokenHandler().WriteToken(token), roles);
        }
    }
}
