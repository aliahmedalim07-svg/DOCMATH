using System.Security.Claims;
using DrZiadMathIGAPI.Dtos;
using DrZiadMathIGAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DrZiadMathIGAPI.Controllers
{
    [Authorize(Roles = "Parent,Student")]
    [ApiController]
    [Route("api/[controller]")]
    public class ParentController(UserManager<ApplicationUser> userManager, DragonLMSDbContext context) : ControllerBase
    {
        [HttpGet("child-stats/{childId}")]
        public async Task<ActionResult<ParentDashboardDto>> GetChildStats(string childId, [FromQuery] int? courseId = null)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId is null) return Unauthorized();

            ApplicationUser? child;
            if (User.IsInRole("Student"))
            {
                if (childId != userId) return Forbidden("You can only view your own stats.");
                child = await context.Users.Include(u => u.Courses).FirstOrDefaultAsync(u => u.Id == userId);
                if (child is null) return NotFound("User not found.");
            }
            else
            {
                var parent = await userManager.FindByIdAsync(userId);
                if (parent is null) return NotFound("Parent not found.");

                child = await context.Users
                    .Include(u => u.Courses)
                    .FirstOrDefaultAsync(u => u.Id == childId && u.ParentPhoneNumber == parent.PhoneNumber && u.AccountType == AccountType.Student);

                if (child is null) return Forbidden("This child does not belong to you or does not exist.");
            }

            // 1. Get all Tries and UserAnswers for context
            var triesQuery = context.Tries
                .Include(t => t.QuestionGroup)
                .Where(t => t.User.Id == childId);

            var userAnswersQuery = context.UserAnswers
                .Include(a => a.Question)
                    .ThenInclude(q => q.Choices)
                .Include(a => a.Question)
                    .ThenInclude(q => q.QuestionBelongings)
                        .ThenInclude(qb => qb.QuestionGroup)
                .Include(a => a.SelectedChoice)
                .Include(a => a.Try)
                .Where(a => a.User.Id == childId);

            if (courseId.HasValue)
            {
                triesQuery = triesQuery.Where(t => t.QuestionGroup != null && t.QuestionGroup.Course != null && t.QuestionGroup.Course.Id == courseId.Value);
                userAnswersQuery = userAnswersQuery.Where(a => a.Question.QuestionBelongings.Any(qb => qb.QuestionGroup != null && qb.QuestionGroup.Course != null && qb.QuestionGroup.Course.Id == courseId.Value));
            }

            var tries = await triesQuery.OrderBy(t => t.CreatedAt).ToListAsync();
            var userAnswers = await userAnswersQuery.ToListAsync();
            var questionGroupIds = tries
                .Where(t => t.QuestionGroup != null)
                .Select(t => t.QuestionGroup!.Id)
                .Distinct()
                .ToList();
            var questionTotals = await context.QuestionBelongings
                .Where(b => questionGroupIds.Contains(b.QuestionGroup.Id))
                .GroupBy(b => b.QuestionGroup.Id)
                .Select(g => new { QuestionGroupId = g.Key, Total = g.Count() })
                .ToDictionaryAsync(item => item.QuestionGroupId, item => item.Total);

            int GetTryTotal(Try tryRecord, int fallbackTotal)
            {
                var questionGroupId = tryRecord.QuestionGroup?.Id ?? 0;
                return questionTotals.TryGetValue(questionGroupId, out var total) && total > 0
                    ? total
                    : fallbackTotal;
            }

            // 2. Map Mistakes
            var mistakes = userAnswers
                .Where(a => !a.SelectedChoice.IsCorrect)
                .OrderByDescending(a => a.Try.CreatedAt)
                .Take(20)
                .Select(a => new MistakeDto
                {
                    QuestionId = a.Question.Id,
                    QuestionText = a.Question.Text ?? string.Empty,
                    QuestionImageUrl = a.Question.QuestionImageUrl,
                    SelectedChoiceText = a.SelectedChoice.Text,
                    CorrectChoiceText = a.Question.Choices.FirstOrDefault(c => c.IsCorrect)?.Text ?? "Unknown",
                    Date = a.Try.CreatedAt
                })
                .ToList();

            // 3. Map Weak Points (Categorized by Skills)
            var skillAnswers = userAnswers
                .SelectMany(a => a.Question.QuestionBelongings
                    .Where(qb => qb.QuestionGroup.Type == QuestionGroupType.Skills)
                    .Select(qb => new { Answer = a, Skill = qb.QuestionGroup }))
                .GroupBy(x => x.Skill.Title)
                .Select(g => new WeakPointDto
                {
                    CategoryName = g.Key,
                    MistakeCount = g.Count(x => !x.Answer.SelectedChoice.IsCorrect),
                    Accuracy = g.Any() ? (double)g.Count(x => x.Answer.SelectedChoice.IsCorrect) / g.Count() * 100 : 0
                })
                .OrderBy(wp => wp.Accuracy)
                .ToList();

            // 4. Map General Progress
            var assignmentQuery = context.QuestionGroups
                .Where(qg => qg.Type == QuestionGroupType.Assignments && child.Courses.Select(c => c.Id).Contains(qg.Course != null ? qg.Course.Id : -1));

            if (courseId.HasValue)
            {
                assignmentQuery = assignmentQuery.Where(qg => qg.Course != null && qg.Course.Id == courseId.Value);
            }

            var totalAssignments = await assignmentQuery.CountAsync();

            var completedAssignments = tries
                .Where(t => t.QuestionGroup != null && t.QuestionGroup.Type == QuestionGroupType.Assignments)
                .Select(t => t.QuestionGroup!.Id)
                .Distinct()
                .Count();

            double averageScore = 0;
            if (tries.Any())
            {
                var tryScores = tries.Select(t =>
                {
                    var answers = userAnswers.Where(a => a.Try.Id == t.Id).ToList();
                    var total = GetTryTotal(t, answers.Count);
                    return total > 0 ? (double)answers.Count(a => a.SelectedChoice.IsCorrect) / total * 100 : 0;
                });
                averageScore = tryScores.Average();
            }

            var scoreTrend = tries
                .Select(t =>
                {
                    var answers = userAnswers.Where(a => a.Try.Id == t.Id).ToList();
                    var total = GetTryTotal(t, answers.Count);
                    return new ScoreTrendDto
                    {
                        Date = t.CreatedAt,
                        Score = total > 0 ? (double)answers.Count(a => a.SelectedChoice.IsCorrect) / total * 100 : 0
                    };
                })
                .OrderBy(st => st.Date)
                .ToList();

            var (studentRank, rankedStudents) = await CalculateStudentRankAsync(childId);

            var generalProgress = new GeneralProgressDto
            {
                AverageScore = Math.Round(averageScore, 1),
                CompletedAssignments = completedAssignments,
                TotalAssignments = totalAssignments,
                StudentRank = studentRank,
                RankedStudents = rankedStudents,
                ScoreTrend = scoreTrend
            };

            // 5. Map Daily Activity (for chart + click details)
            var dailyActivity = tries
                .GroupBy(t => t.CreatedAt.Date)
                .Select(g =>
                {
                    var dayAnswers = userAnswers.Where(a => a.Try.CreatedAt.Date == g.Key).ToList();
                    var dayTries = g.ToList();
                    var details = dayTries.Select(t =>
                    {
                        var answers = dayAnswers.Where(a => a.Try.Id == t.Id).ToList();
                        var correct = answers.Count(a => a.SelectedChoice.IsCorrect);
                        var total = GetTryTotal(t, answers.Count);
                        return new DailyActivityDetailDto
                        {
                            TryId = t.Id,
                            ActivityTitle = t.QuestionGroup?.Title ?? "Activity",
                            CorrectAnswers = correct,
                            TotalQuestions = total,
                            Score = total > 0 ? Math.Round((double)correct / total * 100, 1) : 0,
                            SubmittedAt = t.CreatedAt
                        };
                    }).ToList();
                    var avgScore = details.Any() ? details.Average(d => d.Score) : 0;
                    return new DailyActivityDto
                    {
                        Date = g.Key,
                        AttemptsCount = dayTries.Count,
                        AverageScore = Math.Round(avgScore, 1),
                        Details = details
                    };
                })
                .OrderBy(d => d.Date)
                .ToList();

            return Ok(new ParentDashboardDto
            {
                GeneralProgress = generalProgress,
                WeakPoints = skillAnswers,
                Mistakes = mistakes,
                DailyActivity = dailyActivity
            });
        }

        private ActionResult Forbidden(string message)
        {
            return StatusCode(403, message);
        }

        private async Task<(int Rank, int RankedStudents)> CalculateStudentRankAsync(string childId)
        {
            var tries = await context.Tries
                .Include(t => t.User)
                .ToListAsync();
            var tryIds = tries.Select(t => t.Id).ToList();
            if (tryIds.Count == 0) return (0, 0);

            var answerCounts = await context.UserAnswers
                .Include(a => a.SelectedChoice)
                .Where(a => tryIds.Contains(a.Try.Id))
                .GroupBy(a => a.Try.Id)
                .Select(g => new
                {
                    TryId = g.Key,
                    Total = g.Count(),
                    Correct = g.Count(a => a.SelectedChoice.IsCorrect)
                })
                .ToListAsync();

            var scoreByTry = answerCounts.ToDictionary(
                item => item.TryId,
                item => item.Total > 0 ? (double)item.Correct / item.Total * 100 : 0);

            var ranked = tries
                .Where(t => scoreByTry.ContainsKey(t.Id))
                .GroupBy(t => t.User.Id)
                .Select(g => new
                {
                    StudentId = g.Key,
                    AverageScore = g.Average(t => scoreByTry[t.Id])
                })
                .OrderByDescending(item => item.AverageScore)
                .ThenBy(item => item.StudentId)
                .ToList();

            var rank = ranked.FindIndex(item => item.StudentId == childId);
            return (rank >= 0 ? rank + 1 : 0, ranked.Count);
        }
    }
}
