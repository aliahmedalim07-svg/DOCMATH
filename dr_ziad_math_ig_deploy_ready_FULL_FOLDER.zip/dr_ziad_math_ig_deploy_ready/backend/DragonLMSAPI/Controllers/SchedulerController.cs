﻿using DrZiadMathIGAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DrZiadMathIGAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SchedulerController(ISchedulerService schedulerService) : ControllerBase
    {
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> ConfigureWeeklyExam(DayOfWeek day, int numQuestions)
        {
            schedulerService.ConfigureExamWeeklyJob(day, numQuestions);
            return Ok();
        }
    }
}
