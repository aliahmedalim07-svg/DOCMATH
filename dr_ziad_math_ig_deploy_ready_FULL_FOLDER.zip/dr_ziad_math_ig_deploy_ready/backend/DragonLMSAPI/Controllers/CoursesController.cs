using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DrZiadMathIGAPI.Models;
using DrZiadMathIGAPI.Dtos;
using Microsoft.AspNetCore.Authorization;
using DrZiadMathIGAPI.Services;
using System.Security.Claims;

namespace DrZiadMathIGAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoursesController : ControllerBase
    {
        private readonly DragonLMSDbContext _context;
        private readonly IWhatsappService _whathsappService;

        public CoursesController(DragonLMSDbContext context, IWhatsappService whathsappService)
        {
            _whathsappService = whathsappService;
            _context = context;
        }

        private string? GetUserId() => User?.FindFirstValue(ClaimTypes.NameIdentifier);

        // GET: api/Courses (returns courses for current user)
        [HttpGet]
        [Authorize(Roles = "Student,Admin,Parent")]
        public async Task<ActionResult<IEnumerable<CourseListDto>>> GetCourses()
        {
            var userId = GetUserId();
            var isAdmin = User.IsInRole("Admin");

            IQueryable<Course> query = _context.Courses;

            if (!isAdmin && userId != null)
            {
                if (User.IsInRole("Parent"))
                {
                    var parent = await _context.Users.FindAsync(userId);
                    if (parent != null)
                    {
                        var childIds = await _context.Users
                            .Where(u => u.ParentPhoneNumber == parent.PhoneNumber && u.AccountType == AccountType.Student)
                            .Select(u => u.Id)
                            .ToListAsync();

                        query = query.Where(c => c.Students.Any(s => childIds.Contains(s.Id)));
                    }
                }
                else
                {
                    query = query.Where(c => c.Students.Any(s => s.Id == userId));
                }
            }

            var courses = await query.ToListAsync();

            return courses.Select(c => new CourseListDto
            {
                Id = c.Id,
                Title = c.Title,
                Deadline = c.Deadline,
                IsEnded = c.Deadline < DateOnly.FromDateTime(DateTime.Now)
            }).ToList();
        }

        // GET: api/Courses/names (returns only names for dropdowns)
        [HttpGet("names")]
        [Authorize(Roles = "Student,Admin,Parent")]
        public async Task<ActionResult<IEnumerable<CourseNameDto>>> GetCourseNames()
        {
            var userId = GetUserId();
            var isAdmin = User.IsInRole("Admin");

            IQueryable<Course> query = _context.Courses;

            if (!isAdmin && userId != null)
            {
                if (User.IsInRole("Parent"))
                {
                    var parent = await _context.Users.FindAsync(userId);
                    if (parent != null)
                    {
                        var childIds = await _context.Users
                            .Where(u => u.ParentPhoneNumber == parent.PhoneNumber && u.AccountType == AccountType.Student)
                            .Select(u => u.Id)
                            .ToListAsync();

                        query = query.Where(c => c.Students.Any(s => childIds.Contains(s.Id)));
                    }
                }
                else
                {
                    query = query.Where(c => c.Students.Any(s => s.Id == userId));
                }
            }

            var courses = await query.ToListAsync();

            return courses.Select(c => new CourseNameDto
            {
                Id = c.Id,
                Title = c.Title,
                IsEnded = c.Deadline < DateOnly.FromDateTime(DateTime.Now)
            }).ToList();
        }

        // GET: api/Courses/5
        [HttpGet("{id}")]
        [Authorize(Roles = "Student,Admin,Parent")]
        public async Task<ActionResult<CourseDetailDto>> GetCourse(int id)
        {
            var course = await _context.Courses
                .Include(c => c.Books)
                .Include(c => c.QuestionGroups)
                    .ThenInclude(qg => qg.Videos)
                .Include(c => c.Sessions)
                    .ThenInclude(s => s.SessionPDFs)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null) return NotFound();

            var isEnded = course.Deadline < DateOnly.FromDateTime(DateTime.Now);

            return new CourseDetailDto
            {
                Id = course.Id,
                Title = course.Title,
                Deadline = course.Deadline,
                IsEnded = isEnded,
                Books = isEnded ? null : course.Books,
                QuestionGroups = isEnded ? null : course.QuestionGroups,
                Sessions = isEnded ? null : course.Sessions
            };
        }

        // POST: api/Courses
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<CourseDetailDto>> PostCourse([FromBody] CourseDto dto)
        {
            var course = new Course
            {
                Title = dto.Title,
                Deadline = dto.Deadline
            };

            if (dto.BookIds.Any()) course.Books = await _context.Books.Where(b => dto.BookIds.Contains(b.Id)).ToListAsync();
            if (dto.SessionIds.Any()) course.Sessions = await _context.Sessions.Where(s => dto.SessionIds.Contains(s.Id)).ToListAsync();
            if (dto.QuestionGroupIds.Any()) course.QuestionGroups = await _context.QuestionGroups.Where(q => dto.QuestionGroupIds.Contains(q.Id)).ToListAsync();
            if (dto.StudentIds.Any()) course.Students = await _context.Users.Where(u => dto.StudentIds.Contains(u.Id)).ToListAsync();

            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetCourse", new { id = course.Id }, new CourseDetailDto
            {
                Id = course.Id,
                Title = course.Title,
                Deadline = course.Deadline,
                IsEnded = false,
                Books = course.Books,
                QuestionGroups = course.QuestionGroups,
                Sessions = course.Sessions
            });
        }

        // PUT: api/Courses/5
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PutCourse(int id, [FromBody] CourseDto dto)
        {
            var existing = await _context.Courses
                .Include(c => c.Books)
                .Include(c => c.Sessions)
                .Include(c => c.QuestionGroups)
                .Include(c => c.Students)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (existing == null) return NotFound();

            existing.Title = dto.Title;
            existing.Deadline = dto.Deadline;

            if (dto.BookIds.Any()) existing.Books = await _context.Books.Where(b => dto.BookIds.Contains(b.Id)).ToListAsync();
            if (dto.SessionIds.Any()) existing.Sessions = await _context.Sessions.Where(s => dto.SessionIds.Contains(s.Id)).ToListAsync();
            if (dto.QuestionGroupIds.Any()) existing.QuestionGroups = await _context.QuestionGroups.Where(q => dto.QuestionGroupIds.Contains(q.Id)).ToListAsync();
            if (dto.StudentIds.Any()) existing.Students = await _context.Users.Where(u => dto.StudentIds.Contains(u.Id)).ToListAsync();

            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/Courses/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteCourse(int id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course == null) return NotFound();

            _context.Courses.Remove(course);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST: api/Courses/5/add-book/3
        [HttpPost("{id}/add-book/{bookId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddBookToCourse(int id, int bookId)
        {
            var course = await _context.Courses.Include(c => c.Books).FirstOrDefaultAsync(c => c.Id == id);
            if (course == null) return NotFound("Course not found.");

            var book = await _context.Books.FindAsync(bookId);
            if (book == null) return NotFound("Book not found.");

            if (course.Books.Any(b => b.Id == bookId))
                return BadRequest("Book is already assigned to this course.");

            book.Course = course;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST: api/Courses/5/remove-book/3
        [HttpPost("{id}/remove-book/{bookId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemoveBookFromCourse(int id, int bookId)
        {
            var book = await _context.Books.FirstOrDefaultAsync(b => b.Id == bookId && b.Course != null && b.Course.Id == id);
            if (book == null) return NotFound();

            book.Course = null;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST: api/Courses/5/add-session/3
        [HttpPost("{id}/add-session/{sessionId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddSessionToCourse(int id, int sessionId)
        {
            var course = await _context.Courses.Include(c => c.Sessions).FirstOrDefaultAsync(c => c.Id == id);
            if (course == null) return NotFound("Course not found.");

            var session = await _context.Sessions.FindAsync(sessionId);
            if (session == null) return NotFound("Session not found.");

            if (course.Sessions.Any(s => s.Id == sessionId))
                return BadRequest("Session is already assigned to this course.");

            session.Course = course;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST: api/Courses/5/remove-session/3
        [HttpPost("{id}/remove-session/{sessionId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemoveSessionFromCourse(int id, int sessionId)
        {
            var session = await _context.Sessions.FirstOrDefaultAsync(s => s.Id == sessionId && s.Course != null && s.Course.Id == id);
            if (session == null) return NotFound();

            session.Course = null;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST: api/Courses/5/add-questiongroup/3
        [HttpPost("{id}/add-questiongroup/{groupId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddQuestionGroupToCourse(int id, int groupId)
        {
            var course = await _context.Courses.Include(c => c.QuestionGroups).FirstOrDefaultAsync(c => c.Id == id);
            if (course == null) return NotFound("Course not found.");

            var group = await _context.QuestionGroups.FindAsync(groupId);
            if (group == null) return NotFound("QuestionGroup not found.");

            if (course.QuestionGroups.Any(q => q.Id == groupId))
                return BadRequest("QuestionGroup is already assigned to this course.");

            group.Course = course;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST: api/Courses/5/remove-questiongroup/3
        [HttpPost("{id}/remove-questiongroup/{groupId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemoveQuestionGroupFromCourse(int id, int groupId)
        {
            var group = await _context.QuestionGroups.FirstOrDefaultAsync(q => q.Id == groupId && q.Course != null && q.Course.Id == id);
            if (group == null) return NotFound();

            group.Course = null;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST: api/Courses/5/add-student/user123
        [HttpPost("{id}/add-student/{userId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddStudentToCourse(int id, string userId)
        {
            var course = await _context.Courses.Include(c => c.Students).FirstOrDefaultAsync(c => c.Id == id);
            if (course == null) return NotFound("Course not found.");

            var student = await _context.Users.FindAsync(userId);
            if (student == null) return NotFound("Student not found.");

            if (course.Students.Any(s => s.Id == userId))
                return BadRequest("Student is already assigned to this course.");

            course.Students.Add(student);
            await _context.SaveChangesAsync();
            var message = $@"السلام عليكم، مساء الخير.🌹
تم تفعيل الحساب بنجاح
#course: {course.Title}
#student name: {student.FullName}
#username: {student.UserName}

🎯اليوزر والباسورد ناخدهم من ابننا أو بنتنا

بالتوفيق تيم دكتور زياد🤝♥️

Best wishes team Dr. Ziad Mohamed❤️";
            await _whathsappService.SendMessageAsync(student.ParentPhoneNumber, message);
            return NoContent();
        }

        // POST: api/Courses/5/remove-student/user123
        [HttpPost("{id}/remove-student/{userId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemoveStudentFromCourse(int id, string userId)
        {
            var course = await _context.Courses.Include(c => c.Students).FirstOrDefaultAsync(c => c.Id == id);
            if (course == null) return NotFound("Course not found.");

            var student = course.Students.FirstOrDefault(s => s.Id == userId);
            if (student == null) return NotFound("Student is not assigned to this course.");

            course.Students.Remove(student);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
