using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DrZiadMathIGAPI.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace DrZiadMathIGAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly DragonLMSDbContext _context;

        public BooksController(DragonLMSDbContext context)
        {
            _context = context;
        }

        private string? GetUserId() => User?.FindFirstValue(ClaimTypes.NameIdentifier);
        private static DateOnly Today => DateOnly.FromDateTime(DateTime.Now);

        // GET: api/Books
        [HttpGet]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<Book>>> GetBooks()
        {
            var query = _context.Books
                .Include(b => b.Course)
                    .ThenInclude(c => c!.Students)
                .AsQueryable();

            var userId = GetUserId();
            if (User?.IsInRole("Admin") != true && userId != null)
            {
                query = query.Where(b => b.Course != null
                    && b.Course.Deadline >= Today
                    && b.Course.Students.Any(s => s.Id == userId));
            }

            return await query.ToListAsync();
        }

        // GET: api/Books/5
        [HttpGet("{id}")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<Book>> GetBook(int id)
        {
            var book = await _context.Books
                .Include(b => b.Course)
                    .ThenInclude(c => c!.Students)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (book == null)
            {
                return NotFound();
            }

            var userId = GetUserId();
            if (User?.IsInRole("Admin") != true && userId != null)
            {
                if (book.Course == null || book.Course.Deadline < Today || !book.Course.Students.Any(s => s.Id == userId))
                {
                    return NotFound();
                }
            }

            return book;
        }

        // PUT: api/Books/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PutBook(int id, Book book)
        {
            if (id != book.Id)
            {
                return BadRequest();
            }

            _context.Entry(book).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BookExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Books
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Book>> PostBook(Book book, [FromQuery] int? courseId = null)
        {
            if (courseId.HasValue)
            {
                var course = await _context.Courses.FindAsync(courseId.Value);
                if (course != null) book.Course = course;
            }
            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBook", new { id = book.Id }, book);
        }

        // DELETE: api/Books/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("{id}/questions")]
        [Authorize(Roles = "Student,Admin")]
        public async Task<ActionResult<IEnumerable<Question>>> GetBookQuestions(int id)
        {
            var book = await _context.Books.Include(b => b.BookQuestions)
                                            .ThenInclude(bq => bq.Question)
                                            .Include(b => b.Course)
                                            .ThenInclude(c => c!.Students)
                                            .FirstOrDefaultAsync(b => b.Id == id);
            if (book == null)
            {
                return NotFound();
            }

            var userId = GetUserId();
            if (User?.IsInRole("Admin") != true && userId != null)
            {
                if (book.Course == null || book.Course.Deadline < Today || !book.Course.Students.Any(s => s.Id == userId))
                {
                    return NotFound();
                }
            }

            var questions = book.BookQuestions.Select(bq => bq.Question).ToList();
            return questions;
        }



        private bool BookExists(int id)
        {
            return _context.Books.Any(e => e.Id == id);
        }
    }
}
