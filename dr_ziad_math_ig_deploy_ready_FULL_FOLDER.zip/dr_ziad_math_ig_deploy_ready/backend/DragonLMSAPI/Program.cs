﻿using System.Text;
using DrZiadMathIGAPI.Filters;
using DrZiadMathIGAPI.Models;
using DrZiadMathIGAPI.Services;
using Hangfire;
using Hangfire.PostgreSql;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.IdentityModel.Tokens;

namespace DrZiadMathIGAPI
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Configuration.AddYamlFile("config.yml", optional: false, reloadOnChange: false);
            var whatsappEnabled = builder.Configuration.GetValue<bool>("features:services:baileyswp");
            Console.WriteLine($"[WhatsApp] Enabled: {whatsappEnabled}");
            const long uploadLimitBytes = 100L * 1024L * 1024L;

            // Add services to the container.
            builder.WebHost.ConfigureKestrel(options =>
            {
                options.Limits.MaxRequestBodySize = uploadLimitBytes;
            });

            builder.Services.AddControllers()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
                });
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();
            builder.Services.Configure<FormOptions>(options =>
            {
                options.MultipartBodyLengthLimit = uploadLimitBytes;
                options.ValueLengthLimit = int.MaxValue;
                options.MultipartHeadersLengthLimit = int.MaxValue;
            });


            builder.Services.AddDbContext<DragonLMSDbContext>(options =>
                options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection"))
                    .ConfigureWarnings(warnings => warnings.Ignore(RelationalEventId.PendingModelChangesWarning)));

            builder.Services.AddHangfire(config =>
               config.UsePostgreSqlStorage(options =>
               {
                   options.UseNpgsqlConnection(builder.Configuration.GetConnectionString("DefaultConnection"));
               }));

            builder.Services.AddHangfireServer();

            builder.Services.AddHttpContextAccessor();
            builder.Services.AddScoped<IStorageService, LocalStorageService>();
            builder.Services.AddHttpClient<IWhatsappService, BaileysWhatsappService>();
            builder.Services.AddScoped<IAnalyticsService, AnalyticsService>();

            builder.Services.AddSingleton<ISchedulerService, SchedulerService>();
            builder.Services.AddScoped<IWeeklyExamService, WeeklyExamService>();
            builder.Services.AddScoped<Services.Video.IVideoProvider, Services.Video.DefaultVideoProvider>();
            builder.Services.AddHttpClient<Services.Video.IVideoProvider, Services.Video.VdoCipherVideoProvider>();
            builder.Services.AddScoped<Services.Video.VideoService>();

            builder.Services
                .AddIdentityCore<ApplicationUser>(options =>
                {
                    options.User.RequireUniqueEmail = false;
                    options.Password.RequiredLength = 6;
                    options.Password.RequireDigit = false;
                    options.Password.RequireLowercase = false;
                    options.Password.RequireUppercase = false;
                    options.Password.RequireNonAlphanumeric = false;
                })
                .AddRoles<IdentityRole>()
                .AddEntityFrameworkStores<DragonLMSDbContext>()
                .AddDefaultTokenProviders();

            var jwtSection = builder.Configuration.GetSection("Jwt");
            var jwtKey = jwtSection["Key"] ?? throw new InvalidOperationException("Jwt:Key is missing.");
            var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));

            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = jwtSection["Issuer"],
                    ValidAudience = jwtSection["Audience"],
                    IssuerSigningKey = signingKey,
                    ClockSkew = TimeSpan.Zero
                };

                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        var token = context.Request.Cookies["dr-ziad-math-ig-token"];
                        if (!string.IsNullOrEmpty(token))
                        {
                            context.Token = token;
                        }
                        return Task.CompletedTask;
                    }
                };
            });

            builder.Services.AddAuthorization();

            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });

            var app = builder.Build();

            using (var scope = app.Services.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<DragonLMSDbContext>();
                await dbContext.Database.MigrateAsync();

                var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
                await EnsureRolesAsync(roleManager);

                var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
                var config = scope.ServiceProvider.GetRequiredService<IConfiguration>();
                var adminPassword = config.GetValue<string>("DefaultAdmin:Password");
                if (string.IsNullOrWhiteSpace(adminPassword)) adminPassword = "Admin123!";
                var adminUsername = config.GetValue<string>("DefaultAdmin:Username");
                if (string.IsNullOrWhiteSpace(adminUsername)) adminUsername = "drZiad";
                await EnsureDefaultUsersAsync(userManager, adminPassword, adminUsername);

                // Seed default courses
                if (!dbContext.Courses.Any())
                {
                    var defaultCourses = new[]
                    {
                        new Course { Title = "IGCSE Math Core Foundation", Deadline = new DateOnly(2027, 12, 31) },
                        new Course { Title = "IGCSE Math Extended Track", Deadline = new DateOnly(2027, 12, 31) },
                        new Course { Title = "IGCSE Math Past Papers", Deadline = new DateOnly(2027, 12, 31) },
                        new Course { Title = "IGCSE Math Weekly Homework", Deadline = new DateOnly(2027, 12, 31) },
                        new Course { Title = "IGCSE Math Final Revision", Deadline = new DateOnly(2027, 12, 31) },
                    };
                    dbContext.Courses.AddRange(defaultCourses);
                    await dbContext.SaveChangesAsync();
                }
            }

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
            }

            if (!app.Environment.IsDevelopment())
            {
                app.UseHttpsRedirection();
            }

            var uploadPath = builder.Configuration["UPLOAD_PATH"] ?? Path.Combine(Directory.GetCurrentDirectory(), "uploads");
            if (!Directory.Exists(uploadPath))
            {
                Directory.CreateDirectory(uploadPath);
            }
            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(uploadPath),
                RequestPath = "/api/uploads"
            });

            app.UseCors("AllowAll");
            app.UseAuthentication();
            app.UseAuthorization();
            app.MapControllers();

            app.UseHangfireDashboard("/api/hangfire", new DashboardOptions
            {
                Authorization = new[] { new HangfireDashboardAuthorizationFilter() }
            });

            using (var scope = app.Services.CreateScope())
            {
                var schedulerService = scope.ServiceProvider.GetRequiredService<ISchedulerService>();
                schedulerService.ConfigureExamWeeklyJob(DayOfWeek.Friday, 20);
            }

            await app.RunAsync();
        }

        private static async Task EnsureRolesAsync(RoleManager<IdentityRole> roleManager)
        {
            string[] roles = ["Student", "Admin", "Parent"];

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }
        }

        private static async Task EnsureDefaultUsersAsync(UserManager<ApplicationUser> userManager, string adminPassword, string adminUsername)
        {
            var admin = await userManager.FindByNameAsync(adminUsername);
            if (admin == null)
            {
                admin = new ApplicationUser
                {
                    UserName = adminUsername,
                    Email = "drziad@mathig.local",
                    Name = "Dr. Ziad Mohamed",
                    PhoneNumber = "0123456789",
                    ParentPhoneNumber = "N/A",
                    FullName = "Dr. Ziad Mohamed",
                    AccountType = AccountType.Admin
                };

                var result = await userManager.CreateAsync(admin, adminPassword);
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(admin, "Admin");
                }
            }
            else
            {
                // Ensure existing teacher is in the Admin role
                if (!await userManager.IsInRoleAsync(admin, "Admin"))
                {
                    await userManager.AddToRoleAsync(admin, "Admin");
                }
            }
        }
    }
}

