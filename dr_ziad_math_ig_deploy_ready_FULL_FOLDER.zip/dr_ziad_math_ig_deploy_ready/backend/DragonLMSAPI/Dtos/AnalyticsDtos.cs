namespace DrZiadMathIGAPI.Dtos
{
    public class AverageScoreTrendDto
    {
        public string Date { get; set; } = string.Empty;
        public double AverageScore { get; set; }
    }

    public class StudentCourseDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
    }
}
