using System;
using System.Collections.Generic;

namespace DrZiadMathIGAPI.Dtos
{
    public class ParentDashboardDto
    {
        public required GeneralProgressDto GeneralProgress { get; set; }
        public List<WeakPointDto> WeakPoints { get; set; } = new();
        public List<MistakeDto> Mistakes { get; set; } = new();
        public List<DailyActivityDto> DailyActivity { get; set; } = new();
    }

    public class GeneralProgressDto
    {
        public double AverageScore { get; set; }
        public int CompletedAssignments { get; set; }
        public int TotalAssignments { get; set; }
        public int StudentRank { get; set; }
        public int RankedStudents { get; set; }
        public List<ScoreTrendDto> ScoreTrend { get; set; } = new();
    }

    public class ScoreTrendDto
    {
        public DateTime Date { get; set; }
        public double Score { get; set; }
    }

    public class DailyActivityDto
    {
        public DateTime Date { get; set; }
        public int AttemptsCount { get; set; }
        public double AverageScore { get; set; }
        public List<DailyActivityDetailDto> Details { get; set; } = new();
    }

    public class DailyActivityDetailDto
    {
        public int TryId { get; set; }
        public string ActivityTitle { get; set; } = string.Empty;
        public int CorrectAnswers { get; set; }
        public int TotalQuestions { get; set; }
        public double Score { get; set; }
        public DateTime SubmittedAt { get; set; }
    }

    public class WeakPointDto
    {
        public string CategoryName { get; set; } = string.Empty;
        public int MistakeCount { get; set; }
        public double Accuracy { get; set; }
    }

    public class MistakeDto
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; } = string.Empty;
        public string? QuestionImageUrl { get; set; }
        public string SelectedChoiceText { get; set; } = string.Empty;
        public string CorrectChoiceText { get; set; } = string.Empty;
        public DateTime Date { get; set; }
    }

    public class AdminDashboardDto
    {
        public int TotalStudents { get; set; }
        public int TotalCourses { get; set; }
        public int ActiveCourses { get; set; }
        public int EndedCourses { get; set; }
        public int TotalBooks { get; set; }
        public int TotalSessions { get; set; }
        public int TotalAssignments { get; set; }
        public int TotalSkills { get; set; }
        public int TotalWeeklyExams { get; set; }
        public int TotalAttempts { get; set; }
        public double AverageScore { get; set; }
        public int AttemptsToday { get; set; }
        public List<AdminSeriesPointDto> AttemptTrend { get; set; } = new();
        public List<AdminSeriesPointDto> ScoreTrend { get; set; } = new();
        public List<AdminSeriesPointDto> CourseDistribution { get; set; } = new();
        public List<AdminSeriesPointDto> AverageScoreByCourse { get; set; } = new();
        public List<AdminSeriesPointDto> CourseStatus { get; set; } = new();
        public List<AdminSeriesPointDto> ContentMix { get; set; } = new();
        public List<AdminRecentAttemptDto> RecentAttempts { get; set; } = new();
    }

    public class AdminSeriesPointDto
    {
        public string Label { get; set; } = string.Empty;
        public double Value { get; set; }
    }

    public class AdminRecentAttemptDto
    {
        public int Id { get; set; }
        public string StudentName { get; set; } = string.Empty;
        public string ActivityTitle { get; set; } = string.Empty;
        public DateTime SubmittedAt { get; set; }
        public double Score { get; set; }
    }
}
