using DrZiadMathIGAPI.Models;
using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Dtos
{
    public class RegisterRequest
    {
        [Required]
        public string Username { get; set; } = string.Empty;

        [Required]
        [MinLength(6)]
        public string Password { get; set; } = string.Empty;

        [Required]
        public string Name { get; set; } = string.Empty;

        public string? PhoneNumber { get; set; }

        public string? ParentPhoneNumber { get; set; }

        [Required]
        public AccountType AccountType { get; set; }
    }

    public class LoginRequest
    {
        [Required]
        public string Username { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;
    }

    public class AdminResetPasswordRequest
    {
        [Required]
        [MinLength(6)]
        public string NewPassword { get; set; } = string.Empty;
    }

    public class UpdateStudentRequest
    {
        public string? Name { get; set; }
        public string? Phone { get; set; }
        public string? ParentPhone { get; set; }
    }

    public class UserProfileDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? UserName { get; set; }
        public string? Phone { get; set; }
        public string? ParentPhone { get; set; }
        public AccountType AccountType { get; set; }
        public List<int> CourseIds { get; set; } = new();
    }

    public sealed record AuthResponse(string Token, IEnumerable<string> Roles);

    public class StudentStatsDto
    {
        public string StudentId { get; set; } = string.Empty;
        public string StudentName { get; set; } = string.Empty;
        public string? StudentPhone { get; set; }
        public double TotalScore { get; set; }
        public double TotalScoreOutOf800 { get; set; }
        public int WeakPointsCount { get; set; }
        public int MistakeCount { get; set; }
        public int CompletedAssignments { get; set; }
        public int StudentRank { get; set; }
        public int RankedStudents { get; set; }
        public DateTime? LastActivity { get; set; }
        public List<TryDto> RecentTries { get; set; } = new();
    }

    public class ParentChildDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public DateTime? LastActivity { get; set; }
    }
}
