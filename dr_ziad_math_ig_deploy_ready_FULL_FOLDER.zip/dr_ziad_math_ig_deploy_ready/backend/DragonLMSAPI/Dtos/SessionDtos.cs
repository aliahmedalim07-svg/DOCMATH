using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Dtos
{
    public class PostSessionWithPDFsDTO
    {
        public int Id { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public required string URL { get; set; }
        [Required]
        public required List<byte[]> PDFBytes { get; set; }
    }

    public class CreateSessionDto
    {
        public string? Title { get; set; }

        public DateTime? StartTime { get; set; }

        [Required]
        public required string Url { get; set; }
    }
}
