using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Dtos
{
    public class CreateAssignmentDto
    {
        public string Title { get; set; } = "";
        public int DurationInMinutes { get; set; }
        public int BookId { get; set; }
        public int? CourseId { get; set; }
    }

    public class SubmitAnswerDto
    {
        public int QuestionId { get; set; }
        public int ChoiceId { get; set; }
    }

    public class SubmitQuestionGroupDto
    {
        public List<SubmitAnswerDto> Answers { get; set; } = new();
    }

    public class SubmitResultDto
    {
        public int TryId { get; set; }
        public int TotalQuestions { get; set; }
        public int CorrectAnswers { get; set; }
        public double ScorePercentage { get; set; }
    }

    public class TryDto
    {
        public int Id { get; set; }
        public string QuestionGroupTitle { get; set; } = "";
        public int QuestionGroupId { get; set; }
        public DateTime SubmittedAt { get; set; }
        public int TotalQuestions { get; set; }
        public int CorrectAnswers { get; set; }
        public double ScorePercentage { get; set; }
    }

    public class TryDetailDto
    {
        public int TryId { get; set; }
        public string QuestionGroupTitle { get; set; } = "";
        public int QuestionGroupId { get; set; }
        public DateTime SubmittedAt { get; set; }
        public int TotalQuestions { get; set; }
        public int CorrectAnswers { get; set; }
        public double ScorePercentage { get; set; }
        public List<QuestionAnswerDto> Answers { get; set; } = new();
    }

    public class AssignmentDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public QuestionGroupType Type { get; set; }
        public int DurationInMinutes { get; set; }
        public Book? Book { get; set; }
        public Course? Course { get; set; }
        public List<QuestionGroupVideo> Videos { get; set; } = new();
        public List<QuestionGroupPDF> Pdfs { get; set; } = new();
        public List<QuestionBelonging> QuestionBelongings { get; set; } = new();
    }

    public class SkillDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public QuestionGroupType Type { get; set; }
        public Course? Course { get; set; }
        public List<QuestionGroupVideo> Videos { get; set; } = new();
        public List<QuestionGroupPDF> Pdfs { get; set; } = new();
        public List<QuestionBelonging> QuestionBelongings { get; set; } = new();
    }

    public class WeeklyExamDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public QuestionGroupType Type { get; set; }
        public DateOnly Date { get; set; }
        public Course? Course { get; set; }
        public List<QuestionGroupVideo> Videos { get; set; } = new();
        public List<QuestionGroupPDF> Pdfs { get; set; } = new();
        public List<QuestionBelonging> QuestionBelongings { get; set; } = new();
    }

    public class UpdateQuestionGroupDto
    {
        public int? CourseId { get; set; }
    }

    public class QuestionAnswerDto
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; } = "";
        public string? QuestionImageUrl { get; set; }
        public string? Explanation { get; set; }
        public string? ExplanationImageUrl { get; set; }
        public int? SelectedChoiceId { get; set; }
        public string? SelectedChoiceText { get; set; }
        public string? SelectedChoiceImageUrl { get; set; }
        public int? CorrectChoiceId { get; set; }
        public string? CorrectChoiceText { get; set; }
        public string? CorrectChoiceImageUrl { get; set; }
        public bool IsCorrect { get; set; }
    }
}
