using System.ComponentModel.DataAnnotations;
using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Dtos
{
    public class CourseDto
    {
        public int? Id { get; set; }

        [Required]
        public required string Title { get; set; }

        [Required]
        public DateOnly Deadline { get; set; }

        public List<int> BookIds { get; set; } = new();
        public List<int> SessionIds { get; set; } = new();
        public List<int> QuestionGroupIds { get; set; } = new();
        public List<string> StudentIds { get; set; } = new();
    }

    public class CourseListDto
    {
        public int Id { get; set; }
        public required string Title { get; set; }
        public DateOnly Deadline { get; set; }
        public bool IsEnded { get; set; }
    }

    public class CourseNameDto
    {
        public int Id { get; set; }
        public required string Title { get; set; }
        public bool IsEnded { get; set; }
    }

    public class CourseDetailDto
    {
        public int Id { get; set; }
        public required string Title { get; set; }
        public DateOnly Deadline { get; set; }
        public bool IsEnded { get; set; }
        public List<Book>? Books { get; set; }
        public List<QuestionGroup>? QuestionGroups { get; set; }
        public List<Session>? Sessions { get; set; }
    }

    public class EndedCourseDto
    {
        public int Id { get; set; }
        public required string Title { get; set; }
        public bool IsEnded { get; set; }
    }
}
