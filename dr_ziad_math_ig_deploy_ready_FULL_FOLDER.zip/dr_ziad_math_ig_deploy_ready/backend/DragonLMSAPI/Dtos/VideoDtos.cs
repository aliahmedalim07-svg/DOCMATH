using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Dtos
{
    public class AddQuestionGroupVideoDto
    {
        public required string Url { get; set; }
        public VideoProvider Provider { get; set; } = VideoProvider.YouTube;
        public int? DefaultViews { get; set; }
    }

    public class VideoPlayResultDto
    {
        public string Url { get; set; } = "";
        public string PlayerType { get; set; } = "youtube";
    }

    public class VideoUserViewDto
    {
        public string UserId { get; set; } = "";
        public string UserName { get; set; } = "";
        public int Views { get; set; }
    }

    public class UpdateUserViewDto
    {
        public int Views { get; set; }
    }

    public class RemainingViewsDto
    {
        public int RemainingViews { get; set; }
    }
}
