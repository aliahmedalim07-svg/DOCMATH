using DrZiadMathIGAPI.Dtos;
using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Services
{
    public interface IAnalyticsService
    {
        Task<List<MistakeDto>> GetMistakeHistoryAsync(ApplicationUser user);
        Task<List<WeakPointDto>> GetWeakPointsDataAsync(ApplicationUser user);
        Task<List<AverageScoreTrendDto>> GetAverageScoreTrendByCourseAsync(int courseId);
        Task<List<StudentCourseDto>> GetStudentsByCourseAsync(int courseId);
    }
}
