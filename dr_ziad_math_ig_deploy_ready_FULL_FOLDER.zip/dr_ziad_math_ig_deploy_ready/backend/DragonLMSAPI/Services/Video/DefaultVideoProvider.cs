using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Services.Video
{
    public class DefaultVideoProvider : IVideoProvider
    {
        public bool CanHandle(QuestionGroupVideo video)
        {
            return video.Provider == VideoProvider.YouTube;
        }

        public Task<VideoPlayResult> GetPlayableUrlAsync(QuestionGroupVideo video, string? viewerName = null)
        {
            return Task.FromResult(new VideoPlayResult
            {
                Url = video.Url,
                PlayerType = "youtube"
            });
        }
    }
}
