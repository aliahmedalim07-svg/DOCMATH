using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Services.Video
{
    public class VideoService
    {
        private readonly IEnumerable<IVideoProvider> _providers;

        public VideoService(IEnumerable<IVideoProvider> providers)
        {
            _providers = providers;
        }

        public async Task<VideoPlayResult> GetPlayableUrlAsync(QuestionGroupVideo video, string? viewerName = null)
        {
            var provider = _providers.FirstOrDefault(p => p.CanHandle(video));
            if (provider == null)
            {
                return new VideoPlayResult
                {
                    Url = video.Url,
                    PlayerType = "unknown"
                };
            }

            return await provider.GetPlayableUrlAsync(video, viewerName);
        }
    }
}
