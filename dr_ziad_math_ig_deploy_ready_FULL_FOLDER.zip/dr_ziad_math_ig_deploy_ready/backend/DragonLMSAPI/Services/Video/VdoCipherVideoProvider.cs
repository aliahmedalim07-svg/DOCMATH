using System.Text.Json;
using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Services.Video
{
    public class VdoCipherVideoProvider : IVideoProvider
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;

        public VdoCipherVideoProvider(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _apiKey = configuration["VdoCipher:ApiKey"] ?? throw new InvalidOperationException("VdoCipher:ApiKey is missing.");
        }

        public bool CanHandle(QuestionGroupVideo video)
        {
            return video.Provider == VideoProvider.VdoCipher;
        }

        public async Task<VideoPlayResult> GetPlayableUrlAsync(QuestionGroupVideo video, string? viewerName = null)
        {
            var videoId = video.Url;

            var body = BuildOtpRequestBody(viewerName);

            var request = new HttpRequestMessage(HttpMethod.Post, $"https://dev.vdocipher.com/api/videos/{videoId}/otp");
            request.Headers.Add("Authorization", $"Apisecret {_apiKey}");
            request.Content = new StringContent(body, System.Text.Encoding.UTF8, "application/json");

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;
            var otp = root.GetProperty("otp").GetString();
            var playbackInfo = root.GetProperty("playbackInfo").GetString()!;

            return new VideoPlayResult
            {
                Url = $"https://player.vdocipher.com/v2/?otp={otp}&playbackInfo={playbackInfo}",
                PlayerType = "vdocipher"
            };
        }

        private static string BuildOtpRequestBody(string? viewerName)
        {
            if (string.IsNullOrWhiteSpace(viewerName))
                return "{\"ttl\": 3600}";

            var annotate = JsonSerializer.Serialize(new[]
            {
                new
                {
                    type = "rtext",
                    text = viewerName,
                    alpha = "0.50",
                    color = "0xFFFFFF",
                    size = "12",
                    interval = "5000"
                }
            });

            return $"{{\"ttl\": 3600, \"annotate\": {JsonSerializer.Serialize(annotate)}}}";
        }
    }
}
