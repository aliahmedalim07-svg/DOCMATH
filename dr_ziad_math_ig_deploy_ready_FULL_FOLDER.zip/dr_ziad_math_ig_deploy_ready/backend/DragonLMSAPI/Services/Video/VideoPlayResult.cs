namespace DrZiadMathIGAPI.Services.Video
{
    public class VideoPlayResult
    {
        public string Url { get; set; } = "";
        public string PlayerType { get; set; } = "youtube";
    }
}
