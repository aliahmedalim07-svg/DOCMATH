using DrZiadMathIGAPI.Models;

namespace DrZiadMathIGAPI.Services.Video
{
    public interface IVideoProvider
    {
        bool CanHandle(QuestionGroupVideo video);
        Task<VideoPlayResult> GetPlayableUrlAsync(QuestionGroupVideo video, string? viewerName = null);
    }
}
