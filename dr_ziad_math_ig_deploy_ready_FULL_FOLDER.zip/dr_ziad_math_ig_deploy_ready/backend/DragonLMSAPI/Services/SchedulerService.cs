﻿using Hangfire;

namespace DrZiadMathIGAPI.Services
{
    public class SchedulerService : ISchedulerService
    {
        public void ConfigureExamWeeklyJob(DayOfWeek dayOfWeek, int numQuestions)
        {
            RecurringJob.AddOrUpdate<IWeeklyExamService>(
                "weekly-exams",
                service => service.GenerateExam(numQuestions),
                Cron.Weekly(dayOfWeek)
            );
        }
    }
}
