﻿namespace DrZiadMathIGAPI.Services
{
    public interface IWeeklyExamService
    {
        public Task GenerateExam(int numQuestions);
    }
}
