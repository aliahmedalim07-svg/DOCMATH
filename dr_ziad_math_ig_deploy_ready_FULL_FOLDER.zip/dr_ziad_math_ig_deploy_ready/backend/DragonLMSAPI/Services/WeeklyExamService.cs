﻿using DrZiadMathIGAPI.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace DrZiadMathIGAPI.Services
{
    public class WeeklyExamService(DragonLMSDbContext context, UserManager<ApplicationUser> userManager) : IWeeklyExamService
    {
        public async Task GenerateExam(int numQuestions = 20)
        {
            var studentIds = (await userManager.GetUsersInRoleAsync("Student"))
                .Select(s => s.Id)
                .ToList();

            var students = await context.Users
                .Include(u => u.Courses)
                .Where(u => studentIds.Contains(u.Id))
                .ToListAsync();

            var today = DateOnly.FromDateTime(DateTime.UtcNow);

            foreach (var student in students)
            {
                foreach (var course in student.Courses)
                {
                    var wrongQuestionIds = await context.UserAnswers
                        .Where(ua => ua.User.Id == student.Id &&
                                     !ua.SelectedChoice.IsCorrect &&
                                     ua.Try.QuestionGroup != null &&
                                     (ua.Try.QuestionGroup.Type == QuestionGroupType.Assignments ||
                                      ua.Try.QuestionGroup.Type == QuestionGroupType.Skills) &&
                                     ua.Try.QuestionGroup.Course != null &&
                                     ua.Try.QuestionGroup.Course.Id == course.Id)
                        .Select(ua => ua.Question.Id)
                        .Distinct()
                        .ToListAsync();

                    var selectedQuestionIds = new HashSet<int>();
                    foreach (var wrongId in wrongQuestionIds.OrderBy(_ => Guid.NewGuid()))
                    {
                        if (selectedQuestionIds.Count >= numQuestions)
                        {
                            break;
                        }

                        selectedQuestionIds.Add(wrongId);
                    }

                    if (selectedQuestionIds.Count < numQuestions)
                    {
                        var remainingQuestionIds = await context.QuestionBelongings
                            .Where(qb => qb.QuestionGroup.Course != null &&
                                         qb.QuestionGroup.Course.Id == course.Id &&
                                         (qb.QuestionGroup.Type == QuestionGroupType.Assignments ||
                                          qb.QuestionGroup.Type == QuestionGroupType.Skills))
                            .Select(qb => qb.Question.Id)
                            .Distinct()
                            .Where(id => !selectedQuestionIds.Contains(id))
                            .OrderBy(_ => Guid.NewGuid())
                            .Take(numQuestions - selectedQuestionIds.Count)
                            .ToListAsync();

                        foreach (var questionId in remainingQuestionIds)
                        {
                            selectedQuestionIds.Add(questionId);
                        }
                    }

                    if (selectedQuestionIds.Count == 0)
                    {
                        continue;
                    }

                    var questions = await context.Questions
                        .Where(q => selectedQuestionIds.Contains(q.Id))
                        .ToListAsync();

                    var weeklyExam = new WeeklyExam
                    {
                        Title = $"Weekly Exam - {course.Title} - {today:yyyy-MM-dd}",
                        Type = QuestionGroupType.WeeklyExams,
                        User = student,
                        Date = today,
                        Course = course
                    };

                    foreach (var question in questions)
                    {
                        weeklyExam.QuestionBelongings.Add(new QuestionBelonging
                        {
                            Question = question,
                            QuestionGroup = weeklyExam
                        });
                    }

                    context.WeeklyExams.Add(weeklyExam);
                    await context.SaveChangesAsync();
                }
            }
        }
    }
}
