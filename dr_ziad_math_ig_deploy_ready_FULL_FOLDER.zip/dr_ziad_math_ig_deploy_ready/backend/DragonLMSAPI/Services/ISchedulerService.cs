﻿namespace DrZiadMathIGAPI.Services
{
    public interface ISchedulerService
    {
        public void ConfigureExamWeeklyJob(DayOfWeek dayOfWeek, int numQuestions);
    }
}
