using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;

namespace DrZiadMathIGAPI.Services
{
    public class LocalStorageService : IStorageService
    {
        private readonly string _basePath;

        public LocalStorageService(IConfiguration configuration)
        {
            _basePath = configuration["UPLOAD_PATH"] ?? Path.Combine(Directory.GetCurrentDirectory(), "uploads");

            if (!Directory.Exists(_basePath))
            {
                Directory.CreateDirectory(_basePath);
            }
        }

        public async Task<string> UploadFileAsync(IFormFile file, string folder)
        {
            var uploadsFolder = Path.Combine(_basePath, folder);
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            var sanitizedFileName = $"{Guid.NewGuid()}_{string.Join("_", file.FileName.Split(Path.GetInvalidFileNameChars()))}";
            var filePath = Path.Combine(uploadsFolder, sanitizedFileName);
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(fileStream);
            }

            return $"/api/uploads/{folder}/{sanitizedFileName}";
        }

        public Task DeleteFileAsync(string filePath)
        {
            if (Uri.TryCreate(filePath, UriKind.Absolute, out var uri))
            {
                var uploadsMarker = "/api/uploads/";
                var markerIndex = uri.AbsolutePath.IndexOf(uploadsMarker, StringComparison.OrdinalIgnoreCase);
                if (markerIndex >= 0)
                {
                    filePath = uri.AbsolutePath[(markerIndex + uploadsMarker.Length)..].Replace('/', Path.DirectorySeparatorChar);
                }
            }

            filePath = filePath.Replace('/', Path.DirectorySeparatorChar).TrimStart(Path.DirectorySeparatorChar);
            var fullPath = Path.Combine(_basePath, filePath);
            fullPath = Path.GetFullPath(fullPath);

            if (File.Exists(fullPath) && fullPath.StartsWith(Path.GetFullPath(_basePath)))
            {
                File.Delete(fullPath);
                return Task.CompletedTask;
            }
            else
            {
                throw new FileNotFoundException($"File not found: {fullPath}");
            }
        }
    }
}
