﻿namespace DrZiadMathIGAPI.Services
{
    public interface IWhatsappService
    {
        public Task SendMessageAsync(string phoneNumber, string message);
    }
}
