﻿using System.Text;
using System.Text.Json;

namespace DrZiadMathIGAPI.Services
{
    public class BaileysWhatsappService : IWhatsappService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiUrl;
        private readonly ILogger<BaileysWhatsappService> _logger;
        private readonly bool _isEnabled;
        public BaileysWhatsappService(HttpClient httpClient, IConfiguration configuration, ILogger<BaileysWhatsappService> logger)
        {
            _httpClient = httpClient;
            _apiUrl = configuration["WhatsappApi:BaseUrl"] ?? "http://localhost:3000";
            _logger = logger;
            _isEnabled = configuration.GetValue<bool>("features:services:baileyswp");
        }

        public async Task SendMessageAsync(string phoneNumber, string message)
        {
            if (!_isEnabled)
            {
                _logger.LogWarning("WhatsApp service is disabled. Message to {PhoneNumber} not sent.", phoneNumber);
                return;
            }

            var request = new { phoneNumber, message };

            try
            {
                var json = JsonSerializer.Serialize(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_apiUrl}/send", content);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();
                    _logger.LogError("Failed to queue WhatsApp message: {Error}", error);
                    throw new HttpRequestException($"WhatsApp API returned {response.StatusCode}: {error}");
                }

                _logger.LogInformation("Message to {PhoneNumber} queued successfully", phoneNumber);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error queuing WhatsApp message to {PhoneNumber}", phoneNumber);
                throw;
            }
        }
    }
}