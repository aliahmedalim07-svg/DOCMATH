using Microsoft.AspNetCore.Mvc;

namespace DrZiadMathIGAPI.Services
{
    public interface IStorageService
    {
        public Task<string> UploadFileAsync(IFormFile file, string folder);
        public Task DeleteFileAsync(string filePath);
    }
}
