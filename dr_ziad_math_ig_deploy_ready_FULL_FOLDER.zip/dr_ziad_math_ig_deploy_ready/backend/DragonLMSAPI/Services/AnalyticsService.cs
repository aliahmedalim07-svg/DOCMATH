using DrZiadMathIGAPI.Dtos;
using DrZiadMathIGAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace DrZiadMathIGAPI.Services
{
    public class AnalyticsService : IAnalyticsService
    {
        private readonly DragonLMSDbContext _context;

        public AnalyticsService(DragonLMSDbContext context)
        {
            _context = context;
        }

        public async Task<List<MistakeDto>> GetMistakeHistoryAsync(ApplicationUser user)
        {
            var userAnswers = await _context.UserAnswers
                .Include(a => a.Question)
                    .ThenInclude(q => q.Choices)
                .Include(a => a.SelectedChoice)
                .Include(a => a.Try)
                .Where(a => a.User.Id == user.Id)
                .ToListAsync();

            return userAnswers
                .Where(a => !a.SelectedChoice.IsCorrect)
                .OrderByDescending(a => a.Try.CreatedAt)
                .Take(20)
                .Select(a => new MistakeDto
                {
                    QuestionId = a.Question.Id,
                    QuestionText = a.Question.Text ?? string.Empty,
                    QuestionImageUrl = a.Question.QuestionImageUrl,
                    SelectedChoiceText = a.SelectedChoice.Text,
                    CorrectChoiceText = a.Question.Choices.FirstOrDefault(c => c.IsCorrect)?.Text ?? "Unknown",
                    Date = a.Try.CreatedAt
                })
                .ToList();
        }

        public async Task<List<WeakPointDto>> GetWeakPointsDataAsync(ApplicationUser user)
        {
            var userAnswers = await _context.UserAnswers
                .Include(a => a.Question)
                    .ThenInclude(q => q.QuestionBelongings)
                        .ThenInclude(qb => qb.QuestionGroup)
                .Include(a => a.SelectedChoice)
                .Where(a => a.User.Id == user.Id)
                .ToListAsync();

            return userAnswers
                .SelectMany(a => a.Question.QuestionBelongings
                    .Where(qb => qb.QuestionGroup.Type == QuestionGroupType.Skills)
                    .Select(qb => new { Answer = a, Skill = qb.QuestionGroup }))
                .GroupBy(x => x.Skill.Title)
                .Select(g => new WeakPointDto
                {
                    CategoryName = g.Key,
                    MistakeCount = g.Count(x => !x.Answer.SelectedChoice.IsCorrect),
                    Accuracy = g.Any() ? (double)g.Count(x => x.Answer.SelectedChoice.IsCorrect) / g.Count() * 100 : 0
                })
                .OrderBy(wp => wp.Accuracy)
                .ToList();
        }

        public async Task<List<AverageScoreTrendDto>> GetAverageScoreTrendByCourseAsync(int courseId)
        {
            var tries = await _context.Tries
                .Include(t => t.QuestionGroup)
                .ThenInclude(qg => qg!.Course)
                .Where(t => t.QuestionGroup!.Course != null && t.QuestionGroup!.Course.Id == courseId)
                .OrderBy(t => t.CreatedAt)
                .ToListAsync();

            var tryIds = tries.Select(t => t.Id).ToList();
            var answerCounts = await _context.UserAnswers
                .Include(a => a.SelectedChoice)
                .Where(a => tryIds.Contains(a.Try.Id))
                .GroupBy(a => a.Try.Id)
                .Select(g => new
                {
                    TryId = g.Key,
                    Total = g.Count(),
                    Correct = g.Count(a => a.SelectedChoice.IsCorrect)
                })
                .ToListAsync();

            var scoreByTry = answerCounts.ToDictionary(
                item => item.TryId,
                item => item.Total > 0 ? Math.Round((double)item.Correct / item.Total * 100, 1) : 0);

            var trend = tries
                .GroupBy(t => t.CreatedAt.Date)
                .Select(g => new AverageScoreTrendDto
                {
                    Date = g.Key.ToString("yyyy-MM-dd"),
                    AverageScore = Math.Round(g.Average(t => scoreByTry.TryGetValue(t.Id, out var s) ? s : 0), 1)
                })
                .OrderBy(t => t.Date)
                .ToList();

            return trend;
        }

        public async Task<List<StudentCourseDto>> GetStudentsByCourseAsync(int courseId)
        {
            var course = await _context.Courses
                .Include(c => c.Students)
                .FirstOrDefaultAsync(c => c.Id == courseId);

            if (course == null) return new List<StudentCourseDto>();

            return course.Students.Select(s => new StudentCourseDto
            {
                Id = s.Id,
                Name = s.Name,
                Username = s.UserName ?? string.Empty,
                PhoneNumber = s.PhoneNumber ?? string.Empty
            }).ToList();
        }
    }
}
