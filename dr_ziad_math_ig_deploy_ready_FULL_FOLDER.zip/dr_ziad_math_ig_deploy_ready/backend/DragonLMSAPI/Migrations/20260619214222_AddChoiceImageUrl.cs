﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DrZiadMathIGAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddChoiceImageUrl : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ChoiceImageUrl",
                table: "Choices",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ChoiceImageUrl",
                table: "Choices");
        }
    }
}
