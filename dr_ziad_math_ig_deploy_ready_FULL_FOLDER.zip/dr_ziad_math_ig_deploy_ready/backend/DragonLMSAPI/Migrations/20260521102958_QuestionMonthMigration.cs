﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DrZiadMathIGAPI.Migrations
{
    /// <inheritdoc />
    public partial class QuestionMonthMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MonthAppeared",
                table: "Questions",
                type: "integer",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MonthAppeared",
                table: "Questions");
        }
    }
}
