namespace DrZiadMathIGAPI.Models
{
    public class Question
    {
        public int Id { get; set; }
        public string? Text { get; set; }
        public string? QuestionImageUrl { get; set; }
        public string? ExpanationImageUrl { get; set; }
        public string? ExplanationVideoUrl { get; set; }

        public string? Difficulty { get; set; } // easy, medium, hard
        public int YearAppeared { get; set; }
        public int? MonthAppeared { get; set; }
        public string? Explanation { get; set; }
        public int OrderIndex { get; set; }

        public int? TopicId { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public Topic? Topic { get; set; }

        public required List<Choice> Choices { get; set; }

        // Navigation properties for associations
        [System.Text.Json.Serialization.JsonIgnore]
        public List<BookQuestion> BookQuestions { get; set; } = new();
        [System.Text.Json.Serialization.JsonIgnore]
        public List<QuestionBelonging> QuestionBelongings { get; set; } = new();
    }
}
