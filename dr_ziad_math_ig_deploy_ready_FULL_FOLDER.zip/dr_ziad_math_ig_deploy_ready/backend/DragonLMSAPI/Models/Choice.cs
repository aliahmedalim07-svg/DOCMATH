using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class Choice
    {
        public int Id { get; set; }

        [Required]
        public string Text { get; set; } = string.Empty;

        [Required]
        public bool IsCorrect { get; set; }

        public string? ChoiceImageUrl { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public Question? Question { get; set; }
    }
}
