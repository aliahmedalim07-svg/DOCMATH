using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class UserView
    {
        public int Id { get; set; }

        [Required]
        public required QuestionGroupVideo Video { get; set; }

        [Required]
        public required ApplicationUser User { get; set; }
        public int Views { get; set; }
    }
}
