namespace DrZiadMathIGAPI.Models
{
    public class Skill : QuestionGroup
    {
    }
}
