using Microsoft.AspNetCore.Components;
using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class BookQuestion
    {
        public int Id { get; set; }

        [Required]
        public required Book Book { get; set; }

        [Required]
        public required Question Question { get; set; }
    }
}
