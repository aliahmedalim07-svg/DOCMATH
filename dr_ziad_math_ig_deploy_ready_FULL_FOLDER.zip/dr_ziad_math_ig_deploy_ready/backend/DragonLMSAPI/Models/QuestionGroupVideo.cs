using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class QuestionGroupVideo
    {
        public int Id { get; set; }

        [Required]
        public required string Url { get; set; }

        public VideoProvider Provider { get; set; } = VideoProvider.YouTube;

        public int? DefaultViews { get; set; }

        [Required]
        public required QuestionGroup QuestionGroup { get; set; }
    }
}
