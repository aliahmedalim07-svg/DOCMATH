using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class Try
    {
        public int Id { get; set; }

        [Required]
        public required ApplicationUser User { get; set; }

        public QuestionGroup? QuestionGroup { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
