using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class QuestionGroupPDF
    {
        public int Id { get; set; }

        [Required]
        public required string Url { get; set; }

        [Required]
        public required QuestionGroup QuestionGroup { get; set; }
    }
}
