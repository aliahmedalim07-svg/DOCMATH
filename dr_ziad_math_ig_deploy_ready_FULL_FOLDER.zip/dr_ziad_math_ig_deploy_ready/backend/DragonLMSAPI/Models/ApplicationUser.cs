using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public enum AccountType
    {
        Student = 1,
        Parent = 2,
        Admin = 3
    }
    public class ApplicationUser : IdentityUser
    {
        [Required]
        public string Name { get; set; } = string.Empty;

        [Required]
        public string ParentPhoneNumber { get; set; } = string.Empty;

        [Required]
        public string FullName { get; set; } = string.Empty;

        [Required]
        public AccountType AccountType { get; set; }

        public List<Course> Courses { get; set; } = [];
    }
}
