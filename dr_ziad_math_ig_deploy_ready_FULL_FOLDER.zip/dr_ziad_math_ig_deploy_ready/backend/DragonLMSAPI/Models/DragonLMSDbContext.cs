using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DrZiadMathIGAPI.Models
{
    public class DragonLMSDbContext(DbContextOptions<DragonLMSDbContext> options) : IdentityDbContext<ApplicationUser>(options)
    {
        public DbSet<Assignment> Assignments { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BookQuestion> BookQuestions { get; set; }
        public DbSet<Choice> Choices { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<QuestionBelonging> QuestionBelongings { get; set; }
        public DbSet<QuestionGroup> QuestionGroups { get; set; }
        public DbSet<QuestionGroupPDF> QuestionGroupPDFs { get; set; }
        public DbSet<QuestionGroupVideo> QuestionGroupVideos { get; set; }
        public DbSet<Session> Sessions { get; set; }
        public DbSet<SessionPDF> SessionPDFs { get; set; }
        public DbSet<Skill> Skills { get; set; }
        public DbSet<Try> Tries { get; set; }
        public DbSet<UserAnswer> UserAnswers { get; set; }
        public DbSet<UserView> UserViews { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<WeeklyExam> WeeklyExams { get; set; }
        public DbSet<Topic> Topics { get; set; }
    }
}
