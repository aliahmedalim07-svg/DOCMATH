using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class QuestionBelonging
    {
        public int Id { get; set; }

        [Required]
        public required Question Question { get; set; }

        [Required]
        public required QuestionGroup QuestionGroup { get; set; }

        public int? OrderIndex { get; set; }
    }
}
