using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DrZiadMathIGAPI.Models
{
    public enum QuestionGroupType
    {
        Assignments = 0,
        Skills = 1,
        WeeklyExams = 2,
    }
    public abstract class QuestionGroup
    {
        public int Id { get; set; }

        [Required]
        public required string Title { get; set; }

        [Required]
        public QuestionGroupType Type { get; set; }

        public List<QuestionGroupVideo> Videos { get; set; } = new();

        public List<QuestionGroupPDF> PDFs { get; set; } = new();

        public List<Try> Tries { get; set; } = new();

        public Course? Course { get; set; }

        public List<QuestionBelonging> QuestionBelongings { get; set; } = new();
    }
}
