using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class Assignment : QuestionGroup
    {
        public int DurationInMinutes { get; set; }

        [Required]
        public required Book Book { get; set; }
    }
}
