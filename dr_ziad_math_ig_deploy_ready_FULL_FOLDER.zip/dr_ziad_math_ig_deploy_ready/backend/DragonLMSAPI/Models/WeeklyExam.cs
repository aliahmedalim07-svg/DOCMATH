using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class WeeklyExam : QuestionGroup
    {
        [Required]
        public required ApplicationUser User { get; set; }

        [Required]
        public required DateOnly Date { get; set; }
    }
}
