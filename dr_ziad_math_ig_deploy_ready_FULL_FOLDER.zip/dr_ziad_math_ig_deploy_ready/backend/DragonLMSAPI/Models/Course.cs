using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class Course
    {
        public int Id { get; set; }

        [Required]
        public required string Title { get; set; }

        [Required]
        public DateOnly Deadline { get; set; }

        public List<Book> Books { get; set; } = new();

        public List<QuestionGroup> QuestionGroups { get; set; } = new();

        public List<Session> Sessions { get; set; } = new();

        public List<ApplicationUser> Students { get; set; } = new();
    }
}
