using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required]
        public required string Title { get; set; }

        public List<BookQuestion> BookQuestions { get; set; } = new();

        public int? CourseId { get; set; }
        public Course? Course { get; set; }
    }
}
