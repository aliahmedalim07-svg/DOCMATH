using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class SessionPDF
    {
        public int Id { get; set; }

        [Required]
        public required Session Session { get; set; }

        [Required]
        public required string Title { get; set; }

        [Required]
        public required string Url { get; set; }
    }
}
