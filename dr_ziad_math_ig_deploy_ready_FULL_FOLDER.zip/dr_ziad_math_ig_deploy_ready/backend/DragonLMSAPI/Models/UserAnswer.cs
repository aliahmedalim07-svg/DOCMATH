using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class UserAnswer
    {
        public int Id { get; set; }

        [Required]
        public required ApplicationUser User { get; set; }

        [Required]
        public required Try Try { get; set; }

        [Required]
        public required Question Question { get; set; }

        [Required]
        public required Choice SelectedChoice { get; set; }
    }
}
