using System.ComponentModel.DataAnnotations;

namespace DrZiadMathIGAPI.Models
{
    public class Session
    {
        public int Id { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        public string? Title { get; set; }

        [Required]
        public required string Url { get; set; }

        public List<SessionPDF> SessionPDFs { get; set; } = new();

        public Course? Course { get; set; }
    }
}
