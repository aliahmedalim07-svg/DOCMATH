namespace DrZiadMathIGAPI.Models
{
    public enum VideoProvider
    {
        YouTube,
        VdoCipher
    }
}
