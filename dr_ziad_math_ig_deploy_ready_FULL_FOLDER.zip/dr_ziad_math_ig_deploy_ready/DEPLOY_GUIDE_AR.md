# تشغيل ورفع منصة Dr. Ziad Mohamed Math IG

## تشغيل محلي على جهازك

1. افتح Docker Desktop.
2. افتح الفولدر ده.
3. شغل `START_LOCAL_DETACHED.bat`.
4. افتح:

```text
http://localhost:8080
```

بيانات الأدمن الافتراضية موجودة في ملف `.env`.

## رفع عادي على VPS

1. ارفع الفولدر كله للسيرفر.
2. اعمل نسخة من `.env.example` باسم `.env`.
3. غيّر القيم المهمة:
   - `POSTGRES_PASSWORD`
   - `ADMIN_PASSWORD`
   - `JWT_KEY`
   - `WEB_PORT=80` لو عايز الموقع يفتح من IP السيرفر مباشرة.
4. شغل:

```bash
docker compose up --build -d
```

5. افتح:

```text
http://SERVER_IP
```

## ملاحظات مهمة

- النسخة دي متخصصة لـ Math IG فقط.
- مفيش GitHub Actions، مفيش ملفات test، مفيش خدمة WhatsApp/Baileys خارجية.
- الداتابيز هنا PostgreSQL داخل Docker volume باسم `postgres_data`.
- لو عندك داتابيز قديمة للطلاب، لازم تعمل لها restore على نفس PostgreSQL قبل التشغيل النهائي.
- لا تستخدم نفس كلمة مرور الأدمن الافتراضية على السيرفر الحقيقي.

## أوامر مفيدة

```bash
# تشغيل
docker compose up --build -d

# إيقاف بدون حذف الداتابيز
docker compose down

# مشاهدة اللوجات
docker compose logs -f

# حذف كل حاجة بما فيها الداتابيز، استخدمه بحذر
docker compose down -v
```
