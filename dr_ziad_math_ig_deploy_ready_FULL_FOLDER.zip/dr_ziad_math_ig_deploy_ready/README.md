# Dr. Ziad Mohamed Math IG LMS

Deploy-ready LMS folder for Dr. Ziad Mohamed's Math IG course.

## What is included

- React/Vite frontend
- ASP.NET Core backend API
- PostgreSQL database via Docker Compose
- Nginx frontend proxy for `/api`
- Minimal deployment files only

## Start locally

Run:

```bat
START_LOCAL_DETACHED.bat
```

Then open:

```text
http://localhost:8080
```

For Arabic instructions, open `DEPLOY_GUIDE_AR.md`.
