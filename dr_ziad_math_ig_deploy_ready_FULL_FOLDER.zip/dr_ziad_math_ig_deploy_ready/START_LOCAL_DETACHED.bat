@echo off
cd /d "%~dp0"
if not exist .env copy .env.example .env
docker compose up --build -d
echo.
echo Site: http://localhost:8080
echo Admin username: drZiad
echo Admin password: check ADMIN_PASSWORD inside .env
pause
